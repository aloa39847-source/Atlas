from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class TelegramConfig:
    enabled: bool = False
    bot_token_ref: str | None = None  # env:TELEGRAM_BOT_TOKEN
    allowed_chat_ids_ref: str | None = None  # env:TELEGRAM_ALLOWED_CHAT_IDS


class TelegramAdapter:
    """Telegram bot integration scaffold.

    - Bot token and allowed chat IDs must come from secure config/env refs.
    - Commands are verified against allowlist; no anonymous control.
    - Sensitive actions (Live, risk changes, emergency overrides) require explicit confirmation/policy checks.
    - No real Telegram API calls are made without configured token and execution path.
    """

    name = "telegram"

    def __init__(self, config: TelegramConfig | None = None):
        self.config = config or TelegramConfig()

    def status(self) -> dict[str, Any]:
        return {
            "provider": self.name,
            "configured": bool(self.config.enabled and self.config.bot_token_ref and self.config.allowed_chat_ids_ref),
            "note": "Protect bot token. Restrict to authorized chat/user IDs. Do not allow Telegram commands to bypass compliance or risk limits.",
        }

    def parse_command(self, chat_id: str, text: str) -> dict[str, Any]:
        # Safe parsing scaffold; real bot must verify chat_id against allowlist.
        cmd = (text or "").strip()
        allowed_info = {"/status", "/startbot", "/stopbot", "/report", "/help"}
        sensitive = {"/startbot", "/stopbot", "/emergency", "/live"}
        return {
            "chat_id": str(chat_id),
            "command": cmd.split()[0] if cmd else "",
            "known": (cmd.split()[0] if cmd else "") in (allowed_info | sensitive),
            "sensitive": (cmd.split()[0] if cmd else "") in sensitive,
            "authorized": None,  # must be checked against allowed_chat_ids
            "executed": False,
            "note": "No command executed. Verify allowlist and policy before acting.",
        }
