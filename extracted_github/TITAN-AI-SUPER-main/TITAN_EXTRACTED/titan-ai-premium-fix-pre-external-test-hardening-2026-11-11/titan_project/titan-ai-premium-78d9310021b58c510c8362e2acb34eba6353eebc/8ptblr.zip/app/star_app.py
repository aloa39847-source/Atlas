from __future__ import annotations

import json
from datetime import datetime, timezone
import os
from pathlib import Path
from typing import Any

from starlette.applications import Starlette
from starlette.middleware.cors import CORSMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, HTMLResponse, FileResponse
from starlette.routing import Route

from app.core.config import settings
from app.core.enums import MarketType
from app.engines.compliance import compliance_engine
from app.engines.order_gateway import PreTradeOrderGateway
from app.integrations.ai_providers import SUPPORTED_PROVIDERS, invoke_provider, list_configs, record_usage
from app.integrations.binance_adapter import BinanceTestnetAdapter, BinanceConfig
from app.services.credentials import save_testnet_credentials, load_testnet_credentials, delete_testnet_credentials, public_status as creds_public_status
from app.models import db as dbmod
from app.models.entities import AIProviderConfig, AuditLog, ConfigChange, DecisionRecord, KnowledgeSource, KnowledgeConceptRecord, LearningRecord, OrderRecord, PositionRecord, SystemState
from app.services import auth_service
from app.services.audit import log_event
from app.services.core_service import core_service
from app.services.shadow_trading import ShadowTradingService
from app.services.self_diagnosis import get_engine
from sqlalchemy import desc, select


def J(data: Any, status: int = 200) -> JSONResponse:
    return JSONResponse(data, status_code=status)


async def body(request: Request) -> dict:
    try:
        raw = await request.body()
        return json.loads(raw.decode("utf-8")) if raw else {}
    except Exception:
        return {}


def db_sess():
    return dbmod.SessionLocal()


def _bearer(request: Request) -> str | None:
    a = request.headers.get("authorization")
    if a and a.lower().startswith("bearer "):
        return a[7:].strip()
    return request.cookies.get("titan_session")


def require_user(request: Request, db):
    token = _bearer(request)
    user = auth_service.get_session_user(db, token)
    if (settings.auth_required or auth_service.auth_required()) and not user:
        return None, J({"detail": "Authentication required"}, 401)
    return user, None


def _binance_auth_error(request):
    db = db_sess()
    try:
        _user, error = require_user(request, db)
        return error
    finally:
        db.close()


def _binance_emergency_stop_error():
    db = db_sess()
    try:
        state = db.get(SystemState, 1)
        if state is None:
            return J({"ok": False, "error": "system_state_unavailable", "new_orders_blocked": True}, 503)
        if state.emergency_stop:
            return J({"ok": False, "error": "emergency_stop_active", "new_orders_blocked": True}, 423)
        if (state.status_summary or {}).get("binance_testnet_reconciliation_blocked"):
            return J({"ok": False, "error": "testnet_reconciliation_required", "new_orders_blocked": True}, 423)
        return None
    finally:
        db.close()


async def health(request: Request):
    return J({"ok": True, "service": "titan-ai-premium", "version": "0.1.0-foundation", "http_stack": "starlette"})


async def system_status(request: Request):
    db = db_sess()
    try:
        binance_status = {"status": "needs_external_service", "configured": False}
        try:
            binance_status = _binance_testnet_adapter.status()
        except Exception:
            pass
        from app.knowledge.base import coverage_report
        return J({
            "state": core_service.get_state(db),
            "knowledge_foundation": coverage_report(db),
            "engines": core_service.engines(db),
            "integrations": {
                "binance_public": {"status": "ready", "configured": True, "note": "Read-only public data"},
                "binance_testnet": binance_status,
                "binance_live": {"status": "disabled", "configured": False, "note": "Live trading disabled. No real keys."},
                "telegram": {"status": "needs_external_service", "configured": False},
                "ai_providers": {"status": "needs_external_service", "configured": False},
            },
            "data_policy": {"live_market_data": settings.binance_public_data_enabled, "synthetic_labeled_available": True, "binance_public_available": True, "note": "Distinguish clearly: public read-only vs testnet demo vs live (disabled)."},
        })
    finally:
        db.close()


async def update_state(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        return J(core_service.set_state(db, environment_mode=p.get("environment_mode"), market_type=p.get("market_type"),
                                        autonomous_enabled=p.get("autonomous_enabled"), emergency_stop=p.get("emergency_stop")))
    except ValueError as e:
        return J({"detail": str(e)}, 400)
    finally:
        db.close()


async def strategies(request: Request):
    return J({"strategies": core_service.strategies(), "note": "Registry is extensible; statuses reflect current implementation/integration state."})


async def analyze(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        return J(core_service.analyze(db, symbol=p["symbol"], market_type=p.get("market_type", "spot"), environment_mode=p.get("environment_mode", "demo"),
                                      balance=float(p.get("balance", 1000)), max_leverage=float(p.get("max_leverage", 3)), risk_per_trade=float(p.get("risk_per_trade", 0.01))))
    except Exception as e:
        return J({"detail": str(e)}, 400)
    finally:
        db.close()


async def list_decisions(request: Request):
    db = db_sess()
    try:
        limit = min(max(int(request.query_params.get("limit", 50)), 1), 200)
        rows = db.execute(select(DecisionRecord).order_by(desc(DecisionRecord.id)).limit(limit)).scalars().all()
        return J({"items": [{"id": r.id, "created_at": r.created_at.isoformat(), "symbol": r.symbol, "action": r.action, "strategy": r.strategy,
                             "confidence": r.confidence, "environment_mode": r.environment_mode, "market_type": r.market_type,
                             "data_source": r.data_source, "reason": r.rationale} for r in rows]})
    finally:
        db.close()


async def list_audit(request: Request):
    db = db_sess()
    try:
        limit = min(max(int(request.query_params.get("limit", 100)), 1), 500)
        rows = db.execute(select(AuditLog).order_by(desc(AuditLog.id)).limit(limit)).scalars().all()
        return J({"items": [{"id": r.id, "created_at": r.created_at.isoformat(), "action": r.action, "severity": r.severity,
                             "message": r.message, "environment_mode": r.environment_mode, "market_type": r.market_type, "details": r.details} for r in rows]})
    finally:
        db.close()


async def knowledge_list(request: Request):
    db = db_sess()
    try:
        rows = db.execute(select(KnowledgeSource).order_by(desc(KnowledgeSource.id)).limit(200)).scalars().all()
        return J({"items": [{"id": r.id, "title": r.title, "source_type": r.source_type, "url": r.url, "reliability_score": r.reliability_score, "verified": r.verified, "notes": r.notes, "metadata": r.metadata_json} for r in rows]})
    finally:
        db.close()


async def knowledge_add(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        r = KnowledgeSource(title=p.get("title",""), source_type=p.get("source_type","manual"), url=p.get("url"),
                            reliability_score=p.get("reliability_score"), verified=False,
                            notes=(p.get("notes","") + " | Verification pending admin review.").strip(),
                            metadata_json={"concept_keys": p.get("concept_keys", [])})
        db.add(r); db.commit(); db.refresh(r)
        return J({"id": r.id, "title": r.title, "verified": False})
    finally:
        db.close()


async def knowledge_verify(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        if not getattr(user, "is_admin", False): return J({"error": "admin_verification_required"}, 403)
        source_id = int(request.path_params["source_id"])
        source = db.get(KnowledgeSource, source_id)
        if source is None: return J({"error": "knowledge_source_not_found"}, 404)
        p = await body(request)
        if not (source.url or "").startswith("https://"): return J({"error": "https_source_url_required"}, 400)
        from app.knowledge.base import SEED_CONCEPTS
        keys = p.get("concept_keys", [])
        dynamic_keys = db.execute(select(KnowledgeConceptRecord.key)).scalars().all()
        valid = {c.key for c in SEED_CONCEPTS} | set(dynamic_keys)
        if not keys or any(k not in valid for k in keys): return J({"error": "unknown_or_missing_concept_key"}, 400)
        score = float(p.get("reliability_score", 0))
        notes = str(p.get("verification_notes", ""))
        if score < 0.7 or len(notes) < 20: return J({"error": "verification_evidence_insufficient"}, 400)
        source.verified = True
        source.reliability_score = score
        source.notes = notes
        source.metadata_json = {"concept_keys": keys, "verification_method": "manual_admin_review",
                                "verified_by": getattr(user, "id", None), "verified_at": datetime.now(timezone.utc).isoformat()}
        db.add(source); db.commit()
        return J({"ok": True, "id": source.id, "verified": True})
    finally:
        db.close()


async def knowledge_coverage(request: Request):
    db = db_sess()
    try:
        from app.knowledge.base import coverage_report
        return J(coverage_report(db))
    finally:
        db.close()


async def knowledge_concept_add(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        if not getattr(user, "is_admin", False): return J({"error": "admin_concept_creation_required"}, 403)
        p = await body(request)
        key = str(p.get("key", ""))
        if len(key) < 3 or len(key) > 128 or not all(c.islower() or c.isdigit() or c == "_" for c in key):
            return J({"error": "invalid_concept_key"}, 400)
        from app.knowledge.base import SEED_CONCEPTS
        existing = {c.key for c in SEED_CONCEPTS} | set(db.execute(select(KnowledgeConceptRecord.key)).scalars().all())
        if key in existing: return J({"error": "knowledge_concept_key_exists"}, 409)
        summary = str(p.get("summary", ""))
        if len(summary) < 20: return J({"error": "concept_summary_too_short"}, 400)
        row = KnowledgeConceptRecord(key=key, category=str(p.get("category", "general")),
            title=str(p.get("title", "")), summary=summary, details=p.get("details", []), tags=p.get("tags", []),
            caution=str(p.get("caution", "")), confidence_note=str(p.get("confidence_note", "Pending source verification and testing.")),
            confidence=0.0, metadata_json={"verified": False})
        db.add(row); db.commit(); db.refresh(row)
        return J({"id": row.id, "key": row.key, "verified": False})
    finally:
        db.close()


async def knowledge_concepts(request: Request):
    db = db_sess()
    try:
        from app.knowledge.base import categories, list_concepts, coverage_report
        return J({"categories": categories(db), "items": list_concepts(category=request.query_params.get("category"), query=request.query_params.get("q"), db=db), "coverage": coverage_report(db)})
    finally:
        db.close()


async def knowledge_source_catalog(request: Request):
    from app.knowledge.base import source_catalog
    return J({"items": source_catalog()})


async def learning_list(request: Request):
    db = db_sess()
    try:
        rows = db.execute(select(LearningRecord).order_by(desc(LearningRecord.id)).limit(200)).scalars().all()
        return J({"items": [{"id": r.id, "category": r.category, "subject": r.subject, "outcome": r.outcome, "lesson": r.lesson, "verified": r.verified, "environment_mode": r.environment_mode, "market_type": r.market_type} for r in rows]})
    finally:
        db.close()


async def learning_add(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        r = LearningRecord(category=p.get("category",""), subject=p.get("subject",""), lesson=p.get("lesson",""), outcome=p.get("outcome"), environment_mode=p.get("environment_mode"), market_type=p.get("market_type"), verified=bool(p.get("verified")))
        db.add(r); db.commit(); db.refresh(r)
        return J({"id": r.id, "subject": r.subject})
    finally:
        db.close()


async def auth_status(request: Request):
    db = db_sess()
    try:
        from app.models.entities import AppUser
        has_user = db.execute(select(AppUser.id).limit(1)).first() is not None
        return J({"auth_required": settings.auth_required, "allowlist_configured": bool(auth_service.get_allowed_emails()) or bool(settings.allowed_emails), "has_user": has_user,
                  "note": "Set initial password locally with backend script. Never send passwords in chat."})
    finally:
        db.close()


async def auth_login(request: Request):
    db = db_sess()
    try:
        p = await body(request)
        user = auth_service.authenticate(db, p.get("email",""), p.get("password",""))
        if not user:
            db.commit()
            return J({"detail": "Invalid credentials, email not allowed, or account locked"}, 401)
        token = auth_service.create_session(db, user, ttl_hours=settings.session_ttl_hours, ip_address=request.client.host if request.client else None, user_agent=request.headers.get("user-agent"))
        db.commit()
        return J({"ok": True, "token": token, "email": user.email, "token_type": "bearer"})
    finally:
        db.close()


async def auth_logout(request: Request):
    db = db_sess()
    try:
        token = _bearer(request)
        ok = auth_service.revoke_session(db, token) if token else False
        db.commit()
        return J({"ok": ok})
    finally:
        db.close()


async def auth_me(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err and settings.auth_required: return err
        if not user:
            return J({"authenticated": False, "auth_required": settings.auth_required})
        return J({"authenticated": True, "email": user.email, "is_admin": user.is_admin, "two_factor_enabled": user.two_factor_enabled})
    finally:
        db.close()


async def config_changes(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        rows = db.execute(select(ConfigChange).order_by(desc(ConfigChange.id)).limit(100)).scalars().all()
        return J({"items": [{"id": r.id, "created_at": r.created_at.isoformat(), "actor": r.actor, "scope": r.scope, "key": r.key, "approved": r.approved, "reason": r.reason} for r in rows]})
    finally:
        db.close()


async def chat(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        msg = (p.get("message") or "").strip()
        low = msg.lower()
        state = core_service.get_state(db)
        decisions = db.execute(select(DecisionRecord).order_by(desc(DecisionRecord.id)).limit(5)).scalars().all()
        from app.knowledge.base import list_concepts
        if not msg:
            reply = "اكتب سؤالك عن حالة النظام، القرارات، الاستراتيجيات، المخاطر، أو التحليل."
        elif any(k in low for k in ["حالة", "status", "يعمل", "متوقف", "demo", "live", "spot", "futures", "earn"]):
            reply = f"حالة النظام: البيئة={state['environment_mode']}، السوق={state['market_type']}، مستقل={state['autonomous_enabled']}، إيقاف طوارئ={state['emergency_stop']}. Demo→Live تلقائي معطل؛ لا صلاحيات سحب."
        elif any(k in low for k in ["قرار", "decision", "لماذا", "why", "صفقة", "trade"]):
            if decisions:
                d = decisions[0]
                reply = f"آخر قرار: {d.symbol} → {d.action} (استراتيجية {d.strategy}, ثقة {d.confidence}, مصدر {d.data_source}). السبب: {d.rationale}"
            else:
                reply = "لا توجد قرارات مسجلة بعد. شغّل تحليلًا من Market Scanner."
        elif any(k in low for k in ["استرات", "strategy"]):
            reply = "الاستراتيجيات: " + ", ".join([f"{s['name']}[{s['status']}]" for s in core_service.strategies()[:8]])
        elif any(k in low for k in ["مخاطر", "risk", "رافعة", "رسوم", "امتثال", "compliance"]):
            reply = f"حدود الأمان: {state.get('risk_limits',{})}. محرك الامتثال يسبق أي تنفيذ؛ Live يتطلب تمكينًا صريحًا وتحقق شروط؛ السحب/التحويل ممنوعان."
        elif any(k in low for k in ["تشخيص", "diagnosis", "خطأ", "error", "مشكلة", "issue", "إصلاح", "heal", "صحة", "health"]):
            from app.services.self_diagnosis import get_engine
            engine = get_engine()
            report = engine.run_full_check()
            if any(k in low for k in ["أصلح", "fix", "heal", "repair"]):
                healed = []
                for issue in report.get("issues", []):
                    h = engine.attempt_auto_heal(issue)
                    if h.get("healed"):
                        healed.append(h)
                reply = "تشخيص: " + report["overall"] + ". مشكلات: " + str(len(report["issues"])) + ". مُصلحة تلقائياً: " + str(len(healed)) + "."
            else:
                reply = f"تشخيص النظام: حالة={report['overall']}. مكونات: {len(report['components'])}. مشكلات: {len(report['issues'])}. " + engine.get_summary_text()
        elif any(k in low for k in ["bos", "choch", "سيولة", "liquidity", "اختراق", "breakout", "شمعة", "candle", "rsi", "macd"]):
            concepts = list_concepts(query=msg)[:3]
            reply = " | ".join([f"{c['title']}: {c['summary']}" for c in concepts]) if concepts else "جرّب: BOS, CHOCH, liquidity, breakout, RSI, MACD."
        else:
            reply = "مساعد TITAN مرتبط ببيانات النظام. اسأل عن الحالة، القرارات، الاستراتيجيات، المخاطر/الامتثال، أو مفاهيم التحليل. التكامل مع LLM خارجي اختياري ويخضع للأمان."
        return J({"reply": reply, "grounded": True, "used_external_llm": False})
    finally:
        db.close()


async def ai_providers(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        rows = list_configs(db)
        return J({"supported_providers": sorted(SUPPORTED_PROVIDERS), "items": [{"id": r.id, "name": r.name, "provider": r.provider, "model": r.model, "api_key_ref_set": bool(r.api_key_ref), "enabled": r.enabled, "priority": r.priority, "tasks": r.tasks or []} for r in rows]})
    finally:
        db.close()


async def ai_provider_create(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        if p.get("provider") not in SUPPORTED_PROVIDERS: return J({"detail": "unsupported provider"}, 400)
        row = AIProviderConfig(name=p.get("name",""), provider=p.get("provider"), model=p.get("model",""), base_url=p.get("base_url"), api_key_ref=p.get("api_key_ref"), enabled=bool(p.get("enabled")), priority=int(p.get("priority",100)), tasks=p.get("tasks") or [])
        db.add(row); db.commit(); db.refresh(row)
        return J({"id": row.id})
    finally:
        db.close()


async def ai_provider_test(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        cfg = db.get(AIProviderConfig, int(request.path_params["provider_id"]))
        if not cfg: return J({"detail": "not found"}, 404)
        result = invoke_provider(cfg, [{"role": "user", "content": "Reply with: TITAN_OK"}], task="test")
        record_usage(db, cfg, "test", result); db.commit()
        return J(result.to_dict())
    finally:
        db.close()


async def ai_research(request: Request):
    return J({"checked_at_note": "Web lookups performed in-session; verify current terms/pricing/access before relying on them. Not live-tested without API keys.",
              "sources": [
                  {"provider": "Anthropic", "urls": ["https://www.anthropic.com/legal/supported-regions", "https://platform.claude.com/docs/en/about-claude/pricing"], "algeria_note": "Retrieved supported-regions page listed Algeria; verify directly."},
                  {"provider": "OpenAI", "urls": ["https://developers.openai.com/api/docs/supported-countries.md", "https://openai.com/api/pricing/"], "algeria_note": "Retrieved supported-countries markdown included Algeria; verify pricing/models/terms directly."},
                  {"provider": "Google Gemini API", "urls": ["https://ai.google.dev/gemini-api/docs/available-regions", "https://ai.google.dev/gemini-api/docs/pricing"], "algeria_note": "Could not conclusively confirm Algeria from retrieved content; verify directly."},
                  {"provider": "Mistral", "urls": ["https://mistral.ai/pricing", "https://docs.mistral.ai/getting-started/models/"], "algeria_note": "Verify directly."},
                  {"provider": "DeepSeek", "urls": ["https://api-docs.deepseek.com/quick_start/pricing"], "algeria_note": "Verify directly."},
                  {"provider": "xAI", "urls": ["https://docs.x.ai/developers/models"], "algeria_note": "Verify directly."},
              ],
              "caveat": "No model is connected and no feature works until configured with valid credentials and tested successfully."})


async def compliance_check(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        g = PreTradeOrderGateway()
        r = g.validate(symbol=p.get("symbol","BTC/USDT"), market=MarketType(p.get("market_type","spot")), side="buy", order_type="limit",
                       quantity=0.001, price=1.0, reference_price=1.0, environment_mode=p.get("environment_mode","demo"), live_enabled=False)
        if not r.ok:
            log_event(db, action="compliance.block", severity="warning", message=r.reason, details=r.normalized,
                      environment_mode=p.get("environment_mode"), market_type=p.get("market_type")); db.commit()
        return J({"gateway": r.to_dict(), "sources": ["https://www.binance.com/en/terms", "https://www.binance.com/en/terms-api", "https://developers.binance.com/"],
                  "note": "Software precheck only. Verify official Binance terms/policies, eligibility, KYC, geo restrictions, symbol filters, and API limits before live operations."})
    finally:
        db.close()



async def master_start(request):
    from starlette.responses import JSONResponse as J
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        return J(core_service.start_bot(db, account_target=p.get("account_target"), live_confirm=bool(p.get("live_confirm"))))
    except Exception as e:
        return J({"detail": str(e)}, 400)
    finally:
        db.close()

async def master_stop(request):
    from starlette.responses import JSONResponse as J
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        return J(core_service.stop_bot(db, reason=p.get("reason","user_stop"), close_positions=bool(p.get("close_positions"))))
    except Exception as e:
        return J({"detail": str(e)}, 400)
    finally:
        db.close()

async def master_emergency(request):
    from starlette.responses import JSONResponse as J
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        return J(core_service.set_state(db, emergency_stop=True))
    finally:
        db.close()




shadow_service = ShadowTradingService()

async def shadow_order(request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        res = shadow_service.create_shadow_order(db, env=p.get("environment_mode","demo"), market=p.get("market_type","spot"),
            symbol=p.get("symbol","BTC/USDT"), side=p.get("side","buy"), order_type=p.get("order_type","limit"),
            quantity=float(p.get("quantity",0)), price=p.get("price"), reference_price=p.get("reference_price"),
            idempotency_key=p.get("idempotency_key"), simulate=p.get("simulate","fill"), fill_ratio=float(p.get("fill_ratio",1.0)),
            fee_rate=float(p.get("fee_rate",0.001)), mark_price=p.get("mark_price"))
        db.commit()
        return J({"ok": res.ok, "message": res.message, "details": res.details,
                  "order": {"id": res.order.id, "status": res.order.status, "filled_quantity": res.order.filled_quantity, "fees_paid": res.order.fees_paid, "idempotency_key": res.order.idempotency_key} if res.order else None,
                  "position": {"id": res.position.id, "quantity": res.position.quantity, "entry_avg_price": res.position.entry_avg_price, "unrealized_pnl": res.position.unrealized_pnl} if res.position else None})
    except Exception as e:
        db.rollback(); return J({"detail": str(e)}, 400)
    finally:
        db.close()

async def portfolio(request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err and settings.auth_required: return err
        return J(shadow_service.get_portfolio(db, env=request.query_params.get("environment_mode","demo"), market=request.query_params.get("market_type","spot")))
    finally:
        db.close()


async def shadow_close(request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        res = shadow_service.close_shadow_position(db, position_id=int(p.get("position_id")), close_price=float(p.get("close_price")), fee_rate=float(p.get("fee_rate",0.001)))
        db.commit(); return J(res)
    except Exception as e:
        db.rollback(); return J({"detail": str(e)}, 400)
    finally:
        db.close()





async def self_diagnosis(request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err and settings.auth_required: return err
        engine = get_engine()
        report = engine.run_full_check()
        # Attempt auto-heal for recoverable issues
        for issue in report.get("issues", []):
            heal = engine.attempt_auto_heal(issue)
            if heal.get("healed"):
                report.setdefault("healed", []).append(heal)
        # Log to audit
        log_event(db, action="self_diagnosis.run", entity_type="system", details={"overall": report["overall"], "issue_count": len(report["issues"])})
        db.commit()
        return J(report)
    except Exception as e:
        db.rollback()
        return J({"detail": str(e)}, 500)
    finally:
        db.close()


async def download_zip(request):
    zip_path = Path('/storage/emulated/0/Android/data/com.androidharness.app/files/workspace/TITAN_SUPER_AI_PREMIUM_COMPLETE.zip')
    if not zip_path.exists():
        return JSONResponse({"error":"not found"}, status_code=404)
    resp = FileResponse(str(zip_path), filename='TITAN_SUPER_AI_PREMIUM_COMPLETE.zip', media_type='application/octet-stream')
    resp.headers['Content-Disposition'] = 'attachment; filename="TITAN_SUPER_AI_PREMIUM_COMPLETE.zip"'
    return resp


async def backup_info(request):
    db_path = settings.database_url.replace('sqlite:///', '')
    return J({
        "db_path": db_path,
        "backup_instructions": "انسخ ملف قاعدة البيانات وملف بيانات الاعتماد المشفرة (backend/data/binance_testnet_creds.json) من التخزين الدائم للاستضافة.",
        "note": "على الاستضافة المجانية قد لا يتوفر تخزين دائم أو قد يُحذف عند إعادة النشر - تحقق من إعدادات Volume/Disk."
    })


async def export_formats(request):
    libs = {}
    for m in ['openpyxl','reportlab','xlsxwriter']:
        try: __import__(m); libs[m]=True
        except Exception: libs[m]=False
    return J({"formats": {"csv": True, "xlsx": libs['openpyxl'] or libs['xlsxwriter'], "pdf": libs['reportlab']},
              "available_libraries": libs,
              "note": "CSV export is implemented. XLSX/PDF require optional libraries in the target environment; install and extend export service if needed."})


# Binance Testnet (Demo external) - NO real keys, NO live
def _get_binance_adapter(market: str = None):
    stored = load_testnet_credentials()
    mkt = (market or stored.get('market') or os.getenv('BINANCE_TESTNET_MARKET', 'spot')).lower()
    if mkt not in {'spot', 'futures'}:
        mkt = 'spot'
    # Stored credentials are valid only for the exact market they were saved for.
    if stored.get('configured') and stored.get('market', 'spot') == mkt:
        return BinanceTestnetAdapter(BinanceConfig(
            enabled=True, environment='testnet', market=mkt,
            api_key_ref='stored:api_key', api_secret_ref='stored:api_secret'
        ))
    prefix = 'BINANCE_FUTURES_TESTNET' if mkt == 'futures' else 'BINANCE_SPOT_TESTNET'
    key_name, secret_name = prefix + '_API_KEY', prefix + '_API_SECRET'
    key, secret = os.getenv(key_name), os.getenv(secret_name)
    # Backward-compatible generic variables are accepted only for their explicitly selected market.
    if not (key and secret) and os.getenv('BINANCE_TESTNET_MARKET', 'spot').lower() == mkt:
        key, secret = os.getenv('BINANCE_TESTNET_API_KEY'), os.getenv('BINANCE_TESTNET_API_SECRET')
        if key and secret:
            key_name, secret_name = 'BINANCE_TESTNET_API_KEY', 'BINANCE_TESTNET_API_SECRET'
    configured = bool(key and secret)
    return BinanceTestnetAdapter(BinanceConfig(
        enabled=configured, environment='testnet', market=mkt,
        api_key_ref='env:' + key_name if configured else None,
        api_secret_ref='env:' + secret_name if configured else None,
    ))



async def connect_page(request):
    # In production, require auth before exposing control UI
    try:
        db = db_sess()
        try:
            user, err = require_user(request, db)
            if err and settings.auth_required:
                return HTMLResponse("<h2>Authentication required</h2><p>Login via /api/auth/login first.</p>", status_code=401)
        finally:
            db.close()
    except Exception:
        pass
    try:
        p = Path(__file__).resolve().parent / 'static_connect.html'
        return HTMLResponse(p.read_text(encoding='utf-8'))
    except Exception as e:
        return HTMLResponse(f"<h1>Error</h1><pre>{e}</pre>", status_code=500)


async def binance_testnet_status(request):
    auth_error = _binance_auth_error(request)
    if auth_error: return auth_error
    try:
        market = request.query_params.get('market')
        return J(_get_binance_adapter(market).status())
    except Exception as e:
        return J({"ok": False, "error": str(e)}, 400)

def _map_testnet_order_status(result: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    response = result.get("response") if isinstance(result.get("response"), dict) else {}
    if result.get("order_status_uncertain") or result.get("error") == "order_status_uncertain_blocked":
        return "uncertain", response
    exchange_status = str(response.get("status", "")).upper()
    status_map = {"NEW": "submitted", "PARTIALLY_FILLED": "partially_filled", "FILLED": "filled",
                  "CANCELED": "cancelled", "CANCELLED": "cancelled", "REJECTED": "rejected", "EXPIRED": "cancelled"}
    if exchange_status in status_map:
        return status_map[exchange_status], response
    if result.get("sent_to_exchange") or result.get("duplicate"):
        return "submitted", response
    return ("rejected" if result.get("error") in {"pretrade_blocked", "testnet_adapter_disabled", "testnet_credentials_required"} else "failed"), response


async def binance_testnet_order(request):
    db = db_sess()
    order = None
    try:
        user, err = require_user(request, db)
        if err: return err
        state = db.get(SystemState, 1)
        if state is None:
            return J({"ok": False, "error": "system_state_unavailable", "new_orders_blocked": True}, 503)
        if state.emergency_stop:
            return J({"ok": False, "error": "emergency_stop_active", "new_orders_blocked": True}, 423)
        if (state.status_summary or {}).get("binance_testnet_reconciliation_blocked"):
            return J({"ok": False, "error": "testnet_reconciliation_required", "new_orders_blocked": True}, 423)

        payload = await body(request)
        market = str(payload.get("market", "spot")).lower()
        if market not in {"spot", "futures"}:
            return J({"ok": False, "error": "unsupported_testnet_market"}, 400)
        symbol = str(payload.get("symbol", "BTCUSDT")).strip().upper()
        side = str(payload.get("side", "BUY")).strip().upper()
        order_type = str(payload.get("order_type", "MARKET")).strip().upper()
        quantity = float(payload.get("quantity", 0))
        price = float(payload["price"]) if payload.get("price") is not None else None
        idempotency_key = str(payload.get("idempotency_key", "")).strip()
        reduce_only = bool(payload.get("reduce_only", False))
        if not idempotency_key:
            return J({"ok": False, "error": "valid_idempotency_key_required"}, 400)

        order = db.execute(select(OrderRecord).where(OrderRecord.idempotency_key == idempotency_key)).scalar_one_or_none()
        if order is not None:
            if order.shadow:
                return J({"ok": False, "error": "idempotency_key_reused_for_non_testnet_order"}, 409)
            same_order = (
                order.market_type == market
                and order.symbol.replace("/", "").upper() == symbol.replace("/", "").upper()
                and order.side.lower() == side.lower()
                and order.order_type.lower() == order_type.lower()
                and abs(float(order.quantity) - quantity) <= 1e-12
                and ((order.price is None and price is None) or
                     (order.price is not None and price is not None and abs(float(order.price) - price) <= 1e-12))
                and bool((order.metadata_json or {}).get("reduce_only", False)) == reduce_only
            )
            if not same_order:
                return J({"ok": False, "error": "idempotency_key_reused_for_different_order"}, 409)
            if order.status in {"filled", "cancelled", "rejected", "failed"}:
                return J({"ok": True, "duplicate": True, "sent_to_exchange": False,
                          "local_order_id": order.id, "local_status": order.status})

        unresolved = db.execute(select(OrderRecord).where(
            OrderRecord.shadow.is_(False), OrderRecord.market_type == market,
            OrderRecord.status.in_(["pending", "uncertain"]),
        )).scalars().all()
        if any(o.idempotency_key != idempotency_key for o in unresolved):
            return J({"ok": False, "error": "unresolved_testnet_order_status", "new_orders_blocked": True,
                      "unresolved_order_ids": [o.id for o in unresolved if o.idempotency_key != idempotency_key]}, 423)

        if order is None:
            order = OrderRecord(environment_mode="demo", market_type=market, symbol=symbol, side=side.lower(),
                                order_type=order_type.lower(), quantity=quantity, price=price, status="pending",
                                shadow=False, idempotency_key=idempotency_key, client_order_id=idempotency_key,
                                reason="Testnet submission prepared; remote state must be reconciled by client order ID.",
                                metadata_json={"testnet": True, "adapter": "binance_testnet", "reduce_only": reduce_only})
            db.add(order)
            db.commit()
            db.refresh(order)

        adapter = _get_binance_adapter(market)
        try:
            if reduce_only:
                result = adapter.close_position(symbol=symbol, side=side, quantity=quantity,
                                                reference_price=payload.get("reference_price"),
                                                idempotency_key=idempotency_key)
            else:
                result = adapter.place_order(symbol=symbol, side=side, order_type=order_type, quantity=quantity,
                                             price=price, reference_price=payload.get("reference_price"),
                                             idempotency_key=idempotency_key)
        except Exception as exc:
            order.status = "uncertain"
            order.reason = "Adapter raised after submission preparation; reconcile before any retry."
            order.metadata_json = {**(order.metadata_json or {}), "adapter_exception": type(exc).__name__}
            db.add(order); db.commit()
            return J({"ok": False, "error": "testnet_submission_uncertain", "new_orders_blocked": True,
                      "local_order_id": order.id}, 503)

        local_status, response = _map_testnet_order_status(result)
        order.status = local_status
        order.exchange_order_id = str(response.get("orderId")) if response.get("orderId") is not None else order.exchange_order_id
        order.client_order_id = str(response.get("clientOrderId") or idempotency_key)
        try:
            order.filled_quantity = float(response.get("executedQty", order.filled_quantity or 0) or 0)
            avg_price = response.get("avgPrice") or response.get("price")
            if avg_price not in (None, "", "0", 0): order.avg_fill_price = float(avg_price)
        except (TypeError, ValueError):
            pass
        order.reason = str(result.get("error") or response.get("status") or "Testnet adapter result recorded")[:500]
        order.metadata_json = {**(order.metadata_json or {}), "last_adapter_result": result}
        db.add(order); db.commit(); db.refresh(order)
        return J({**result, "local_order_id": order.id, "local_status": order.status})
    except Exception as exc:
        if order is not None:
            try:
                order.status = "uncertain"
                order.reason = "Unhandled route exception; remote state must be reconciled before retry."
                db.add(order); db.commit()
            except Exception:
                db.rollback()
        return J({"ok": False, "error": str(exc), "new_orders_blocked": bool(order)}, 400)
    finally:
        db.close()



async def binance_testnet_account(request):
    auth_error = _binance_auth_error(request)
    if auth_error: return auth_error
    try:
        market = request.query_params.get('market')
        return J(_get_binance_adapter(market).get_account())
    except Exception as e:
        return J({"ok": False, "error": str(e)}, 400)



async def binance_testnet_reconcile(request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        market = (request.query_params.get("market") or "spot").lower()
        if market not in {"spot", "futures"}:
            return J({"ok": False, "error": "unsupported_testnet_market"}, 400)
        adapter = _get_binance_adapter(market)
        local_rows = db.execute(select(OrderRecord).where(
            OrderRecord.shadow.is_(False), OrderRecord.market_type == market,
            OrderRecord.status.in_(["pending", "submitted", "partially_filled", "uncertain"]),
        )).scalars().all()
        local_orders = [{"id": o.idempotency_key, "clientOrderId": o.client_order_id,
                         "orderId": o.exchange_order_id, "symbol": o.symbol} for o in local_rows]
        result = adapter.reconcile(local_open_orders=local_orders)
        state = db.get(SystemState, 1)
        if state is not None:
            summary = dict(state.status_summary or {})
            if result.get("ok"):
                summary.pop("binance_testnet_reconciliation_blocked", None)
                summary.pop("binance_testnet_reconciliation_reason", None)
            else:
                summary["binance_testnet_reconciliation_blocked"] = True
                summary["binance_testnet_reconciliation_reason"] = result.get("action") or result.get("error")
            state.status_summary = summary
            db.add(state)
            db.commit()
        if not result.get("ok"):
            result["new_orders_blocked"] = True
        return J(result)
    except Exception as exc:
        return J({"ok": False, "error": str(exc), "new_orders_blocked": True}, 400)
    finally:
        db.close()



async def binance_testnet_orders(request):
    auth_error = _binance_auth_error(request)
    if auth_error: return auth_error
    try:
        market = request.query_params.get('market')
        symbol = request.query_params.get('symbol')
        return J(_get_binance_adapter(market).get_open_orders(symbol))
    except Exception as e:
        return J({"ok": False, "error": str(e)}, 400)


async def binance_testnet_close(request):
    payload = await body(request)
    payload["reduce_only"] = True

    class _CloseRequestProxy:
        def __init__(self, original, data):
            self._original = original
            self._data = data
        def __getattr__(self, name):
            return getattr(self._original, name)
        async def body(self):
            return json.dumps(self._data).encode("utf-8")

    return await binance_testnet_order(_CloseRequestProxy(request, payload))


async def binance_testnet_save(request):
    auth_error = _binance_auth_error(request)
    if auth_error: return auth_error
    try:
        p = await body(request)
        api_key = (p.get('api_key') or '').strip()
        api_secret = (p.get('api_secret') or '').strip()
        market = p.get('market', 'spot')
        if not api_key or not api_secret:
            return J({"ok": False, "error": "api_key_and_secret_required"}, 400)
        res = save_testnet_credentials(api_key, api_secret, market)
        # Test immediately
        adapter = _get_binance_adapter(market)
        status = adapter.status()
        return J({"ok": True, "saved": True, "test_status": status, "note": "Keys stored encrypted server-side. Secret not returned."})
    except Exception as e:
        return J({"ok": False, "error": str(e)}, 400)

async def binance_testnet_delete(request):
    auth_error = _binance_auth_error(request)
    if auth_error: return auth_error
    try:
        res = delete_testnet_credentials()
        return J(res)
    except Exception as e:
        return J({"ok": False, "error": str(e)}, 400)

async def binance_testnet_creds_status(request):
    auth_error = _binance_auth_error(request)
    if auth_error: return auth_error
    return J(creds_public_status())

async def engines_list_detailed(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        return J({"engines": core_service.get_engines_detailed(db)})
    finally:
        db.close()


async def engine_control(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        key = request.path_params.get("engine_key") or p.get("key")
        action = p.get("action") or request.query_params.get("action")
        res = core_service.control_engine(db, key, action, user=user.email if user else "system")
        return J(res)
    except Exception as e:
        return J({"detail": str(e)}, 400)
    finally:
        db.close()


async def export_csv(request):
    import csv, io
    from starlette.responses import Response
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err and settings.auth_required: return err
        kind = request.query_params.get("kind","orders")
        env = request.query_params.get("environment_mode","demo"); market = request.query_params.get("market_type","spot")
        buf = io.StringIO(); w = csv.writer(buf)
        if kind == "positions":
            rows = db.execute(select(PositionRecord).where(PositionRecord.environment_mode==env, PositionRecord.market_type==market)).scalars().all()
            w.writerow(["id","symbol","side","quantity","entry_avg_price","mark_price","unrealized_pnl","realized_pnl","fees_total","status","shadow"])
            for r in rows: w.writerow([r.id,r.symbol,r.side,r.quantity,r.entry_avg_price,r.mark_price,r.unrealized_pnl,r.realized_pnl,r.fees_total,r.status,r.shadow])
        else:
            rows = db.execute(select(OrderRecord).where(OrderRecord.environment_mode==env, OrderRecord.market_type==market)).scalars().all()
            w.writerow(["id","symbol","side","order_type","quantity","filled_quantity","price","avg_fill_price","status","fees_paid","shadow","idempotency_key"])
            for r in rows: w.writerow([r.id,r.symbol,r.side,r.order_type,r.quantity,r.filled_quantity,r.price,r.avg_fill_price,r.status,r.fees_paid,r.shadow,r.idempotency_key])
        return Response(buf.getvalue(), media_type="text/csv; charset=utf-8", headers={"Content-Disposition": f'attachment; filename="{kind}_{env}_{market}.csv"'})
    finally:
        db.close()

routes = [
    Route("/", connect_page),
    Route("/connect", connect_page),
    Route("/api/health", health),
    Route("/api/system/status", system_status),
    Route("/api/system/state", update_state, methods=["POST"]),
    Route("/api/strategies", strategies),
    Route("/api/analysis/decision", analyze, methods=["POST"]),
    Route("/api/decisions", list_decisions),
    Route("/api/audit", list_audit),
    Route("/api/knowledge", knowledge_list),
    Route("/api/knowledge", knowledge_add, methods=["POST"]),
    Route("/api/knowledge/{source_id:int}/verify", knowledge_verify, methods=["POST"]),
    Route("/api/knowledge/coverage", knowledge_coverage),
    Route("/api/knowledge/catalog", knowledge_source_catalog),
    Route("/api/knowledge/concepts", knowledge_concepts),
    Route("/api/knowledge/concepts", knowledge_concept_add, methods=["POST"]),
    Route("/api/learning", learning_list),
    Route("/api/learning", learning_add, methods=["POST"]),
    Route("/api/auth/status", auth_status),
    Route("/api/auth/login", auth_login, methods=["POST"]),
    Route("/api/auth/logout", auth_logout, methods=["POST"]),
    Route("/api/auth/me", auth_me),
    Route("/api/config/changes", config_changes),
    Route("/api/chat", chat, methods=["POST"]),
    Route("/api/ai/providers", ai_providers),
    Route("/api/ai/providers", ai_provider_create, methods=["POST"]),
    Route("/api/ai/providers/{provider_id:int}/test", ai_provider_test, methods=["POST"]),
    Route("/api/ai/research", ai_research),
    Route("/api/compliance/check-order", compliance_check, methods=["POST"]),
    Route("/api/master/start", master_start, methods=["POST"]),
    Route("/api/master/stop", master_stop, methods=["POST"]),
    Route("/api/master/emergency-stop", master_emergency, methods=["POST"]),
    Route("/api/shadow/order", shadow_order, methods=["POST"]),
    Route("/api/portfolio", portfolio),
    Route("/api/export/csv", export_csv),
    Route("/api/export/formats", export_formats),
    Route("/api/self-diagnosis", self_diagnosis),
    Route("/api/backup/info", backup_info),
    Route("/download", download_zip),
    Route("/api/shadow/close", shadow_close, methods=["POST"]),
    Route("/api/engines", engines_list_detailed),
    Route("/api/engines/detailed", engines_list_detailed),
    Route("/api/engines/{engine_key}/control", engine_control, methods=["POST"]),
    Route("/api/engine/control", engine_control, methods=["POST"]),
    Route("/api/binance/testnet/status", binance_testnet_status),
    Route("/api/binance/testnet/creds", binance_testnet_creds_status),
    Route("/api/binance/testnet/save", binance_testnet_save, methods=["POST"]),
    Route("/api/binance/testnet/delete", binance_testnet_delete, methods=["POST"]),
    Route("/api/binance/testnet/order", binance_testnet_order, methods=["POST"]),
    Route("/api/binance/testnet/close", binance_testnet_close, methods=["POST"]),
    Route("/api/binance/testnet/account", binance_testnet_account),
    Route("/api/binance/testnet/orders", binance_testnet_orders),
    Route("/api/binance/testnet/reconcile", binance_testnet_reconcile),
]


from contextlib import asynccontextmanager

@asynccontextmanager
async def lifespan(app):
    dbmod.init_db()
    db = dbmod.SessionLocal()
    try:
        core_service.ensure_bootstrap(db)
    finally:
        db.close()
    yield

def create_star_app() -> Starlette:
    app = Starlette(routes=routes, lifespan=lifespan)
    origins = [o.strip() for o in (settings.allowed_origins or "*").split(",") if o.strip()]
    app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False, allow_methods=["*"], allow_headers=["*"])
    return app

def _startup():
    # kept for compatibility
    pass


app = create_star_app()
