"""Binance Adapter - Testnet/Demo only. NO Live trading, NO withdrawal permissions.
- Spot Testnet: https://testnet.binance.vision
- Futures Testnet: https://testnet.binancefuture.com
All requests routed ONLY to testnet endpoints. Live URLs are blocked.
"""
from __future__ import annotations

import hashlib
import hmac
import json
from math import isfinite
import os
import time
import urllib.parse
import urllib.request
import urllib.error
from dataclasses import dataclass
from typing import Any

from app.core.enums import MarketType
from app.engines.compliance import compliance_engine
from app.engines.order_gateway import PreTradeOrderGateway
from app.data.binance_public import BinancePublicData


SPOT_TESTNET_BASE = "https://testnet.binance.vision"
FUTURES_TESTNET_BASE = "https://testnet.binancefuture.com"
ALLOWED_BASES = {SPOT_TESTNET_BASE, FUTURES_TESTNET_BASE}


def _resolve_secret(ref: str | None) -> str | None:
    if not ref:
        return None
    if ref.startswith("env:"):
        return os.getenv(ref[4:], "") or None
    if ref.startswith("stored:"):
        try:
            from app.services.credentials import load_testnet_credentials
            c = load_testnet_credentials()
            if ref == "stored:api_key":
                return c.get("api_key") or None
            if ref == "stored:api_secret":
                return c.get("api_secret") or None
        except Exception:
            return None
    return ref


def _sign(params: dict, secret: str) -> str:
    query = urllib.parse.urlencode(params)
    return hmac.new(secret.encode(), query.encode(), hashlib.sha256).hexdigest()


@dataclass
class BinanceConfig:
    enabled: bool = False
    environment: str = "testnet"  # testnet only for external; demo for internal shadow
    market: str = "spot"  # spot or futures
    api_key_ref: str | None = None  # env:BINANCE_TESTNET_API_KEY
    api_secret_ref: str | None = None  # env:BINANCE_TESTNET_API_SECRET
    # base_url is determined by market + testnet; never use live


class BinanceTestnetAdapter:
    name = "binance_testnet"

    def __init__(self, config: BinanceConfig | None = None):
        self.config = config or BinanceConfig()
        self.gateway = PreTradeOrderGateway()
        self.public_data = BinancePublicData()

    def _base_url(self) -> str:
        if self.config.market == "futures":
            return FUTURES_TESTNET_BASE
        return SPOT_TESTNET_BASE

    def _api_key(self) -> str | None:
        return _resolve_secret(self.config.api_key_ref)

    def _api_secret(self) -> str | None:
        return _resolve_secret(self.config.api_secret_ref)

    def _request(self, method: str, path: str, signed: bool = False, params: dict | None = None) -> dict:
        base = self._base_url()
        if base not in ALLOWED_BASES:
            raise RuntimeError("live_or_unapproved_endpoint_blocked")
        url = base + path
        params = dict(params or {})
        headers = {"User-Agent": "TITAN-AI-PREMIUM/1.0"}
        key = self._api_key()
        secret = self._api_secret()
        if key:
            headers["X-MBX-APIKEY"] = key
        if signed:
            if not secret:
                raise RuntimeError("missing_api_secret_for_signed_request")
            params["timestamp"] = int(time.time() * 1000)
            params.setdefault("recvWindow", 5000)
            params["signature"] = _sign(params, secret)
        if method.upper() == "GET":
            if params:
                url += "?" + urllib.parse.urlencode(params)
            req = urllib.request.Request(url, headers=headers, method="GET")
        else:
            data = urllib.parse.urlencode(params).encode()
            headers["Content-Type"] = "application/x-www-form-urlencoded"
            req = urllib.request.Request(url, data=data, headers=headers, method=method.upper())
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                body = resp.read().decode()
                try:
                    return json.loads(body)
                except Exception:
                    return {"raw": body}
        except urllib.error.HTTPError as e:
            try:
                err_body = e.read().decode()
                return {"error": "http_error", "status": e.code, "body": err_body}
            except Exception:
                return {"error": "http_error", "status": getattr(e, 'code', None)}
        except Exception as e:
            return {"error": str(e)}

    def status(self) -> dict[str, Any]:
        configured = bool(self._api_key() and self._api_secret())
        result = {
            "provider": self.name,
            "environment": "testnet",
            "market": self.config.market,
            "configured": configured,
            "base_url": self._base_url(),
            # The adapter never exposes withdrawal operations, but it does not
            # inspect a user's Binance API-key restriction settings.
            "withdrawal_permissions": None,
            "withdrawal_permission_status": "unknown_not_checked",
            "withdrawal_operations_supported": False,
            "live_blocked": True,
        }
        if configured:
            try:
                if self.config.market == "futures":
                    acct = self._request("GET", "/fapi/v2/account", signed=True)
                else:
                    acct = self._request("GET", "/api/v3/account", signed=True)
                payload_valid = isinstance(acct, dict) and not acct.get("error")
                if payload_valid and "code" in acct:
                    try:
                        payload_valid = int(acct.get("code")) >= 0
                    except (TypeError, ValueError, OverflowError):
                        payload_valid = False
                if payload_valid and self.config.market == "futures":
                    payload_valid = isinstance(acct.get("assets"), list) and isinstance(acct.get("positions"), list)
                elif payload_valid and self.config.market == "spot":
                    payload_valid = isinstance(acct.get("balances"), list)
                else:
                    payload_valid = False
                result["connected"] = bool(payload_valid)
                result["account_check"] = "ok" if payload_valid else "invalid_or_error_account_payload"
                result["trading_allowed"] = acct.get("canTrade") if payload_valid and isinstance(acct.get("canTrade"), bool) else None
            except Exception as e:
                result["connected"] = False
                result["account_check"] = str(e)
        else:
            result["connected"] = False
            result["note"] = "Configure testnet API keys (env refs recommended). No real keys."
        return result

    def get_order_by_client_id(self, symbol: str, client_order_id: str) -> dict[str, Any]:
        """Read-only idempotency lookup. Unknown lookup state must never be retried as absent."""
        path = "/fapi/v1/order" if self.config.market == "futures" else "/api/v3/order"
        result = self._request("GET", path, signed=True, params={
            "symbol": symbol.replace("/", "").upper(),
            "origClientOrderId": client_order_id,
        })
        if isinstance(result, dict) and result.get("error"):
            body = result.get("body", "")
            try:
                payload = json.loads(body) if isinstance(body, str) else body
            except Exception:
                payload = {}
            if isinstance(payload, dict) and (payload.get("code") == -2013 or "does not exist" in str(payload.get("msg", "")).lower()):
                return {"found": False, "confirmed_absent": True}
            return {"found": False, "confirmed_absent": False, "error": "order_lookup_uncertain", "details": result}
        return {"found": True, "confirmed_absent": False, "order": result}

    def _load_order_filters(self, symbol: str, order_type: str) -> tuple[dict[str, float] | None, str | None]:
        """Fetch and normalize exchange filters; fail closed when symbol rules are unavailable."""
        info = self.get_exchange_info(symbol)
        if not isinstance(info, dict) or info.get("error") or not isinstance(info.get("symbols"), list):
            return None, "exchange_symbol_filters_unavailable"
        normalized = symbol.replace("/", "").upper()
        matches = [item for item in info["symbols"] if isinstance(item, dict)
                   and str(item.get("symbol", "")).upper() == normalized]
        if len(matches) != 1:
            return None, "exchange_symbol_filter_match_missing_or_ambiguous"
        item = matches[0]
        if str(item.get("status", "TRADING")).upper() != "TRADING":
            return None, "exchange_symbol_not_trading"
        raw_filters = item.get("filters")
        if not isinstance(raw_filters, list):
            return None, "exchange_symbol_filters_malformed"
        by_type = {str(f.get("filterType", "")).upper(): f for f in raw_filters if isinstance(f, dict)}
        price_filter = by_type.get("PRICE_FILTER")
        lot_filter = by_type.get("MARKET_LOT_SIZE") if order_type.upper() == "MARKET" else by_type.get("LOT_SIZE")
        if not isinstance(lot_filter, dict) or str(lot_filter.get("stepSize", "0")).strip() in {"", "0", "0.0"}:
            lot_filter = by_type.get("LOT_SIZE")
        if not isinstance(price_filter, dict) or not isinstance(lot_filter, dict):
            return None, "required_exchange_tick_or_step_filter_missing"
        min_values = []
        for kind in ("MIN_NOTIONAL", "NOTIONAL"):
            f = by_type.get(kind)
            if isinstance(f, dict):
                raw = f.get("minNotional", f.get("notional"))
                if raw is not None:
                    try:
                        value = float(raw)
                    except (TypeError, ValueError, OverflowError):
                        return None, "exchange_min_notional_filter_invalid"
                    if not isfinite(value) or value < 0:
                        return None, "exchange_min_notional_filter_invalid"
                    min_values.append(value)
        try:
            tick = float(price_filter.get("tickSize", 0) or 0)
            step = float(lot_filter.get("stepSize", 0) or 0)
        except (TypeError, ValueError, OverflowError):
            return None, "exchange_tick_or_step_filter_invalid"
        if not isfinite(tick) or tick <= 0 or not isfinite(step) or step <= 0:
            return None, "exchange_tick_or_step_filter_invalid"
        if not min_values:
            return None, "exchange_min_notional_filter_missing"
        return {"tickSize": tick, "stepSize": step, "minNotional": max(min_values)}, None

    def place_order(self, symbol: str, side: str, order_type: str, quantity: float, price: float | None = None,
                    reference_price: float | None = None, idempotency_key: str | None = None) -> dict[str, Any]:
        # External Testnet order submission is opt-in and requires dedicated Testnet credentials.
        if not self.config.enabled:
            return {"ok": False, "testnet": True, "sent_to_exchange": False, "error": "testnet_adapter_disabled"}
        if self.config.environment not in {"testnet", "demo"}:
            return {"ok": False, "testnet": True, "sent_to_exchange": False, "error": "unapproved_environment"}
        if self.config.market not in {"spot", "futures"}:
            return {"ok": False, "testnet": True, "sent_to_exchange": False, "error": "unsupported_market"}
        if not self._api_key() or not self._api_secret():
            return {"ok": False, "testnet": True, "sent_to_exchange": False, "error": "testnet_credentials_required"}
        if not isinstance(idempotency_key, str) or len(idempotency_key) < 8 or len(idempotency_key) > 36 or not all(c.isalnum() or c in "_.-" for c in idempotency_key):
            return {"ok": False, "testnet": True, "sent_to_exchange": False, "error": "valid_idempotency_key_required"}
        lookup = self.get_order_by_client_id(symbol, idempotency_key)
        if lookup.get("found"):
            return {"ok": True, "testnet": True, "sent_to_exchange": False, "duplicate": True, "response": lookup.get("order")}
        if not lookup.get("confirmed_absent"):
            return {"ok": False, "testnet": True, "sent_to_exchange": False, "error": "order_status_uncertain_blocked", "details": lookup}
        exchange_side = str(side or "").upper()
        position_side = None
        if self.config.market == "futures":
            position_mode = self.get_position_mode()
            if position_mode.get("error"):
                return {"ok": False, "testnet": True, "sent_to_exchange": False,
                        "error": "futures_position_mode_unavailable", "details": position_mode}
            if position_mode["dualSidePosition"]:
                if exchange_side not in {"LONG", "SHORT"}:
                    return {"ok": False, "testnet": True, "sent_to_exchange": False,
                            "error": "hedge_mode_requires_explicit_long_or_short"}
                position_side = exchange_side
                exchange_side = "BUY" if position_side == "LONG" else "SELL"
            elif exchange_side == "LONG":
                exchange_side = "BUY"
            elif exchange_side == "SHORT":
                exchange_side = "SELL"
            elif exchange_side not in {"BUY", "SELL"}:
                return {"ok": False, "testnet": True, "sent_to_exchange": False,
                        "error": "invalid_futures_order_side"}
        elif exchange_side not in {"BUY", "SELL"}:
            return {"ok": False, "testnet": True, "sent_to_exchange": False,
                    "error": "invalid_spot_order_side"}

        if order_type.upper() == "MARKET":
            try:
                # Never trust a caller-supplied reference price for market-order sizing.
                reference_price = self.public_data.get_ticker_price(symbol, market=self.config.market) * 1.01
            except Exception as e:
                return {"ok": False, "testnet": True, "sent_to_exchange": False,
                        "error": "market_reference_price_unavailable", "details": str(e)}
        exchange_filters, filter_error = self._load_order_filters(symbol, order_type)
        if filter_error or not exchange_filters:
            return {"ok": False, "testnet": True, "sent_to_exchange": False,
                    "error": filter_error or "exchange_symbol_filters_unavailable"}
        pre = self.gateway.validate(
            symbol=symbol, market=MarketType(self.config.market),
            side=side, order_type=order_type, quantity=quantity, price=price,
            reference_price=reference_price, idempotency_key=idempotency_key,
            environment_mode="demo", live_enabled=False, bypass_attempt=False,
            exchange_filters=exchange_filters
        )
        if not pre.ok:
            return {"ok": False, "error": "pretrade_blocked", "details": pre.to_dict(), "sent_to_exchange": False}
        params = {
            "symbol": symbol.replace("/", "").upper(),
            "side": exchange_side,
            "type": order_type.upper(),
            "quantity": quantity,
            "newClientOrderId": idempotency_key,
        }
        if position_side:
            params["positionSide"] = position_side
        if price and order_type.upper() in ("LIMIT",):
            params["price"] = price
            params["timeInForce"] = "GTC"
        path = "/fapi/v1/order" if self.config.market == "futures" else "/api/v3/order"
        res = self._request("POST", path, signed=True, params=params)
        return {"ok": "error" not in res, "testnet": True, "response": res, "precheck": pre.to_dict(),
                "sent_to_exchange": "error" not in res, "order_status_uncertain": "error" in res,
                "client_order_id": idempotency_key}

    def close_position(self, symbol: str, side: str, quantity: float, *, reference_price: float | None = None,
                       idempotency_key: str | None = None) -> dict[str, Any]:
        # Testnet-only close; sync the remote position/free balance before any reducing order.
        if not self.config.enabled or self.config.environment not in {"testnet", "demo"}:
            return {"ok": False, "testnet": True, "sent_to_exchange": False, "error": "testnet_adapter_disabled"}
        if not self._api_key() or not self._api_secret():
            return {"ok": False, "testnet": True, "sent_to_exchange": False, "error": "testnet_credentials_required"}
        if not isinstance(idempotency_key, str) or len(idempotency_key) < 8 or len(idempotency_key) > 36 or not all(c.isalnum() or c in "_.-" for c in idempotency_key):
            return {"ok": False, "testnet": True, "sent_to_exchange": False, "error": "valid_idempotency_key_required"}
        lookup = self.get_order_by_client_id(symbol, idempotency_key)
        if lookup.get("found"):
            return {"ok": True, "testnet": True, "sent_to_exchange": False, "duplicate": True, "response": lookup.get("order")}
        if not lookup.get("confirmed_absent"):
            return {"ok": False, "testnet": True, "sent_to_exchange": False,
                    "error": "order_status_uncertain_blocked", "order_status_uncertain": True, "details": lookup}
        if not isinstance(quantity, (int, float)) or quantity <= 0:
            return {"ok": False, "testnet": True, "sent_to_exchange": False, "error": "positive_close_quantity_required"}

        normalized_symbol = symbol.replace("/", "").upper()
        requested_side = str(side or "").upper()
        try:
            if self.config.market == "futures":
                account = self.get_account()
                if not isinstance(account, dict) or account.get("error") or not isinstance(account.get("positions"), list):
                    return {"ok": False, "testnet": True, "sent_to_exchange": False,
                            "error": "futures_position_sync_unavailable", "details": account}
                positions = [p for p in account["positions"] if str(p.get("symbol", "")).upper() == normalized_symbol
                             and abs(float(p.get("positionAmt", 0) or 0)) > 0]
                if not positions:
                    return {"ok": False, "testnet": True, "sent_to_exchange": False, "error": "no_open_futures_position_to_close"}
                candidates = []
                for pos in positions:
                    pos_side = str(pos.get("positionSide", "BOTH")).upper()
                    amount = float(pos.get("positionAmt", 0) or 0)
                    is_long = pos_side == "LONG" or (pos_side == "BOTH" and amount > 0)
                    is_short = pos_side == "SHORT" or (pos_side == "BOTH" and amount < 0)
                    if ((requested_side in {"LONG", "SELL"} and is_long) or
                        (requested_side in {"SHORT", "BUY"} and is_short)):
                        candidates.append(pos)
                if len(candidates) != 1:
                    return {"ok": False, "testnet": True, "sent_to_exchange": False,
                            "error": "futures_position_side_ambiguous_or_mismatched"}
                position = candidates[0]
                position_side = str(position.get("positionSide", "BOTH")).upper()
                amount = float(position.get("positionAmt", 0) or 0)
                is_long = position_side == "LONG" or (position_side == "BOTH" and amount > 0)
                expected_side = "SELL" if is_long else "BUY"
                if requested_side in {"BUY", "SELL"} and requested_side != expected_side:
                    return {"ok": False, "testnet": True, "sent_to_exchange": False, "error": "futures_close_side_mismatch"}
                if requested_side in {"LONG", "SHORT"} and requested_side != ("LONG" if is_long else "SHORT"):
                    return {"ok": False, "testnet": True, "sent_to_exchange": False, "error": "futures_close_side_mismatch"}
                available = abs(amount)
                if quantity > available + 1e-12:
                    return {"ok": False, "testnet": True, "sent_to_exchange": False,
                            "error": "close_quantity_exceeds_synced_position", "available_quantity": available}
                # Never trust a caller-supplied price for the hard notional check.
                ref = self.public_data.get_ticker_price(symbol, market="futures") * 1.01
                exchange_filters, filter_error = self._load_order_filters(symbol, "MARKET")
                if filter_error or not exchange_filters:
                    return {"ok": False, "testnet": True, "sent_to_exchange": False,
                            "error": filter_error or "exchange_symbol_filters_unavailable"}
                pre = self.gateway.validate(symbol=symbol, market=MarketType.FUTURES, side=expected_side,
                    order_type="market", quantity=quantity, reference_price=ref, idempotency_key=idempotency_key,
                    environment_mode="demo", live_enabled=False, bypass_attempt=False,
                    exchange_filters=exchange_filters)
                if not pre.ok:
                    return {"ok": False, "testnet": True, "sent_to_exchange": False,
                            "error": "pretrade_blocked", "details": pre.to_dict()}
                params = {"symbol": normalized_symbol, "side": expected_side, "type": "MARKET",
                          "quantity": quantity, "newClientOrderId": idempotency_key}
                # Hedge Mode uses positionSide; One-way Mode uses reduceOnly.
                if position_side in {"LONG", "SHORT"}:
                    params["positionSide"] = position_side
                else:
                    params["reduceOnly"] = "true"
                try:
                    response = self._request("POST", "/fapi/v1/order", signed=True, params=params)
                except Exception as exc:
                    return {"ok": False, "testnet": True, "sent_to_exchange": False,
                            "error": "order_status_uncertain_blocked", "order_status_uncertain": True,
                            "details": type(exc).__name__}
            elif self.config.market == "spot":
                if requested_side not in {"SELL", "LONG"}:
                    return {"ok": False, "testnet": True, "sent_to_exchange": False, "error": "spot_close_requires_sell_side"}
                info = self.get_exchange_info(symbol)
                if not isinstance(info, dict) or info.get("error") or not info.get("symbols"):
                    return {"ok": False, "testnet": True, "sent_to_exchange": False,
                            "error": "spot_symbol_sync_unavailable", "details": info}
                base_asset = info["symbols"][0].get("baseAsset")
                account = self.get_account()
                if not base_asset or not isinstance(account, dict) or account.get("error") or not isinstance(account.get("balances"), list):
                    return {"ok": False, "testnet": True, "sent_to_exchange": False,
                            "error": "spot_balance_sync_unavailable", "details": account}
                balance = next((b for b in account["balances"] if b.get("asset") == base_asset), None)
                free = float((balance or {}).get("free", 0) or 0)
                if quantity > free + 1e-12:
                    return {"ok": False, "testnet": True, "sent_to_exchange": False,
                            "error": "close_quantity_exceeds_synced_free_balance", "available_quantity": free}
                ref = self.public_data.get_ticker_price(symbol, market="spot") * 1.01
                exchange_filters, filter_error = self._load_order_filters(symbol, "MARKET")
                if filter_error or not exchange_filters:
                    return {"ok": False, "testnet": True, "sent_to_exchange": False,
                            "error": filter_error or "exchange_symbol_filters_unavailable"}
                pre = self.gateway.validate(symbol=symbol, market=MarketType.SPOT, side="sell",
                    order_type="market", quantity=quantity, reference_price=ref, idempotency_key=idempotency_key,
                    environment_mode="demo", live_enabled=False, bypass_attempt=False,
                    exchange_filters=exchange_filters)
                if not pre.ok:
                    return {"ok": False, "testnet": True, "sent_to_exchange": False,
                            "error": "pretrade_blocked", "details": pre.to_dict()}
                params = {"symbol": normalized_symbol, "side": "SELL", "type": "MARKET",
                          "quantity": quantity, "newClientOrderId": idempotency_key}
                try:
                    response = self._request("POST", "/api/v3/order", signed=True, params=params)
                except Exception as exc:
                    return {"ok": False, "testnet": True, "sent_to_exchange": False,
                            "error": "order_status_uncertain_blocked", "order_status_uncertain": True,
                            "details": type(exc).__name__}
            else:
                return {"ok": False, "testnet": True, "sent_to_exchange": False, "error": "unsupported_market"}
        except Exception as exc:
            return {"ok": False, "testnet": True, "sent_to_exchange": False,
                    "error": "position_or_balance_sync_failed", "details": str(exc)}
        return {"ok": "error" not in response, "testnet": True, "response": response,
                "sent_to_exchange": "error" not in response, "order_status_uncertain": "error" in response,
                "reduce_only_close": True, "client_order_id": idempotency_key}

    def get_position_mode(self) -> dict[str, Any]:
        """Read Futures account position mode; unknown mode blocks new Futures orders."""
        if self.config.market != "futures":
            return {"dualSidePosition": False}
        result = self._request("GET", "/fapi/v1/positionSide/dual", signed=True)
        if not isinstance(result, dict) or result.get("error") or not isinstance(result.get("dualSidePosition"), bool):
            return {"error": "futures_position_mode_unavailable", "details": result}
        return result

    def get_account(self) -> dict[str, Any]:
        if self.config.market == "futures":
            return self._request("GET", "/fapi/v2/account", signed=True)
        return self._request("GET", "/api/v3/account", signed=True)

    def get_open_orders(self, symbol: str | None = None) -> dict[str, Any]:
        params = {}
        if symbol:
            params["symbol"] = symbol.replace("/", "")
        if self.config.market == "futures":
            return self._request("GET", "/fapi/v1/openOrders", signed=True, params=params)
        return self._request("GET", "/api/v3/openOrders", signed=True, params=params)

    def get_exchange_info(self, symbol: str | None = None) -> dict[str, Any]:
        params = {}
        if symbol:
            params["symbol"] = symbol.replace("/", "")
        if self.config.market == "futures":
            return self._request("GET", "/fapi/v1/exchangeInfo", signed=False, params=params)
        return self._request("GET", "/api/v3/exchangeInfo", signed=False, params=params)

    def reconcile(self, local_open_orders: list[dict] | None = None) -> dict[str, Any]:
        remote = self.get_open_orders()
        if isinstance(remote, dict) and remote.get("error"):
            return {"ok": False, "error": "remote_fetch_failed", "details": remote,
                    "action": "halt_new_orders_until_resolved"}
        remote_list = remote if isinstance(remote, list) else []
        local = local_open_orders or []
        local_ids = {
            str(value) for order in local
            for value in (order.get("id"), order.get("orderId"), order.get("clientOrderId"))
            if value is not None
        }
        remote_ids = {
            str(value) for order in remote_list
            for value in (order.get("orderId"), order.get("clientOrderId"))
            if value is not None
        }
        missing_local = [o for o in remote_list
                         if not ({str(o.get("orderId")), str(o.get("clientOrderId"))} & local_ids)]
        resolved_non_open = []
        missing_remote = []
        uncertain = []
        for order in local:
            keys = {str(order.get(k)) for k in ("id", "orderId", "clientOrderId") if order.get(k) is not None}
            if keys & remote_ids:
                continue
            client_id = order.get("clientOrderId") or order.get("id")
            symbol = order.get("symbol")
            if not client_id or not symbol:
                uncertain.append(order)
                continue
            lookup = self.get_order_by_client_id(str(symbol), str(client_id))
            if lookup.get("found"):
                remote_order = lookup.get("order") or {}
                status = str(remote_order.get("status", "UNKNOWN")).upper()
                if status in {"FILLED", "CANCELED", "CANCELLED", "REJECTED", "EXPIRED"}:
                    resolved_non_open.append(remote_order)
                else:
                    uncertain.append({"local": order, "remote": remote_order})
            elif lookup.get("confirmed_absent"):
                missing_remote.append(order)
            else:
                uncertain.append({"local": order, "lookup": lookup})
        ok = not missing_local and not missing_remote and not uncertain
        return {
            "ok": ok, "remote_open_orders_count": len(remote_list), "local_open_orders_count": len(local),
            "missing_in_local": len(missing_local), "missing_in_remote": len(missing_remote),
            "resolved_non_open": len(resolved_non_open), "uncertain": len(uncertain),
            "action": "ok" if ok else "review_required_halt_new_orders",
            "details": {"missing_in_local_sample": missing_local[:3], "missing_in_remote_sample": missing_remote[:3],
                        "resolved_non_open_sample": resolved_non_open[:3], "uncertain_sample": uncertain[:3]},
        }

    # Compatibility methods for existing tests/workflows
    def precheck_order(self, **kwargs) -> dict[str, Any]:
        decision = self.gateway.validate(**kwargs)
        return decision.to_dict() if hasattr(decision, 'to_dict') else decision

    def place_order_shadow(self, **kwargs) -> dict[str, Any]:
        pre = self.precheck_order(**kwargs)
        return {"mode": "shadow", "sent_to_exchange": False, "precheck": pre}

    def place_order_live(self, **kwargs) -> dict[str, Any]:
        return {
            "ok": False,
            "sent_to_exchange": False,
            "reason": "live_exchange_execution_not_enabled_in_foundation",
            "required": ["verified_credentials", "symbol_filters", "balance_sync", "order_reconciliation", "rate_limit_control", "compliance_allow", "explicit_user_approval_for_live"],
        }


# Keep old name for compatibility
BinanceAdapter = BinanceTestnetAdapter
BinanceConfig = BinanceConfig
