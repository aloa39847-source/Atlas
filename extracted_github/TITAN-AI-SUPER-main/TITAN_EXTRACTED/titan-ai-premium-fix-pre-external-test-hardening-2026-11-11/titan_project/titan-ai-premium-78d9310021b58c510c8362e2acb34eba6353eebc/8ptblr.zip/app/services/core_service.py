from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.enums import EngineStatus, EnvironmentMode, MarketType, Timeframe
from app.engines.decision import DecisionEngine
from app.engines.market_data import MarketDataEngine
from app.engines.risk import RiskEngine
from app.engines.strategies import list_strategies
from app.engines.technical import TechnicalAnalysisEngine
from app.models.entities import DecisionRecord, EngineState, SystemState, PositionRecord
from .audit import log_event
from .governance import record_config_change
from .performance import prediction_tracking
from .position_management import position_management
from .portfolio_management import portfolio_management


ENGINE_REGISTRY = [
    ("compliance_policy", "TITAN COMPLIANCE & POLICY ENGINE", "implemented_partial"),
    ("market_analysis", "Market Analysis Engine", "implemented_partial"),
    ("technical_analysis", "Technical Analysis Engine", "implemented_partial"),
    ("fundamental_analysis", "Fundamental Analysis Engine", "not_implemented"),
    ("news_analysis", "News Analysis Engine", "needs_external_service"),
    ("market_structure", "Market Structure Engine", "implemented_partial"),
    ("liquidity_analysis", "Liquidity Analysis Engine", "needs_external_service"),
    ("order_flow", "Order Flow Engine", "needs_external_service"),
    ("volume_analysis", "Volume Analysis Engine", "implemented_partial"),
    ("coin_discovery", "Coin Discovery Engine", "implemented_partial"),
    ("strategy_selection", "Strategy Selection Engine", "implemented_partial"),
    ("decision_making", "Decision Making Engine", "implemented_partial"),
    ("risk_management", "Risk Management Engine", "implemented_partial"),
    ("portfolio_management", "Portfolio Management Engine", "implemented_partial"),
    ("trade_execution", "Trade Execution Engine", "needs_external_service"),
    ("position_management", "Position Management Engine", "implemented_partial"),
    ("backtesting", "Backtesting Engine", "implemented_partial"),
    ("ai_learning", "AI Learning Engine", "implemented_partial"),
    ("self_evolution", "Self-Evolution Engine", "implemented_partial"),
    ("knowledge_base", "Knowledge Base", "implemented_partial"),
    ("long_term_memory", "Long-Term Memory", "implemented_partial"),
    ("performance_evaluation", "Performance Evaluation Engine", "implemented_partial"),
    ("prediction_tracking", "Prediction Tracking Engine", "implemented_partial"),
    ("system_monitoring", "System Monitoring Engine", "implemented_partial"),
]


def _utcnow():
    return datetime.now(timezone.utc)


class TitanCoreService:
    def __init__(self) -> None:
        self.market_data = MarketDataEngine()
        self.technical = TechnicalAnalysisEngine()
        self.risk = RiskEngine()
        self.decision = DecisionEngine()

    def ensure_bootstrap(self, db: Session) -> None:
        state = db.get(SystemState, 1)
        if not state:
            state = SystemState(
                id=1, environment_mode=EnvironmentMode.DEMO.value, account_target="demo", market_type=MarketType.SPOT.value,
                bot_run_state="stopped", autonomous_enabled=False, live_trading_enabled=False, live_confirmed_by_user=False,
                emergency_stop=False, selected_timeframes=[t.value for t in Timeframe],
                risk_limits={"max_leverage_cap": settings.max_leverage_cap, "max_risk_per_trade_cap": settings.max_risk_per_trade_cap,
                             "max_daily_loss_cap": settings.max_daily_loss_cap, "max_open_positions_cap": settings.max_open_positions_cap},
                status_summary={"bootstrapped": True},
            )
            db.add(state)
            log_event(db, action="system.bootstrap", message="Initialized TITAN system state (DEMO, SPOT, stopped, live off).")
        else:
            # compatibility defaults for older DB rows
            if not getattr(state, "account_target", None): state.account_target = state.environment_mode or "demo"
            if not getattr(state, "bot_run_state", None): state.bot_run_state = "stopped"
            db.add(state)
        existing_rows = {
            r.engine_key: r for r in db.execute(select(EngineState)).scalars().all()
        }
        implementation_states = {"not_implemented", "needs_external_service", "implemented_partial"}
        for key, name, status in ENGINE_REGISTRY:
            row = existing_rows.get(key)
            if row is None:
                db.add(EngineState(engine_key=key, name=name, status=status,
                                   message="Registered by TITAN AI CORE bootstrap."))
            elif row.status in implementation_states and row.status != status:
                previous = row.status
                row.status = status
                row.name = name
                row.message = f"Implementation status synchronized from {previous} to {status} by TITAN AI CORE bootstrap."
                db.add(row)
        db.commit()

    def _state(self, db: Session) -> SystemState:
        self.ensure_bootstrap(db)
        return db.get(SystemState, 1)

    def get_state(self, db: Session) -> dict[str, Any]:
        s = self._state(db)
        return {
            "environment_mode": s.environment_mode,
            "account_target": getattr(s, "account_target", s.environment_mode),
            "market_type": s.market_type,
            "bot_run_state": getattr(s, "bot_run_state", "stopped"),
            "bot_started_at": s.bot_started_at.isoformat() if getattr(s, "bot_started_at", None) else None,
            "bot_stopped_at": s.bot_stopped_at.isoformat() if getattr(s, "bot_stopped_at", None) else None,
            "bot_stop_reason": getattr(s, "bot_stop_reason", None),
            "autonomous_enabled": s.autonomous_enabled,
            "live_trading_enabled": s.live_trading_enabled,
            "live_confirmed_by_user": bool(getattr(s, "live_confirmed_by_user", False)),
            "emergency_stop": s.emergency_stop,
            "selected_timeframes": s.selected_timeframes or [t.value for t in Timeframe],
            "risk_limits": s.risk_limits or {},
            "safety": {
                "allow_demo_to_live_auto": settings.allow_demo_to_live_auto,
                "allow_withdrawal_permissions": settings.allow_withdrawal_permissions,
                "note": "Demo/Live separated. Auto switch to Live disabled. Withdrawal/transfer permissions are not supported.",
            },
            "master_control": {
                "start_requires": ["account_target_selected", "connectivity_or_data_check", "compliance_check", "risk_limits", "no_duplicate_run"],
                "stop_default": "stop_new_only",
                "emergency_stop": "independent_flag_blocks_new_actions",
            },
        }

    def set_state(self, db: Session, *, environment_mode: str | None = None, account_target: str | None = None,
                  market_type: str | None = None, autonomous_enabled: bool | None = None, emergency_stop: bool | None = None,
                  live_confirm: bool | None = None) -> dict[str, Any]:
        s = self._state(db)
        old = self.get_state(db)
        if account_target:
            at = account_target.lower()
            if at not in {"demo", "testnet", "live"}:
                raise ValueError("account_target must be demo, testnet, or live")
            if at == "live" and old.get("environment_mode") != "live" and not live_confirm:
                raise ValueError("Switching to Live requires explicit confirmation (live_confirm=true) and enabled config. No auto demo->live.")
            s.account_target = at
            s.environment_mode = "live" if at == "live" else "demo"
        if environment_mode:
            env = EnvironmentMode(environment_mode)
            if env == EnvironmentMode.LIVE and (not settings.live_trading_enabled or not live_confirm):
                log_event(db, action="state.live_blocked", severity="warning", message="Live blocked: requires explicit config enablement and confirmation.")
            else:
                s.environment_mode = env.value
                s.account_target = "live"
                s.live_confirmed_by_user = bool(live_confirm)
        if market_type:
            s.market_type = MarketType(market_type).value
        if autonomous_enabled is not None:
            s.autonomous_enabled = bool(autonomous_enabled)
        if emergency_stop is not None:
            s.emergency_stop = bool(emergency_stop)
            if s.emergency_stop:
                s.bot_run_state = "stopped"
                s.bot_stopped_at = _utcnow()
                s.bot_stop_reason = "emergency_stop"
                log_event(db, action="master.emergency_stop", severity="warning", message="Emergency stop activated: new actions must halt.")
        db.add(s)
        record_config_change(db, actor="api", scope="system", key="state", old_value=old, new_value=self.get_state(db), reason="User/API state update", approved=True)
        log_event(db, action="state.update", message="System state updated.", details={"before_env": old.get("environment_mode"), "after_env": s.environment_mode})
        db.commit()
        return self.get_state(db)

    def start_bot(self, db: Session, *, account_target: str | None = None, live_confirm: bool = False) -> dict[str, Any]:
        s = self._state(db)
        if s.emergency_stop:
            raise ValueError("Cannot start: emergency stop is active.")
        if getattr(s, "bot_run_state", "stopped") in {"starting", "running", "analyzing", "executing", "waiting_data"}:
            raise ValueError("Cannot start duplicate run: bot is already active. Stop it first.")
        if account_target:
            self.set_state(db, account_target=account_target, live_confirm=live_confirm)
            s = self._state(db)
        # Pre-start checks (what we can verify now)
        checks = {
            "account_target": s.account_target,
            "environment_mode": s.environment_mode,
            "market_type": s.market_type,
            "demo_data_available": True,  # synthetic labeled provider available
            "binance_connected": False,   # needs external service
            "compliance_engine": True,
            "risk_limits_present": bool(s.risk_limits),
            "withdrawal_permissions": False,
        }
        from app.knowledge.base import coverage_report
        knowledge_status = coverage_report(db)
        checks["knowledge_foundation_ready"] = knowledge_status["foundation_ready"]
        checks["knowledge_coverage_percent"] = knowledge_status["coverage_percent"]
        if not knowledge_status["foundation_ready"]:
            log_event(db, action="master.start_blocked_knowledge_foundation", severity="warning",
                      message="Autonomous start blocked: verified knowledge foundation is incomplete.",
                      details={"coverage_percent": knowledge_status["coverage_percent"],
                               "missing_domains": knowledge_status["missing_domains"]})
            db.commit()
            raise ValueError("Autonomous start blocked: verified knowledge foundation is incomplete. Manual analysis remains available.")
        if s.environment_mode == "live" or s.account_target == "live":
            if not settings.live_trading_enabled or not live_confirm:
                raise ValueError("Live start blocked: explicit config enablement and user confirmation required.")
            checks["live_preconditions_verified"] = False
            log_event(db, action="master.start_blocked", severity="warning", message="Live start blocked pending full preconditions.", details=checks)
            db.commit()
            raise ValueError("Live start blocked: verify Binance connection, eligibility/KYC/geo, symbol filters, balances/orders sync, and compliance before Live.")
        s.bot_run_state = "running"
        s.bot_started_at = _utcnow()
        s.bot_stopped_at = None
        s.bot_stop_reason = None
        s.autonomous_enabled = True
        db.add(s)
        log_event(db, action="master.start", message=f"Bot started ({s.account_target}/{s.market_type}).", details=checks,
                  environment_mode=s.environment_mode, market_type=s.market_type)
        db.commit()
        return {"ok": True, "state": self.get_state(db), "checks": checks, "note": "Demo/synthetic mode started. No live orders sent. External Binance/Telegram integrations require configuration."}

    def stop_bot(self, db: Session, *, reason: str = "user_stop", close_positions: bool = False) -> dict[str, Any]:
        s = self._state(db)
        s.bot_run_state = "stopped"
        s.bot_stopped_at = _utcnow()
        s.bot_stop_reason = reason
        s.autonomous_enabled = False
        db.add(s)
        log_event(db, action="master.stop", severity="warning", message=f"Bot stopped: {reason}.", details={"close_positions_requested": bool(close_positions), "note": "Stops new actions/orders. Open positions are NOT auto-closed unless explicitly handled by a verified execution adapter."},
                  environment_mode=s.environment_mode, market_type=s.market_type)
        db.commit()
        return {"ok": True, "state": self.get_state(db), "close_positions_requested": bool(close_positions)}

    def engines(self, db: Session) -> list[dict[str, Any]]:
        self._state(db)
        rows = db.execute(select(EngineState).order_by(EngineState.engine_key)).scalars().all()
        return [{"key": r.engine_key, "name": r.name, "status": r.status, "message": r.message, "updated_at": r.updated_at.isoformat() if r.updated_at else None} for r in rows]

    def strategies(self) -> list[dict[str, Any]]:
        return list_strategies()

    def analyze(self, db: Session, *, symbol: str, market_type: str, environment_mode: str, balance: float = 1000.0, max_leverage: float = 3.0, risk_per_trade: float = 0.01) -> dict[str, Any]:
        self.ensure_bootstrap(db)
        market = MarketType(market_type)
        env = EnvironmentMode(environment_mode)
        if env == EnvironmentMode.LIVE and not settings.live_trading_enabled:
            raise ValueError("Live analysis/execution is disabled by configuration. Use DEMO or enable live explicitly in a controlled deployment.")
        state = self._state(db)
        limits = state.risk_limits or {}
        portfolio_positions = db.execute(select(PositionRecord).where(
            PositionRecord.environment_mode == env.value,
            PositionRecord.market_type == market.value,
        )).scalars().all()
        open_positions = [p for p in portfolio_positions if p.status == "open"]
        current_exposure = sum(abs(float(p.mark_price or p.entry_avg_price or 0.0) * float(p.quantity or 0.0)) for p in open_positions)
        today = _utcnow().date()
        daily_realized_losses = sum(max(0.0, -float(p.realized_pnl or 0.0)) for p in portfolio_positions
                                    if p.updated_at and p.updated_at.date() == today)
        daily_unrealized_losses = sum(max(0.0, -float(p.unrealized_pnl or 0.0)) for p in open_positions)
        risk_context = {
            "daily_loss_used": daily_realized_losses + daily_unrealized_losses,
            "max_daily_loss": float(limits.get("max_daily_loss_cap", settings.max_daily_loss_cap)),
            "open_positions": len(open_positions),
            "max_open_positions": int(limits.get("max_open_positions_cap", settings.max_open_positions_cap)),
            "current_exposure": current_exposure,
            "max_exposure": float(limits.get("max_total_exposure", balance * 2.0)),
        }
        batches = self.market_data.get_multi_timeframe(symbol, seed=42, market_type=market.value)
        analyses = {tf.value: self.technical.analyze(batch.df, tf) for tf, batch in batches.items()}
        result = self.decision.decide(
            symbol=symbol, market=market, environment=env,
            timeframe_analyses={Timeframe(k): v for k, v in analyses.items()},
            balance=balance, max_leverage=max_leverage, risk_per_trade=risk_per_trade,
            batches=batches, risk_context=risk_context,
        )
        rec = DecisionRecord(
            environment_mode=env.value, market_type=market.value, symbol=symbol,
            action=result.get("action", "wait"), strategy=result.get("strategy"),
            confidence=result.get("confidence"), entry_price=result.get("entry_price"),
            stop_loss=result.get("stop_loss"), take_profit=result.get("take_profit"),
            risk_reward=result.get("risk_reward"), leverage=result.get("leverage"),
            rationale=result.get("reason", ""), timeframe_context=result.get("timeframes"),
            indicators={"per_timeframe_last": {k: v.indicators for k, v in analyses.items()}},
            costs=result.get("costs"), news_context=None, data_source=(next(iter({b.source.value for b in batches.values()})) if len({b.source.value for b in batches.values()}) == 1 else "mixed"),
            reproducibility={"app_version": "0.1.0-foundation", "inputs": {"symbol": symbol, "market_type": market.value, "environment_mode": env.value, "balance": balance, "max_leverage": max_leverage, "risk_per_trade": risk_per_trade},
                              "timeframes": [t.value for t in batches.keys()], "data_labels": {t.value: b.source.value for t, b in batches.items()},
                              "note": "Replay requires the same data provider/configuration and candle snapshot; source labels are recorded above."},
        )
        db.add(rec)
        db.flush()
        five_minute = analyses.get(Timeframe.M5.value)
        reference_price = (five_minute.indicators or {}).get("close") if five_minute else None
        if reference_price is not None:
            prediction_tracking.record_decision(
                db, decision_id=rec.id, symbol=symbol, environment_mode=env.value,
                market_type=market.value, action=rec.action, confidence=rec.confidence,
                reference_price=reference_price, horizon=Timeframe.M5.value,
                strategy=rec.strategy, data_source=rec.data_source,
                stop_loss=rec.stop_loss, take_profit=rec.take_profit,
            )
        log_event(db, action="analysis.decision", message=f"Decision {rec.action} for {symbol} ({env.value}/{market.value}).",
                  environment_mode=env.value, market_type=market.value, entity_type="decision", details={"symbol": symbol, "action": rec.action, "confidence": rec.confidence})
        db.commit(); db.refresh(rec)
        result["decision_id"] = rec.id
        result["recorded"] = True
        m5_batch = batches.get(Timeframe.M5)
        m5_analysis = analyses.get(Timeframe.M5.value)
        result["market_price_source"] = m5_batch.source.value if m5_batch else "unknown"
        result["market_prices"] = (
            {symbol: float(m5_analysis.indicators["close"])}
            if m5_analysis and m5_analysis.indicators.get("close") is not None
            else {}
        )
        return result

    def get_engines_detailed(self, db: Session) -> list[dict[str, Any]]:
        self._state(db)
        rows = db.execute(select(EngineState).order_by(EngineState.engine_key)).scalars().all()
        result = []
        for r in rows:
            result.append({
                "key": r.engine_key,
                "name": r.name,
                "status": r.status,
                "message": r.message,
                "details": r.details or {},
                "updated_at": r.updated_at.isoformat() if r.updated_at else None,
                "can_start_stop": True,
                "controls": ["start", "stop", "restart", "test"]
            })
        return result

    def control_engine(self, db: Session, key: str, action: str, user: str = "system") -> dict[str, Any]:
        from .audit import log_event
        es = db.execute(select(EngineState).where(EngineState.engine_key == key)).scalar_one_or_none()
        if not es:
            return {"ok": False, "error": "engine_not_found"}
        action = (action or "").lower()
        if action == "start":
            es.status = "running"
            es.message = "Started by user request"
            log_event(db, action="engine.start", message=f"Started engine {key}", entity_type="engine", entity_id=key, actor=user)
            db.commit()
            return {"ok": True, "message": "started", "engine": key}
        elif action == "stop":
            es.status = "stopped"
            es.message = "Stopped by user request"
            log_event(db, action="engine.stop", message=f"Stopped engine {key}", entity_type="engine", entity_id=key, actor=user)
            db.commit()
            return {"ok": True, "message": "stopped", "engine": key}
        elif action == "restart":
            es.status = "running"
            es.message = "Restarted by user request"
            log_event(db, action="engine.restart", message=f"Restarted engine {key}", entity_type="engine", entity_id=key, actor=user)
            db.commit()
            return {"ok": True, "message": "restarted", "engine": key}
        elif action == "test":
            es.message = "Test triggered"
            log_event(db, action="engine.test", message=f"Test triggered for engine {key}", entity_type="engine", entity_id=key, actor=user)
            db.commit()
            return {"ok": True, "message": "test_triggered", "engine": key, "result": "ok"}
        else:
            return {"ok": False, "error": "unknown_action"}



core_service = TitanCoreService()

