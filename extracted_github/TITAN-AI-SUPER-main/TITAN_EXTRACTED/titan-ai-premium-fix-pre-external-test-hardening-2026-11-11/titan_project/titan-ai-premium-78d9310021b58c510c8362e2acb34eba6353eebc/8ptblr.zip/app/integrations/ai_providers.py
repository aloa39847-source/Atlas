from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.entities import AIProviderConfig, AIUsageRecord
from app.services.audit import log_event

# Official/provider reference pages checked during research (verify before relying on pricing/access):
# - Anthropic supported regions/pricing: https://www.anthropic.com/legal/supported-regions , https://platform.claude.com/docs/en/about-claude/pricing
# - Google Gemini API regions/pricing: https://ai.google.dev/gemini-api/docs/available-regions , https://ai.google.dev/gemini-api/docs/pricing
# - OpenAI supported countries/pricing: https://developers.openai.com/api/docs/supported-countries.md , https://openai.com/api/pricing/
# - Mistral pricing/models: https://mistral.ai/pricing , https://docs.mistral.ai/getting-started/models/
# - DeepSeek pricing: https://api-docs.deepseek.com/quick_start/pricing
# - xAI models/pricing: https://docs.x.ai/developers/models
# Algeria: Anthropic supported regions page retrieved during research listed Algeria. Other providers' Algeria eligibility must be verified on their official pages/terms before use.
# IMPORTANT: Never claim a model is connected or a feature works without real API keys and successful tests.


SUPPORTED_PROVIDERS = {"openai", "anthropic", "google", "xai", "mistral", "deepseek", "openai_compatible"}


def _resolve_api_key(api_key_ref: str | None) -> str | None:
    if not api_key_ref:
        return None
    ref = api_key_ref.strip()
    if ref.startswith("env:"):
        return os.getenv(ref[4:], "").strip() or None
    # Direct key storage is discouraged; if present, treat as secret value (never log it).
    return ref or None


def _default_base_url(provider: str) -> str | None:
    return {
        "openai": "https://api.openai.com/v1",
        "anthropic": "https://api.anthropic.com/v1",
        "google": "https://generativelanguage.googleapis.com/v1beta",
        "xai": "https://api.x.ai/v1",
        "mistral": "https://api.mistral.ai/v1",
        "deepseek": "https://api.deepseek.com",
    }.get(provider)


@dataclass
class ProviderResult:
    ok: bool
    provider: str
    model: str
    text: str = ""
    error: str | None = None
    latency_ms: float | None = None
    usage: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return {"ok": self.ok, "provider": self.provider, "model": self.model, "text": self.text, "error": self.error, "latency_ms": self.latency_ms, "usage": self.usage or {}}


def _http_json(method: str, url: str, headers: dict[str, str], payload: dict[str, Any] | None, timeout: int = 30) -> dict[str, Any]:
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {e.code}: {body[:500]}") from e


def _call_openai_compatible(base_url: str, api_key: str, model: str, messages: list[dict[str, str]]) -> dict[str, Any]:
    url = base_url.rstrip("/") + "/chat/completions"
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    payload = {"model": model, "messages": messages, "temperature": 0.2}
    return _http_json("POST", url, headers, payload)


def _call_anthropic(base_url: str, api_key: str, model: str, messages: list[dict[str, str]]) -> dict[str, Any]:
    url = base_url.rstrip("/") + "/messages"
    system = "\n".join(m["content"] for m in messages if m.get("role") == "system")
    user_msgs = [{"role": m["role"], "content": m["content"]} for m in messages if m.get("role") in {"user", "assistant"}]
    headers = {"x-api-key": api_key, "anthropic-version": "2023-06-01", "Content-Type": "application/json"}
    payload = {"model": model, "max_tokens": 1024, "messages": user_msgs}
    if system:
        payload["system"] = system
    return _http_json("POST", url, headers, payload)


def _extract_text(provider: str, data: dict[str, Any]) -> str:
    if provider == "anthropic":
        parts = data.get("content") or []
        return "\n".join(p.get("text", "") for p in parts if isinstance(p, dict))
    choices = data.get("choices") or []
    if choices:
        msg = choices[0].get("message") or {}
        return msg.get("content") or ""
    # Gemini-like fallback
    cands = data.get("candidates") or []
    if cands:
        parts = (((cands[0].get("content") or {}).get("parts")) or [])
        return "\n".join(p.get("text", "") for p in parts if isinstance(p, dict))
    return ""


def invoke_provider(cfg: AIProviderConfig, messages: list[dict[str, str]], task: str | None = None) -> ProviderResult:
    provider = (cfg.provider or "").lower()
    model = cfg.model
    if provider not in SUPPORTED_PROVIDERS:
        return ProviderResult(False, provider, model, error="unsupported_provider")
    if not cfg.enabled:
        return ProviderResult(False, provider, model, error="provider_disabled")
    api_key = _resolve_api_key(cfg.api_key_ref)
    if not api_key:
        return ProviderResult(False, provider, model, error="api_key_not_configured (use api_key_ref like env:PROVIDER_API_KEY)")
    base_url = cfg.base_url or _default_base_url(provider)
    if not base_url and provider != "google":
        return ProviderResult(False, provider, model, error="base_url_required")
    started = time.time()
    try:
        if provider in {"openai", "xai", "mistral", "deepseek", "openai_compatible"}:
            data = _call_openai_compatible(base_url or "", api_key, model, messages)
        elif provider == "anthropic":
            data = _call_anthropic(base_url or "", api_key, model, messages)
        elif provider == "google":
            # Gemini generateContent (API key as query param for simplicity; header auth may also be used depending on setup)
            url = f"{(base_url or _default_base_url('google')).rstrip('/')}/models/{model}:generateContent?key={api_key}"
            parts = [{"text": "\n".join(m.get("content","") for m in messages)}]
            data = _http_json("POST", url, {"Content-Type": "application/json"}, {"contents": [{"parts": parts}]})
        else:
            return ProviderResult(False, provider, model, error="adapter_not_implemented")
        text = _extract_text(provider, data)
        return ProviderResult(True, provider, model, text=text, latency_ms=round((time.time() - started) * 1000, 2), usage=data.get("usage") or {})
    except Exception as e:
        return ProviderResult(False, provider, model, error=str(e), latency_ms=round((time.time() - started) * 1000, 2))


def list_configs(db: Session) -> list[AIProviderConfig]:
    return db.execute(select(AIProviderConfig).order_by(AIProviderConfig.priority.asc(), AIProviderConfig.id.asc())).scalars().all()


def record_usage(db: Session, cfg: AIProviderConfig | None, task: str | None, result: ProviderResult) -> None:
    db.add(AIUsageRecord(
        provider_config_id=cfg.id if cfg else None, provider=result.provider, model=result.model, task=task,
        success=result.ok, latency_ms=result.latency_ms, error=(result.error or "")[:2000] if result.error else None,
        input_tokens=(result.usage or {}).get("input_tokens"), output_tokens=(result.usage or {}).get("output_tokens"),
    ))
    log_event(db, action="ai.invoke", message=f"AI {result.provider}/{result.model} {'ok' if result.ok else 'failed'}", severity="info" if result.ok else "warning",
              details={"task": task, "error": result.error, "latency_ms": result.latency_ms})
