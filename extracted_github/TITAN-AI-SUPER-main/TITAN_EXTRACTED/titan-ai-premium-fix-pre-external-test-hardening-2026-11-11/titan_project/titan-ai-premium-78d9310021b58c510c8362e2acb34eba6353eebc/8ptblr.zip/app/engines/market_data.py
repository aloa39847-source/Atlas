from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

from app.core.enums import DataSourceKind, EngineStatus, Timeframe
from app.core.config import settings
from app.data.binance_public import BinancePublicData
from .base import Engine


class Candles:
    """Lightweight pure-Python candle container (pandas-free for portability)."""

    def __init__(self, rows: list[dict[str, Any]]):
        self.rows = rows
        self._cols = {k: [r.get(k) for r in rows] for k in (rows[0].keys() if rows else ["timestamp", "open", "high", "low", "close", "volume"])}
        self.iloc = _ILoc(self)

    def __len__(self) -> int:
        return len(self.rows)

    def __getitem__(self, key: str):
        return self._cols[key]

    @property
    def columns(self):
        return list(self._cols.keys())

    def to_records(self) -> list[dict[str, Any]]:
        return list(self.rows)


class _ILoc:
    def __init__(self, c: Candles):
        self.c = c

    def __getitem__(self, idx: int) -> dict[str, Any]:
        return self.c.rows[idx]


@dataclass
class CandleBatch:
    symbol: str
    timeframe: Timeframe
    df: Candles
    source: DataSourceKind
    note: str


class MarketDataEngine(Engine):
    """Market data access layer.

    Labeled synthetic candles remain the default. Optional read-only Binance Spot/Futures public candles are enabled with TITAN_BINANCE_PUBLIC_DATA_ENABLED=true.
    """

    key = "market_data"
    name = "Market Data Engine"

    def status(self) -> EngineStatus:
        return EngineStatus.IMPLEMENTED_PARTIAL

    def get_synthetic_candles(self, symbol: str, timeframe: Timeframe, limit: int = 120, seed: int | None = None) -> CandleBatch:
        rng = random.Random(seed)
        tf_steps = {
            Timeframe.D1: (45000.0, 0.012),
            Timeframe.H4: (45000.0, 0.006),
            Timeframe.H1: (45000.0, 0.003),
            Timeframe.M15: (45000.0, 0.0015),
            Timeframe.M5: (45000.0, 0.0008),
        }
        base, vol = tf_steps.get(timeframe, (45000.0, 0.001))
        sym_offset = (sum(ord(c) for c in symbol) % 5000) - 2500
        price = base + sym_offset
        rows = []
        ts = datetime.now(timezone.utc).replace(second=0, microsecond=0)
        step_minutes = {"1d": 1440, "4h": 240, "1h": 60, "15m": 15, "5m": 5}[timeframe.value]
        for i in range(limit):
            drift = 0.0001 if (i % 11) < 6 else -0.00008
            shock = rng.gauss(0, vol)
            close = max(0.01, price * (1 + drift + shock))
            open_ = price
            high = max(open_, close) * (1 + abs(rng.gauss(0, vol / 2)))
            low = min(open_, close) * (1 - abs(rng.gauss(0, vol / 2)))
            volume = max(1.0, 100 + rng.gauss(0, 15) + (i % 7) * 3)
            rows.append(
                {
                    "timestamp": (ts - timedelta(minutes=step_minutes * (limit - i))).isoformat(),
                    "open": open_, "high": high, "low": min(low, open_, close), "close": close, "volume": volume,
                }
            )
            price = close
        return CandleBatch(
            symbol=symbol, timeframe=timeframe, df=Candles(rows),
            source=DataSourceKind.SYNTHETIC_LABELED,
            note="SYNTHETIC_LABELED data for development/testing only. NOT live market data.",
        )

    def __init__(self) -> None:
        self.public_data = BinancePublicData()
        self.use_live_public_data = settings.binance_public_data_enabled

    def get_multi_timeframe(self, symbol: str, limit: int = 120, seed: int | None = 42,
                            market_type: str = "spot") -> dict[Timeframe, CandleBatch]:
        timeframes = [Timeframe.D1, Timeframe.H4, Timeframe.H1, Timeframe.M15, Timeframe.M5]
        if not self.use_live_public_data:
            return {tf: self.get_synthetic_candles(symbol, tf, limit=limit, seed=(seed + i) if seed is not None else None)
                    for i, tf in enumerate(timeframes)}
        market = (market_type or "spot").lower()
        if market not in {"spot", "futures"}:
            raise ValueError("live_public_data_supports_spot_or_futures_only")
        now_ms = int(time.time() * 1000)
        tf_minutes = {Timeframe.D1: 1440, Timeframe.H4: 240, Timeframe.H1: 60, Timeframe.M15: 15, Timeframe.M5: 5}
        batches = {}
        for tf in timeframes:
            raw = self.public_data.get_klines(symbol, tf.value, limit=limit, market=market)
            candles = self.public_data.klines_to_candles(raw)
            closed = [c for c in candles if c.get("close_time", now_ms) < now_ms]
            if len(closed) < 30:
                raise RuntimeError(f"insufficient_closed_live_candles:{market}:{symbol}:{tf.value}")
            latest_age = now_ms - closed[-1]["close_time"]
            if latest_age > tf_minutes[tf] * 2 * 60_000:
                raise RuntimeError(f"stale_live_market_data:{market}:{symbol}:{tf.value}")
            rows = [{k: c[k] for k in ("timestamp", "open", "high", "low", "close", "volume")} for c in closed]
            batches[tf] = CandleBatch(
                symbol=symbol, timeframe=tf, df=Candles(rows), source=DataSourceKind.LIVE_PUBLIC,
                note=f"Live Binance public {market} candles; read-only, closed candles only; no API key required.",
            )
        return batches
