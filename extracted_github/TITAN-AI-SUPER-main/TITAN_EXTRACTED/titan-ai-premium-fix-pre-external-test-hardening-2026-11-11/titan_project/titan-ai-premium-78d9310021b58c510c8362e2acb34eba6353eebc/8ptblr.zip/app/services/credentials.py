"""Authenticated encryption for server-side Binance Testnet credentials.

A strong TITAN_SECRET_KEY is mandatory. No plaintext or reversible XOR obfuscation.
"""
from __future__ import annotations

import base64
import json
import os
from pathlib import Path
from typing import Any

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from app.core.config import settings


def _fernet() -> Fernet:
    secret = (settings.secret_key or "").encode()
    if len(secret) < 32 or settings.secret_key == "dev-only-change-locally":
        raise RuntimeError("strong_titan_secret_key_required_for_credential_storage")
    key = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=b"titan-ai-premium-credential-storage-v1",
        info=b"binance-testnet-api-credentials",
    ).derive(secret)
    return Fernet(base64.urlsafe_b64encode(key))


def encrypt_secret(text: str) -> str:
    if not text:
        return ""
    return _fernet().encrypt(text.encode("utf-8")).decode("ascii")


def decrypt_secret(token: str) -> str:
    if not token:
        return ""
    try:
        return _fernet().decrypt(token.encode("ascii")).decode("utf-8")
    except (InvalidToken, UnicodeError, ValueError, RuntimeError):
        return ""
    except Exception:
        return ""


def _storage_path() -> Path:
    base = Path(__file__).resolve().parents[2] / "data"
    base.mkdir(parents=True, exist_ok=True)
    return base / "binance_testnet_creds.json"


def save_testnet_credentials(api_key: str, api_secret: str, market: str = "spot") -> dict[str, Any]:
    key = (api_key or "").strip()
    secret = (api_secret or "").strip()
    mkt = (market or "spot").strip().lower()
    if mkt not in {"spot", "futures"}:
        raise ValueError("unsupported_testnet_market")
    if not key or not secret:
        raise ValueError("api_key_and_secret_required")
    # Validate key strength before writing anything.
    cipher_key = encrypt_secret(key)
    cipher_secret = encrypt_secret(secret)
    data = {
        "version": 1,
        "algorithm": "fernet-hkdf-sha256",
        "market": mkt,
        "api_key_enc": cipher_key,
        "api_secret_enc": cipher_secret,
        "has_key": True,
        "has_secret": True,
    }
    path = _storage_path()
    tmp = path.with_suffix(path.suffix + ".tmp")
    try:
        tmp.write_text(json.dumps(data, separators=(",", ":")), encoding="utf-8")
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
        os.chmod(path, 0o600)
    finally:
        if tmp.exists():
            tmp.unlink()
    return {"ok": True, "saved": True, "market": mkt,
            "note": "Authenticated encryption enabled; secret values are never returned."}


def load_testnet_credentials() -> dict[str, Any]:
    path = _storage_path()
    if not path.exists():
        return {"configured": False}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if data.get("version") != 1 or data.get("algorithm") != "fernet-hkdf-sha256":
            return {"configured": False, "reason": "credential_format_upgrade_required"}
        market = data.get("market", "spot")
        if market not in {"spot", "futures"}:
            return {"configured": False, "reason": "invalid_credential_market"}
        api_key = decrypt_secret(data.get("api_key_enc", ""))
        api_secret = decrypt_secret(data.get("api_secret_enc", ""))
        configured = bool(data.get("has_key") and data.get("has_secret") and api_key and api_secret)
        return {"configured": configured, "market": market,
                "api_key": api_key if configured else "",
                "api_secret": api_secret if configured else ""}
    except Exception:
        return {"configured": False}


def delete_testnet_credentials() -> dict[str, Any]:
    path = _storage_path()
    if path.exists():
        path.unlink()
    tmp = path.with_suffix(path.suffix + ".tmp")
    if tmp.exists():
        tmp.unlink()
    return {"ok": True, "deleted": True}


def public_status() -> dict[str, Any]:
    creds = load_testnet_credentials()
    return {
        "configured": creds.get("configured", False),
        "market": creds.get("market", "spot"),
        "has_secret": bool(creds.get("configured")),
        "encryption": "fernet-hkdf-sha256",
    }
