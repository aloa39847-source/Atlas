"""Auditable prediction tracking and performance evaluation.

This service records model decisions and evaluates only explicitly resolved
outcomes. Unverified outcomes never count toward trusted accuracy metrics or
learning-promotion evidence.
"""
from __future__ import annotations

from datetime import datetime, timezone
from math import isfinite
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.entities import PredictionRecord, PositionRecord


DIRECTION_MAP = {"buy": "bullish", "long": "bullish", "sell": "bearish", "short": "bearish"}


def _valid_price(value: Any) -> float | None:
    try:
        price = float(value)
    except (TypeError, ValueError):
        return None
    return price if isfinite(price) and price > 0 else None


class PredictionTrackingService:
    """Persist directional forecasts with a reproducible reference price."""

    def record_decision(
        self, db: Session, *, decision_id: int, symbol: str, environment_mode: str,
        market_type: str, action: str, confidence: float | None, reference_price: float,
        horizon: str = "5m", strategy: str | None = None, data_source: str = "unknown",
        stop_loss: float | None = None, take_profit: float | None = None,
    ) -> PredictionRecord | None:
        direction = DIRECTION_MAP.get(str(action or "").lower())
        reference = _valid_price(reference_price)
        if direction is None or reference is None:
            return None
        try:
            conf = float(confidence) if confidence is not None else None
        except (TypeError, ValueError):
            conf = None
        if conf is not None and (not isfinite(conf) or conf < 0 or conf > 1):
            conf = None
        row = PredictionRecord(
            symbol=symbol.strip().upper(), environment_mode=environment_mode,
            market_type=market_type, horizon=horizon, scenario="base",
            predicted_direction=direction, confidence=conf,
            assumptions={
                "decision_id": int(decision_id), "reference_price": reference,
                "strategy": strategy, "data_source": data_source,
                "stop_loss": _valid_price(stop_loss), "take_profit": _valid_price(take_profit),
                "resolution_policy": "Compare observed price at the declared horizon; no future data used at creation.",
            },
            verified=False,
        )
        db.add(row)
        db.flush()
        return row

    def resolve(self, db: Session, *, prediction_id: int, observed_price: float,
                outcome_source: str) -> dict[str, Any]:
        row = db.get(PredictionRecord, prediction_id)
        if row is None:
            return {"ok": False, "error": "prediction_not_found"}
        if row.resolved_at is not None:
            return {"ok": False, "error": "prediction_already_resolved"}
        observed = _valid_price(observed_price)
        reference = _valid_price((row.assumptions or {}).get("reference_price"))
        if observed is None or reference is None:
            return {"ok": False, "error": "valid_observed_and_reference_prices_required"}
        source = str(outcome_source or "").strip()
        if len(source) < 3:
            return {"ok": False, "error": "outcome_source_required"}
        actual = "bullish" if observed > reference else "bearish" if observed < reference else "neutral"
        correct = actual == row.predicted_direction
        row.outcome = {
            "observed_price": observed, "reference_price": reference,
            "actual_direction": actual, "correct": correct,
            "price_change_pct": round((observed / reference - 1.0) * 100.0, 8),
            "source": source, "verification_status": "pending_admin_review",
        }
        row.resolved_at = datetime.now(timezone.utc)
        row.verified = False
        db.add(row)
        db.flush()
        return {
            "ok": True, "prediction_id": row.id, "correct": correct,
            "actual_direction": actual, "verified": False,
            "note": "Outcome is recorded but excluded from trusted metrics until an administrator verifies its evidence.",
        }

    def verify(self, db: Session, *, prediction_id: int, verification_notes: str) -> dict[str, Any]:
        row = db.get(PredictionRecord, prediction_id)
        if row is None:
            return {"ok": False, "error": "prediction_not_found"}
        if row.resolved_at is None or not isinstance(row.outcome, dict):
            return {"ok": False, "error": "resolved_outcome_required"}
        notes = str(verification_notes or "").strip()
        if len(notes) < 20:
            return {"ok": False, "error": "verification_notes_minimum_20_characters"}
        row.verified = True
        row.outcome = {
            **row.outcome, "verification_status": "manual_admin_review",
            "verification_notes": notes, "verified_at": datetime.now(timezone.utc).isoformat(),
        }
        db.add(row)
        db.flush()
        return {"ok": True, "prediction_id": row.id, "verified": True}


class PerformanceEvaluationService:
    """Compute transparent metrics from verified forecasts and closed shadow positions."""

    def summary(self, db: Session, *, environment_mode: str | None = None,
                market_type: str | None = None, symbol: str | None = None) -> dict[str, Any]:
        prediction_query = select(PredictionRecord)
        position_query = select(PositionRecord).where(
            PositionRecord.status == "closed", PositionRecord.shadow.is_(True)
        )
        if environment_mode:
            prediction_query = prediction_query.where(PredictionRecord.environment_mode == environment_mode)
            position_query = position_query.where(PositionRecord.environment_mode == environment_mode)
        if market_type:
            prediction_query = prediction_query.where(PredictionRecord.market_type == market_type)
            position_query = position_query.where(PositionRecord.market_type == market_type)
        if symbol:
            normalized = symbol.strip().upper()
            prediction_query = prediction_query.where(PredictionRecord.symbol == normalized)
            position_query = position_query.where(PositionRecord.symbol == normalized)
        predictions = db.execute(prediction_query.order_by(PredictionRecord.created_at)).scalars().all()
        resolved = [p for p in predictions if p.resolved_at is not None and isinstance(p.outcome, dict)]
        trusted = [p for p in resolved if p.verified]
        correct = [p for p in trusted if p.outcome.get("correct") is True]
        brier_values = [
            (float(p.confidence) - (1.0 if p.outcome["correct"] else 0.0)) ** 2
            for p in trusted
            if p.confidence is not None and p.outcome.get("correct") in (True, False)
        ]
        positions = db.execute(position_query.order_by(PositionRecord.updated_at)).scalars().all()
        net_pnls = [float(p.realized_pnl or 0.0) - float(p.fees_total or 0.0) for p in positions]
        wins = [pnl for pnl in net_pnls if pnl > 0]
        losses = [pnl for pnl in net_pnls if pnl < 0]
        gross_profit, gross_loss = sum(wins), abs(sum(losses))
        cumulative_pnl = peak_pnl = max_drawdown_quote = 0.0
        for pnl in net_pnls:
            cumulative_pnl += pnl
            peak_pnl = max(peak_pnl, cumulative_pnl)
            max_drawdown_quote = max(max_drawdown_quote, peak_pnl - cumulative_pnl)
        return {
            "filters": {"environment_mode": environment_mode, "market_type": market_type, "symbol": symbol},
            "predictions": {
                "total": len(predictions), "resolved": len(resolved), "verified": len(trusted),
                "unverified_resolved": len(resolved) - len(trusted),
                "directional_accuracy": round(len(correct) / len(trusted), 6) if trusted else None,
                "brier_score": round(sum(brier_values) / len(brier_values), 6) if brier_values else None,
                "note": "Only manually verified outcomes contribute to accuracy and Brier score.",
            },
            "closed_positions": {
                "count": len(positions), "net_pnl_after_fees": round(sum(net_pnls), 8),
                "win_rate": round(len(wins) / len(positions), 6) if positions else None,
                "profit_factor": round(gross_profit / gross_loss, 6) if gross_loss else (None if gross_profit else 0.0),
                "expectancy": round(sum(net_pnls) / len(net_pnls), 8) if net_pnls else None,
                "max_drawdown_quote": round(max_drawdown_quote, 8),
                "scope": "closed_shadow_positions_only",
                "note": "Uses closed shadow PositionRecord values after recorded fees; drawdown is an absolute quote-currency amount, not a percentage or exchange-reconciled account statement.",
            },
        }


prediction_tracking = PredictionTrackingService()
performance_evaluation = PerformanceEvaluationService()
