"""E2E Trading Cycle Orchestrator - Manual trigger only, no auto-loop.
Requires explicit call. Uses testnet when configured; defaults to shadow/safe mode.
"""
from __future__ import annotations
from typing import Any
from datetime import datetime, timezone

from app.core.enums import EnvironmentMode, MarketType
from app.services.core_service import core_service
from app.services.shadow_trading import ShadowTradingService
from app.services.position_management import position_management


class TradingOrchestrator:
    def __init__(self):
        self.shadow = ShadowTradingService()

    def run_cycle(self, db, *, symbol: str, market: str = "spot", environment: str = "demo", execute_testnet: bool = False, max_data_age_seconds: int = 300) -> dict[str, Any]:
        # The core analysis path owns data validation and provenance. Do not fetch
        # the same five timeframes twice or silently continue after feed failure.
        try:
            analysis = core_service.analyze(db, symbol=symbol, market_type=market, environment_mode=environment)
        except Exception as e:
            return {"ok": False, "error": "analysis_failed", "detail": str(e), "executed": False,
                    "execution_mode": "blocked"}
        action = analysis.get("action", "wait")

        # Existing shadow protection rules are evaluated only against explicitly
        # labeled live-public market prices, never synthetic or unknown candles.
        protection_events = []
        price_source = analysis.get("market_price_source")
        prices = analysis.get("market_prices") or {}
        if price_source == "live_public" and isinstance(prices, dict) and prices:
            try:
                triggered = position_management.evaluate_prices(
                    db, prices=prices, environment_mode=environment, market_type=market,
                )
                for event in triggered:
                    closed = self.shadow.close_shadow_position(
                        db, position_id=event["position_id"], close_price=event["price"],
                    )
                    protection_events.append({**event, "close_result": closed})
                if triggered:
                    db.commit()
            except Exception as e:
                db.rollback()
                protection_events.append({
                    "ok": False, "error": "shadow_protection_processing_failed",
                    "detail": str(e), "new_order_sent": False,
                })

        # Step 2: Risk/Compliance already in decision flow
        result = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "symbol": symbol,
            "market": market,
            "environment": environment,
            "analysis_action": action,
            "decision": analysis,
            "executed": False,
            "execution_mode": "none",
            "protection_events": protection_events,
            "protection_monitoring": {
                "evaluated": bool(price_source == "live_public" and prices),
                "price_source": price_source or "unknown",
                "note": "Shadow-only protection close; synthetic/unknown market prices are never used to trigger closes.",
            },
        }
        
        # Step 3: Shadow simulation only. No external Testnet/Live order is sent here.
        if action in ("buy", "long", "short", "sell") and execute_testnet and environment != "live":
            reference_price = analysis.get("entry_price")
            decision_id = analysis.get("decision_id")
            if market == "spot" and action == "sell":
                result["execution_mode"] = "blocked_spot_sell_requires_inventory_sync"
                result["execution_result"] = {"ok": False, "reason": "spot_sell_requires_verified_inventory"}
            elif not reference_price or float(reference_price) <= 0 or not decision_id:
                result["execution_mode"] = "blocked_missing_reference_price_or_decision_id"
                result["execution_result"] = {"ok": False, "reason": "verified_entry_price_and_decision_id_required"}
            else:
                hard_cap = 80.0 if market == "spot" else 800.0 if market == "futures" else 0.0
                quantity = min(0.001, (hard_cap * 0.95) / float(reference_price)) if hard_cap > 0 else 0.0
                shadow_res = self.shadow.create_shadow_order(
                    db, env=environment, market=market, symbol=symbol,
                    side="buy" if action in ("buy", "long") else "sell",
                    order_type="market", quantity=quantity, reference_price=float(reference_price),
                    idempotency_key=f"cycle-{decision_id}", simulate="fill"
                )
                order_status = getattr(shadow_res.order, "status", None)
                did_fill = bool(shadow_res.ok and order_status in {"filled", "partially_filled"})
                result["executed"] = did_fill
                result["execution_mode"] = "shadow_simulation" if did_fill else ("shadow_not_filled" if shadow_res.ok else "blocked")
                result["execution_result"] = {
                    "ok": shadow_res.ok, "message": shadow_res.message,
                    "status": order_status, "order_id": getattr(shadow_res.order, "id", None),
                    "details": shadow_res.details,
                }

        return result
