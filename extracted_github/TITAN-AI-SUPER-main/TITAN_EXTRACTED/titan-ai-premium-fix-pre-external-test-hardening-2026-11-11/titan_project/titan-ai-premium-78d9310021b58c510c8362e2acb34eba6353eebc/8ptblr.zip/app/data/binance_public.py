"""Read-only Binance public market-data adapter for Spot and USD-M Futures."""
from __future__ import annotations

import json
import urllib.parse
import urllib.request
from typing import Any


class BinancePublicData:
    SPOT_BASE = "https://api.binance.com"
    FUTURES_BASE = "https://fapi.binance.com"
    ALLOWED_MARKETS = {"spot", "futures"}
    ALLOWED_INTERVALS = {"1d", "4h", "1h", "15m", "5m"}

    def get_klines(self, symbol: str, interval: str, limit: int = 500, market: str = "spot") -> list[list[Any]]:
        market = (market or "spot").lower()
        if market not in self.ALLOWED_MARKETS:
            raise ValueError("unsupported_market_for_public_klines")
        if interval not in self.ALLOWED_INTERVALS:
            raise ValueError("unsupported_kline_interval")
        limit = max(30, min(int(limit), 1000))
        base = self.FUTURES_BASE if market == "futures" else self.SPOT_BASE
        path = "/fapi/v1/klines" if market == "futures" else "/api/v3/klines"
        query = urllib.parse.urlencode({"symbol": symbol.replace("/", "").upper(), "interval": interval, "limit": limit})
        url = f"{base}{path}?{query}"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "TITAN-AI-PREMIUM/1.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
            if not isinstance(data, list):
                raise RuntimeError("unexpected_kline_response")
            return data
        except Exception as e:
            raise RuntimeError(f"binance_public_error:{e}") from e

    def get_ticker_price(self, symbol: str, market: str = "spot") -> float:
        market = (market or "spot").lower()
        if market not in self.ALLOWED_MARKETS:
            raise ValueError("unsupported_market_for_public_ticker")
        base = self.FUTURES_BASE if market == "futures" else self.SPOT_BASE
        path = "/fapi/v1/ticker/price" if market == "futures" else "/api/v3/ticker/price"
        query = urllib.parse.urlencode({"symbol": symbol.replace("/", "").upper()})
        url = f"{base}{path}?{query}"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "TITAN-AI-PREMIUM/1.0"})
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read().decode())
            price = float(data["price"])
            if price <= 0:
                raise ValueError("invalid_public_ticker_price")
            return price
        except Exception as e:
            raise RuntimeError(f"binance_public_ticker_error:{e}") from e

    def klines_to_candles(self, klines: list[list[Any]]) -> list[dict]:
        candles = []
        for k in klines:
            if not isinstance(k, (list, tuple)) or len(k) < 7:
                continue
            candles.append({
                "timestamp": int(k[0]),
                "open": float(k[1]),
                "high": float(k[2]),
                "low": float(k[3]),
                "close": float(k[4]),
                "volume": float(k[5]),
                "close_time": int(k[6]),
                "source": "binance_public",
            })
        return candles
