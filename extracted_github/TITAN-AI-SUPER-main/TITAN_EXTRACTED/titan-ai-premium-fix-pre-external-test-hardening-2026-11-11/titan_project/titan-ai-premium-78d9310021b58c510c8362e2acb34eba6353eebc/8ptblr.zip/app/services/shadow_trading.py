from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.enums import MarketType
from app.engines.order_gateway import PreTradeOrderGateway
from app.engines.risk import RiskEngine
from app.models.entities import OrderRecord, PortfolioSnapshot, PositionRecord, SystemState
from .audit import log_event


@dataclass
class ShadowFillResult:
    ok: bool
    order: OrderRecord | None
    position: PositionRecord | None
    message: str
    details: dict[str, Any]


class ShadowTradingService:
    """Shadow/demo order lifecycle. No real exchange orders.

    Lifecycle: validate (compliance+gateway+risk) -> create shadow order -> simulate fill/cancel/partial
    -> update position/portfolio -> audit/log. Idempotency keys prevent duplicate orders.
    """

    def __init__(self) -> None:
        self.gateway = PreTradeOrderGateway()
        self.risk = RiskEngine()

    def _get_or_create_position(self, db: Session, *, env: str, market: str, symbol: str, side: str, shadow: bool) -> PositionRecord:
        q = select(PositionRecord).where(
            PositionRecord.environment_mode == env, PositionRecord.market_type == market,
            PositionRecord.symbol == symbol, PositionRecord.side == side, PositionRecord.status == "open", PositionRecord.shadow == shadow,
        )
        pos = db.execute(q).scalar_one_or_none()
        if not pos:
            pos = PositionRecord(environment_mode=env, market_type=market, symbol=symbol, side=side, quantity=0.0, status="open", shadow=shadow, leverage=1.0)
            db.add(pos); db.flush()
        return pos

    def _snapshot(self, db: Session, *, env: str, market: str, cash: float = 10000.0) -> PortfolioSnapshot:
        all_positions = db.execute(select(PositionRecord).where(
            PositionRecord.environment_mode == env, PositionRecord.market_type == market
        )).scalars().all()
        open_positions = [p for p in all_positions if p.status == "open" and p.quantity > 0]
        orders = db.execute(select(OrderRecord).where(
            OrderRecord.environment_mode == env, OrderRecord.market_type == market
        )).scalars().all()
        exposure = sum(abs((p.mark_price or p.entry_avg_price or 0) * p.quantity) for p in open_positions)
        unreal = sum(p.unrealized_pnl for p in open_positions)
        # Position records carry aggregate realized gross PnL and all entry/exit fees.
        # Do not add OrderRecord.fees_paid again: entry fees are already included.
        realized = sum(p.realized_pnl for p in all_positions)
        fees = sum(p.fees_total for p in all_positions)
        snap = PortfolioSnapshot(environment_mode=env, market_type=market, cash_balance=cash, equity_estimate=cash + unreal + realized - fees,
                                 unrealized_pnl=unreal, realized_pnl=realized, fees_total=fees, exposure_notional=exposure,
                                 positions_open=len(open_positions), details={"order_count": len(orders)})
        db.add(snap); db.flush()
        return snap

    def create_shadow_order(self, db: Session, *, env: str, market: str, symbol: str, side: str, order_type: str,
                            quantity: float, price: float | None = None, reference_price: float | None = None,
                            idempotency_key: str | None = None, simulate: str = "fill", fill_ratio: float = 1.0,
                            fee_rate: float = 0.001, mark_price: float | None = None) -> ShadowFillResult:
        mkt = MarketType(market)
        idem = (idempotency_key or "").strip() or f"shadow-{uuid.uuid4().hex}"
        existing = db.execute(select(OrderRecord).where(OrderRecord.idempotency_key == idem)).scalar_one_or_none()
        if existing:
            return ShadowFillResult(True, existing, None, "duplicate_idempotency_returned_existing", {"duplicate": True, "order_id": existing.id})
        state = db.get(SystemState, 1)
        if state is None:
            return ShadowFillResult(False, None, None, "system_state_unavailable", {"blocked": True})
        if state.emergency_stop:
            log_event(db, action="shadow.order_blocked_emergency_stop", severity="warning",
                      message="Emergency stop active; new shadow order blocked.",
                      environment_mode=env, market_type=market, details={"symbol": symbol, "side": side})
            return ShadowFillResult(False, None, None, "emergency_stop_active", {"blocked": True})
        pre = self.gateway.validate(symbol=symbol, market=mkt, side=side, order_type=order_type, quantity=quantity, price=price,
                                    reference_price=reference_price or price, idempotency_key=idem, environment_mode=env, live_enabled=False)
        if not pre.ok:
            log_event(db, action="shadow.order_rejected", severity="warning", message=pre.reason, environment_mode=env, market_type=market, details=pre.normalized)
            return ShadowFillResult(False, None, None, pre.reason, {"precheck": pre.to_dict()})
        order = OrderRecord(environment_mode=env, market_type=market, symbol=symbol, side=side.lower(), order_type=order_type.lower(),
                            quantity=quantity, price=price, status="submitted", shadow=True, idempotency_key=idem, client_order_id=f"sim-{idem[:24]}",
                            reason="shadow simulation", metadata_json={"precheck": pre.to_dict(), "simulate": simulate})
        db.add(order); db.flush()
        if simulate == "connection_loss":
            order.status = "submitted"
            order.reason = "shadow submitted; connection loss simulated - reconciliation required before retry"
            db.add(order); self._snapshot(db, env=env, market=market)
            log_event(db, action="shadow.connection_loss", severity="warning", message="Shadow order submitted with simulated connection loss.", entity_type="order", entity_id=str(order.id))
            return ShadowFillResult(True, order, None, "connection_loss_simulated", {"reconcile_required": True, "idempotency_key": idem})
        if simulate == "cancel":
            order.status = "cancelled"; order.reason = "shadow cancelled"
            db.add(order); self._snapshot(db, env=env, market=market)
            log_event(db, action="shadow.cancelled", entity_type="order", entity_id=str(order.id))
            return ShadowFillResult(True, order, None, "cancelled", {})
        if simulate == "reject":
            order.status = "rejected"; order.reason = "shadow rejected by simulator"
            db.add(order); self._snapshot(db, env=env, market=market)
            return ShadowFillResult(False, order, None, "rejected", {})
        # fill / partial
        ratio = max(0.0, min(1.0, float(fill_ratio)))
        fill_px = float(price or reference_price or 0.0)
        filled = quantity * ratio
        order.filled_quantity = filled
        order.avg_fill_price = fill_px if filled > 0 else None
        order.status = "filled" if ratio >= 1.0 else ("partially_filled" if ratio > 0 else "submitted")
        notional = filled * fill_px
        order.fees_paid = round(notional * fee_rate, 8)
        db.add(order)
        pos = None
        if filled > 0 and fill_px > 0:
            pos_side = "long_spot" if mkt == MarketType.SPOT else side.lower()
            pos = self._get_or_create_position(db, env=env, market=market, symbol=symbol, side=pos_side, shadow=True)
            # simple average-entry update for adds; closes/reductions would be handled by execution engine later
            prev_qty = pos.quantity; prev_avg = pos.entry_avg_price or 0.0
            new_qty = prev_qty + filled
            pos.entry_avg_price = ((prev_avg * prev_qty) + (fill_px * filled)) / new_qty if new_qty else fill_px
            pos.quantity = new_qty
            pos.mark_price = mark_price or fill_px
            pos.fees_total += order.fees_paid
            if pos.mark_price and pos.entry_avg_price:
                # simplified unrealized pnl for long-style shadow positions
                direction = 1.0 if pos_side in {"long_spot", "long", "buy"} else -1.0
                pos.unrealized_pnl = round(direction * (pos.mark_price - pos.entry_avg_price) * pos.quantity, 8)
            db.add(pos)
        snap = self._snapshot(db, env=env, market=market)
        log_event(db, action="shadow.order_filled" if ratio >= 1 else "shadow.order_partial", entity_type="order", entity_id=str(order.id),
                  details={"filled": filled, "avg_fill_price": fill_px, "fees": order.fees_paid, "snapshot_id": snap.id})
        return ShadowFillResult(True, order, pos, order.status, {"snapshot_id": snap.id, "fees_paid": order.fees_paid})

    def get_portfolio(self, db: Session, *, env: str, market: str) -> dict[str, Any]:
        snap = self._snapshot(db, env=env, market=market)
        positions = db.execute(select(PositionRecord).where(PositionRecord.environment_mode == env, PositionRecord.market_type == market, PositionRecord.status == "open")).scalars().all()
        orders = db.execute(select(OrderRecord).where(OrderRecord.environment_mode == env, OrderRecord.market_type == market).order_by(OrderRecord.id.desc()).limit(50)).scalars().all()
        return {
            "snapshot": {"id": snap.id, "cash_balance": snap.cash_balance, "equity_estimate": snap.equity_estimate, "unrealized_pnl": snap.unrealized_pnl,
                         "realized_pnl": snap.realized_pnl, "fees_total": snap.fees_total, "exposure_notional": snap.exposure_notional, "positions_open": snap.positions_open},
            "positions": [{"id": p.id, "symbol": p.symbol, "side": p.side, "quantity": p.quantity, "entry_avg_price": p.entry_avg_price, "mark_price": p.mark_price,
                           "unrealized_pnl": p.unrealized_pnl, "realized_pnl": p.realized_pnl, "fees_total": p.fees_total, "status": p.status, "shadow": p.shadow} for p in positions],
            "orders": [{"id": o.id, "symbol": o.symbol, "side": o.side, "type": o.order_type, "quantity": o.quantity, "filled_quantity": o.filled_quantity,
                        "price": o.price, "avg_fill_price": o.avg_fill_price, "status": o.status, "shadow": o.shadow, "fees_paid": o.fees_paid, "idempotency_key": o.idempotency_key} for o in orders],
        }


    def close_shadow_position(self, db: Session, *, position_id: int, close_price: float, fee_rate: float = 0.001) -> dict[str, Any]:
        pos = db.get(PositionRecord, position_id)
        if not pos or pos.status != "open":
            return {"ok": False, "reason": "position_not_found_or_not_open"}
        if not pos.shadow:
            return {"ok": False, "reason": "real_position_close_not_supported_by_shadow_service"}
        try:
            close_price = float(close_price)
            fee_rate = float(fee_rate)
        except (TypeError, ValueError):
            return {"ok": False, "reason": "invalid_close_price_or_fee_rate"}
        if not __import__("math").isfinite(close_price) or close_price <= 0:
            return {"ok": False, "reason": "positive_finite_close_price_required"}
        if not __import__("math").isfinite(fee_rate) or fee_rate < 0 or fee_rate > 0.05:
            return {"ok": False, "reason": "fee_rate_out_of_range"}
        notional = abs(pos.quantity * close_price)
        fee = round(notional * fee_rate, 8)
        direction = 1.0 if pos.side in {"long_spot", "long", "buy"} else -1.0
        realized_gross = round(direction * (close_price - (pos.entry_avg_price or close_price)) * pos.quantity, 8)
        realized_net = round(realized_gross - fee, 8)
        pos.realized_pnl += realized_gross
        pos.fees_total += fee
        pos.unrealized_pnl = 0.0
        pos.mark_price = close_price
        pos.status = "closed"
        pos.quantity = 0.0
        db.add(pos)
        snap = self._snapshot(db, env=pos.environment_mode, market=pos.market_type)
        log_event(db, action="shadow.position_closed", entity_type="position", entity_id=str(pos.id),
                  details={"close_price": close_price, "realized_pnl_gross": realized_gross, "realized_pnl_net": realized_net,
                           "fee": fee, "snapshot_id": snap.id})
        return {"ok": True, "position_id": pos.id, "realized_pnl": realized_net,
                "realized_pnl_gross": realized_gross, "fee": fee, "snapshot_id": snap.id}
