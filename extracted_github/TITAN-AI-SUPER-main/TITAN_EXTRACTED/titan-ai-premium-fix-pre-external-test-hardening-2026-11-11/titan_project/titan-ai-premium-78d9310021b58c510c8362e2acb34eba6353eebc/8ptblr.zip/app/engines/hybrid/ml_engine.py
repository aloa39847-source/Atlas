"""Machine Learning Component - Explainable pattern recognition
Auditable, testable, no black-box magic.
"""
from __future__ import annotations

from typing import Any, Sequence

from app.core.enums import EngineStatus
from app.engines.base import Engine


class MLEngine(Engine):
    key = "ml_engine"
    name = "Machine Learning Pattern Engine"

    def status(self):
        return EngineStatus.IMPLEMENTED_PARTIAL

    def detect_patterns(self, candles: Sequence[dict]) -> dict[str, Any]:
        if not candles or len(candles) < 5:
            return {"patterns": [], "confidence": 0.0}
        patterns = []
        # Simple explainable patterns
        c = candles
        # Higher highs/lows detection
        if len(c) >= 3:
            if float(c[-1]["high"]) > float(c[-2]["high"]) > float(c[-3]["high"]):
                patterns.append({"name": "ascending_sequence", "type": "structure", "confidence": 0.6})
            if float(c[-1]["low"]) > float(c[-2]["low"]) > float(c[-3]["low"]):
                patterns.append({"name": "higher_lows", "type": "structure", "confidence": 0.6})
        # Volume pattern
        vols = [float(x.get("volume", 0)) for x in c[-10:]]
        if vols and max(vols) == vols[-1] and vols[-1] > sum(vols[:-1]) / max(1, len(vols[:-1])):
            patterns.append({"name": "volume_spike", "type": "volume", "confidence": 0.55})
        conf = sum(p["confidence"] for p in patterns) / len(patterns) if patterns else 0.0
        return {"patterns": patterns, "confidence": round(conf, 3), "explainable": True}

    def probability_estimate(self, features: dict[str, Any]) -> dict[str, Any]:
        # Simple weighted probabilistic estimate - fully explainable
        score = 0.0
        weights = []
        if features.get("trend_bull"):
            score += 0.2
            weights.append("trend_bull:+0.2")
        if features.get("rsi_ok"):
            score += 0.1
            weights.append("rsi_ok:+0.1")
        if features.get("volume_ok"):
            score += 0.15
            weights.append("volume_ok:+0.15")
        if features.get("structure_bull"):
            score += 0.2
            weights.append("structure_bull:+0.2")
        prob = min(0.95, max(0.05, score))
        return {
            "prob_up": round(prob, 3),
            "prob_down": round(1 - prob, 3),
            "weights": weights,
            "explainable": True,
            "model": "explainable_weighted_v1",
        }
