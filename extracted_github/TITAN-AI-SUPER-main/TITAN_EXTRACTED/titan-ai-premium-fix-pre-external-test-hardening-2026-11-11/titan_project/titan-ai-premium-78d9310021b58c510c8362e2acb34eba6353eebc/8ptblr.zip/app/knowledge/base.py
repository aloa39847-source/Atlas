from __future__ import annotations

from dataclasses import asdict, dataclass, field
import json
from pathlib import Path
from typing import Any


@dataclass
class KnowledgeConcept:
    key: str
    category: str
    title: str
    summary: str
    details: list[str]
    tags: list[str]
    caution: str = ""
    confidence_note: str = "Educational/system knowledge entry. Validate in current market context and with tested data."
    source_keys: list[str] = field(default_factory=list)
    verified: bool = False
    confidence: float = 0.0


# Curated foundational knowledge (extensible). Not exhaustive; sources/verification workflow managed via KnowledgeSource records.
SEED_CONCEPTS: list[KnowledgeConcept] = [
    KnowledgeConcept("market_structure_bos", "market_structure", "Break of Structure (BOS)",
        "BOS indicates potential continuation when price breaks a relevant structural high/low in trend direction.",
        ["Confirm with candle close/context, not just wick.", "Check higher-timeframe bias (1D/4H).", "Evaluate volume, momentum, and retest behavior.", "Distinguish from liquidity sweep/fakeout."],
        ["BOS", "HH", "HL", "LH", "LL", "trend"], "A raw level break can be a trap; use multi-factor confirmation."),
    KnowledgeConcept("market_structure_choch", "market_structure", "Change of Character (CHOCH/MSS)",
        "CHOCH/MSS suggests possible trend shift when structure breaks against the prevailing sequence.",
        ["Look for break of key swing after liquidity grab or momentum loss.", "Validate with displacement, retest, and timeframe alignment.", "Do not assume reversal from one signal."],
        ["CHOCH", "MSS", "reversal"], "Early reversal signals have lower reliability in strong trends."),
    KnowledgeConcept("liquidity_sweep", "liquidity", "Liquidity Sweep / Stop Hunt",
        "Price may probe areas where stops/liquidity rest (equal highs/lows, obvious swings) before moving.",
        ["Watch reaction after sweep: rejection, close back inside range, structure shift.", "Combine with volume/spread and session timing.", "Equal highs/lows can act as liquidity pools."],
        ["liquidity", "sweep", "equal highs", "equal lows"], "Liquidity concepts are often inferred; distinguish observable data from interpretation."),
    KnowledgeConcept("breakout_quality", "price_action", "True vs False Breakout",
        "Breakout quality depends on close, volume, momentum, retest, context, and liquidity behavior.",
        ["True breakout: acceptance beyond level, supportive volume/momentum, successful retest possible.", "False breakout/fakeout: wick beyond level then rejection back into range.", "Bull/Bear traps occur when breakout participants are forced to exit."],
        ["breakout", "fakeout", "retest", "trap"], "No breakout rule is universal; always manage risk."),
    KnowledgeConcept("candlestick_context", "candlesticks", "Candlestick Analysis in Context",
        "Candlestick patterns must be read with body/wicks, close location, volume, and market structure.",
        ["Hammer/shooting star need context near key levels.", "Engulfing patterns are stronger with displacement and volume.", "Doji indicates indecision, not automatic reversal.", "Inside bar often signals compression; breakout direction needs confirmation."],
        ["candles", "pin bar", "engulfing", "doji"], "Pattern names alone are insufficient for trade decisions."),
    KnowledgeConcept("risk_management_core", "risk", "Core Risk Management",
        "Risk management defines survival: position sizing, stop placement, leverage limits, and total exposure.",
        ["Risk per trade should be bounded and configurable.", "Use stop-loss based on invalidation, not arbitrary distance.", "Calculate net outcome after fees/slippage/funding.", "Futures leverage increases liquidation risk; caps must be enforced."],
        ["risk", "position sizing", "stop loss", "R:R", "leverage"], "High confidence does not justify excessive risk."),
    KnowledgeConcept("multi_timeframe", "analysis", "Multi-Timeframe Analysis (1D/4H/1H/15M/5M)",
        "Use higher timeframes for bias/context and lower timeframes for setup/timing.",
        ["1D: primary trend/regime. 4H: confirmation. 1H: structure/zones. 15M: setup. 5M: execution timing/scalping.", "Handle conflicts by reducing risk or waiting.", "Prefer closed candles for confirmation when avoiding noise."],
        ["MTF", "1D", "4H", "1H", "15M", "5M"], "Timeframe alignment improves clarity but does not guarantee outcomes."),
    KnowledgeConcept("volume_orderflow", "volume", "Volume and Order Flow (Data-Dependent)",
        "Volume and order flow can confirm participation, absorption, exhaustion, and breakout quality when reliable data exists.",
        ["Relative volume and spikes add context.", "Order book/CVD/delta require reliable exchange data feeds.", "Label inferred liquidity/order-flow assumptions clearly."],
        ["volume", "order flow", "CVD", "order book"], "Many microstructure signals require data not available in synthetic/demo mode."),
    KnowledgeConcept("fees_execution", "execution", "Fees, Slippage, and Execution Quality",
        "Real profitability depends on execution quality and total costs.",
        ["Account for maker/taker fees, spread, slippage, and futures funding.", "Large orders can move price in thin liquidity.", "Measure expected vs actual fill price when live data is available."],
        ["fees", "slippage", "maker", "taker", "funding"], "Use verified exchange fee schedules for live trading."),
    KnowledgeConcept("strategy_selection", "strategies", "Strategy Selection by Market Regime",
        "No single strategy fits all conditions; match strategy to trend/range/volatility/liquidity/costs.",
        ["Trend following performs differently than mean reversion/range strategies.", "Test strategies across regimes and out-of-sample periods.", "Disable or review strategies that degrade."],
        ["strategy", "regime", "trend", "range"], "Historical performance is not proof of future performance."),
    KnowledgeConcept("demo_live_safety", "operations", "Demo/Live Separation and Safety Controls",
        "Demo and Live environments must remain strictly separated with explicit user control.",
        ["Never auto-switch from Demo to Live.", "Require explicit approval and enabled config for Live.", "No withdrawal/transfer permissions for API keys.", "Emergency stop should prevent new risk-taking actions."],
        ["demo", "live", "safety", "permissions"], "Operational safety overrides automation convenience."),
]


# Extended curriculum seeds are educational notes, not verified source material.
_seed_catalog_path = Path(__file__).with_name("seed_catalog.json")
if _seed_catalog_path.exists():
    _seed_rows = json.loads(_seed_catalog_path.read_text(encoding="utf-8"))
    _seed_keys = {item.key for item in SEED_CONCEPTS}
    for _row in _seed_rows:
        if _row["key"] not in _seed_keys:
            SEED_CONCEPTS.append(KnowledgeConcept(**_row))


def source_catalog() -> list[dict[str, Any]]:
    path = Path(__file__).with_name("source_catalog.json")
    if not path.exists():
        return []
    rows = json.loads(path.read_text(encoding="utf-8"))
    # A catalog entry is only a suggested reference until an administrator reviews it.
    return [{**row, "verified": False, "status": "pending_admin_review"} for row in rows]


REQUIRED_KNOWLEDGE_DOMAINS: dict[str, dict[str, Any]] = {
    "market_structure": {"title": "Market structure and trend", "categories": ["market_structure"]},
    "candlesticks": {"title": "Candlesticks and price action", "categories": ["candlesticks", "price_action"]},
    "technical_indicators": {"title": "Technical indicators and signal math", "categories": ["indicators"]},
    "chart_patterns": {"title": "Chart patterns and breakouts", "categories": ["price_action", "candlesticks"]},
    "volume": {"title": "Volume analysis", "categories": ["volume"]},
    "order_flow": {"title": "Order flow and delta", "categories": ["order_flow", "volume"]},
    "liquidity": {"title": "Liquidity and execution depth", "categories": ["liquidity"]},
    "market_microstructure": {"title": "Market microstructure and spread", "categories": ["microstructure"]},
    "spot_market": {"title": "Spot market mechanics", "categories": ["spot_market"]},
    "futures_market": {"title": "Futures and perpetual contracts", "categories": ["futures_market"]},
    "leverage_margin": {"title": "Leverage and margin mechanics", "categories": ["leverage_margin", "risk"]},
    "liquidation": {"title": "Liquidation and margin calls", "categories": ["liquidation", "risk"]},
    "funding": {"title": "Funding and basis", "categories": ["funding", "execution"]},
    "order_types": {"title": "Order types and matching", "categories": ["order_types", "execution"]},
    "execution": {"title": "Execution quality and slippage", "categories": ["execution"]},
    "risk_management": {"title": "Trade and portfolio risk", "categories": ["risk"]},
    "portfolio_management": {"title": "Portfolio allocation and exposure", "categories": ["portfolio"]},
    "backtesting": {"title": "Backtesting methodology", "categories": ["backtesting"]},
    "walk_forward_validation": {"title": "Walk-forward and out-of-sample validation", "categories": ["validation", "backtesting"]},
    "statistics": {"title": "Statistics and probability", "categories": ["statistics"]},
    "time_series": {"title": "Time-series analysis", "categories": ["time_series", "statistics"]},
    "market_regimes": {"title": "Market regimes and volatility states", "categories": ["regimes", "strategies"]},
    "strategy_design": {"title": "Strategy design and robustness", "categories": ["strategies"]},
    "machine_learning": {"title": "Machine learning and model validation", "categories": ["machine_learning"]},
    "data_quality": {"title": "Data quality and provenance", "categories": ["data_quality", "operations"]},
    "exchange_api": {"title": "Exchange APIs and reconciliation", "categories": ["exchange_api", "operations"]},
    "security": {"title": "API security and secrets", "categories": ["security", "operations"]},
    "compliance": {"title": "Compliance and operational constraints", "categories": ["compliance", "operations"]},
    "macro_economics": {"title": "Macro and cross-asset context", "categories": ["macro"]},
    "correlation": {"title": "Correlation and cross-market risk", "categories": ["correlation", "analysis"]},
    "on_chain": {"title": "On-chain data and limitations", "categories": ["on_chain"]},
    "tokenomics": {"title": "Tokenomics and supply mechanics", "categories": ["tokenomics"]},
    "stablecoins": {"title": "Stablecoins and depeg risk", "categories": ["stablecoins"]},
    "trading_psychology": {"title": "Trading psychology and behavioral bias", "categories": ["psychology"]},
    "operations": {"title": "Monitoring, incidents and recovery", "categories": ["operations"]},
}


def _knowledge_records(db=None):
    records = [asdict(x) for x in SEED_CONCEPTS]
    if db is not None:
        from sqlalchemy import select
        from app.models.entities import KnowledgeConceptRecord
        dynamic = db.execute(select(KnowledgeConceptRecord).order_by(KnowledgeConceptRecord.category, KnowledgeConceptRecord.key)).scalars().all()
        records.extend({
            "key": x.key, "category": x.category, "title": x.title, "summary": x.summary,
            "details": x.details or [], "tags": x.tags or [], "caution": x.caution,
            "confidence_note": x.confidence_note, "source_keys": [], "verified": False,
            "confidence": float(x.confidence or 0.0),
        } for x in dynamic)
    return records


def _source_links(db=None):
    links: dict[str, set[int]] = {}
    if db is not None:
        from sqlalchemy import select
        from app.models.entities import KnowledgeSource
        rows = db.execute(select(KnowledgeSource).where(
            KnowledgeSource.verified.is_(True), KnowledgeSource.reliability_score >= 0.7
        )).scalars().all()
        for source in rows:
            metadata = source.metadata_json or {}
            if metadata.get("verification_method") != "manual_admin_review":
                continue
            for key in metadata.get("concept_keys", []):
                links.setdefault(str(key), set()).add(int(source.id))
    return links


def list_concepts(category: str | None = None, query: str | None = None, db=None) -> list[dict[str, Any]]:
    items = _knowledge_records(db)
    links = _source_links(db)
    for item in items:
        suggested = list(item.get("source_keys", []))
        ids = sorted(links.get(item["key"], set()))
        item["suggested_source_keys"] = suggested
        item["source_keys"] = [str(x) for x in ids]
        item["verified"] = len(ids) >= 2
        if ids:
            item["confidence"] = max(float(item.get("confidence", 0.0)), 0.7)
    if category:
        c = category.strip().lower()
        items = [x for x in items if x["category"].lower() == c]
    if query:
        q = query.strip().lower()
        items = [x for x in items if q in x["title"].lower() or q in x["summary"].lower() or q in " ".join(x["tags"]).lower() or q in " ".join(x["details"]).lower()]
    return items


def categories(db=None) -> list[str]:
    return sorted({x["category"] for x in _knowledge_records(db)})


def coverage_report(db=None) -> dict[str, Any]:
    """Report verified knowledge coverage; unverified seed notes never count as training-ready."""
    concepts = _knowledge_records(db)
    source_links = _source_links(db)
    manual_source_ids = set().union(*(ids for ids in source_links.values())) if source_links else set()
    domain_rows = []
    ready_count = 0
    for domain, spec in REQUIRED_KNOWLEDGE_DOMAINS.items():
        concepts_in_domain = [c for c in concepts if c["category"] in spec["categories"] or c["category"] == domain]
        verified_concepts = [c for c in concepts_in_domain if len(source_links.get(c["key"], set())) >= 2]
        source_ids = set().union(*(source_links.get(c["key"], set()) for c in concepts_in_domain)) if concepts_in_domain else set()
        ready = len(verified_concepts) >= 3 and len(source_ids) >= 2
        ready_count += int(ready)
        domain_rows.append({
            "key": domain, "title": spec["title"], "seeded_concepts": len(concepts_in_domain),
            "verified_concepts": len(verified_concepts), "verified_sources": len(source_ids),
            "ready": ready,
        })
    missing = [r["key"] for r in domain_rows if not r["ready"]]
    verified_concepts_total = sum(1 for c in concepts if len(source_links.get(c["key"], set())) >= 2)
    return {
        "foundation_ready": not missing,
        "coverage_percent": round(ready_count / len(domain_rows) * 100, 1) if domain_rows else 0.0,
        "required_domains": len(domain_rows), "ready_domains": ready_count,
        "seeded_concepts": len(concepts), "verified_concepts": verified_concepts_total,
        "verified_sources": len(manual_source_ids), "missing_domains": missing,
        "domains": domain_rows,
        "promotion_blocked_until_ready": True,
        "note": "Only manually admin-verified sources linked to concepts count. Seed summaries are educational notes, not a complete verified training corpus.",
    }
