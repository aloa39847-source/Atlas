"""Position Manager - SL/TP/Trailing Stop logic (simulation/testable)
Does NOT auto-execute real orders. Execution must go through approved safe paths.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable


@dataclass
class ManagedPosition:
    symbol: str
    side: str  # long/buy or short/sell
    entry_price: float
    quantity: float
    stop_loss: float | None = None
    take_profit: float | None = None
    trailing_stop_pct: float | None = None  # e.g. 0.02 for 2%
    trailing_stop_price: float | None = None
    highest_price: float | None = None
    lowest_price: float | None = None

    def update_price(self, price: float) -> dict[str, Any]:
        action = None
        reason = None
        if self.side in ("long","buy"):
            if self.highest_price is None or price > self.highest_price:
                self.highest_price = price
            # SL
            if self.stop_loss and price <= self.stop_loss:
                action = "close"; reason = "stop_loss"
            # TP
            elif self.take_profit and price >= self.take_profit:
                action = "close"; reason = "take_profit"
            # Trailing
            elif self.trailing_stop_pct and self.highest_price:
                trail = self.highest_price * (1 - self.trailing_stop_pct)
                if self.trailing_stop_price is None or trail > self.trailing_stop_price:
                    self.trailing_stop_price = trail
                if price <= self.trailing_stop_price:
                    action = "close"; reason = "trailing_stop"
        else:  # short
            if self.lowest_price is None or price < self.lowest_price:
                self.lowest_price = price
            if self.stop_loss and price >= self.stop_loss:
                action = "close"; reason = "stop_loss"
            elif self.take_profit and price <= self.take_profit:
                action = "close"; reason = "take_profit"
            elif self.trailing_stop_pct and self.lowest_price:
                trail = self.lowest_price * (1 + self.trailing_stop_pct)
                if self.trailing_stop_price is None or trail < self.trailing_stop_price:
                    self.trailing_stop_price = trail
                if price >= self.trailing_stop_price:
                    action = "close"; reason = "trailing_stop"
        return {"action": action, "reason": reason, "trailing_stop_price": self.trailing_stop_price, "price": price}


class PositionRiskManager:
    def evaluate_positions(self, positions: list[ManagedPosition], prices: dict[str, float]) -> list[dict[str, Any]]:
        signals = []
        for p in positions:
            price = prices.get(p.symbol)
            if price is None:
                continue
            res = p.update_price(price)
            if res.get("action") == "close":
                signals.append({"symbol": p.symbol, "side": p.side, "quantity": p.quantity, "reason": res["reason"], "price": price})
        return signals
