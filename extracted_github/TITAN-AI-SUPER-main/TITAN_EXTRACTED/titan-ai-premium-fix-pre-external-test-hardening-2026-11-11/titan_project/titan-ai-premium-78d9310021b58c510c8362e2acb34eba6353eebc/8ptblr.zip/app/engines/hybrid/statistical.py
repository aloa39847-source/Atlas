"""Statistical Analysis Engine - Core quantitative foundation for TITAN
All calculations are deterministic and auditable.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Sequence

from app.core.enums import EngineStatus
from app.engines.base import Engine


def _mean(vals: Sequence[float]) -> float:
    if not vals:
        return 0.0
    return sum(float(v) for v in vals) / len(vals)


def _stdev(vals: Sequence[float]) -> float:
    if len(vals) < 2:
        return 0.0
    m = _mean(vals)
    var = sum((float(v) - m) ** 2 for v in vals) / len(vals)
    return math.sqrt(var)


@dataclass
class StatisticalMetrics:
    mean: float
    std: float
    zscore_last: float | None
    correlation: dict[str, float]
    volatility: float
    expectancy: float | None
    win_rate_est: float | None


class StatisticalAnalysisEngine(Engine):
    key = "statistical_analysis"
    name = "Statistical Analysis Engine"

    def status(self):
        return EngineStatus.IMPLEMENTED_PARTIAL

    def analyze_series(self, close: Sequence[float], lookback: int = 20) -> dict[str, Any]:
        vals = [float(x) for x in close[-lookback:]] if close else []
        if not vals:
            return {"ok": False, "reason": "no_data"}
        m = _mean(vals)
        s = _stdev(vals)
        last = vals[-1]
        z = (last - m) / s if s > 1e-12 else 0.0
        returns = []
        for i in range(1, len(vals)):
            if vals[i - 1] != 0:
                returns.append((vals[i] / vals[i - 1]) - 1.0)
        vol = _stdev(returns) if returns else 0.0
        return {
            "ok": True,
            "mean": round(m, 8),
            "std": round(s, 8),
            "zscore_last": round(z, 4),
            "volatility": round(vol, 8),
            "lookback": len(vals),
            "last_price": last,
        }

    def correlation_matrix(self, series_map: dict[str, Sequence[float]]) -> dict[str, dict[str, float]]:
        keys = list(series_map.keys())
        res = {}
        for k1 in keys:
            res[k1] = {}
            v1 = [float(x) for x in series_map[k1]]
            m1 = _mean(v1)
            s1 = _stdev(v1)
            for k2 in keys:
                if k1 == k2:
                    res[k1][k2] = 1.0
                    continue
                v2 = [float(x) for x in series_map[k2]]
                n = min(len(v1), len(v2))
                if n == 0 or s1 < 1e-12 or _stdev(v2[:n]) < 1e-12:
                    res[k1][k2] = 0.0
                    continue
                m2 = _mean(v2[:n])
                cov = sum((v1[i] - m1) * (v2[i] - m2) for i in range(n)) / n
                corr = cov / (s1 * _stdev(v2[:n]))
                res[k1][k2] = round(corr, 4)
        return res
