from __future__ import annotations

from dataclasses import dataclass
from math import isfinite
from typing import Any

from app.core.enums import MarketType
from .compliance import compliance_engine


@dataclass
class GatewayDecision:
    ok: bool
    reason: str
    normalized: dict[str, Any]
    warnings: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {"ok": self.ok, "reason": self.reason, "normalized": self.normalized, "warnings": self.warnings}


class PreTradeOrderGateway:
    """Independent pre-trade safety layer. No AI model may bypass it.

    This validates request shape and basic safety constraints. Exchange-specific
    filters (tick/step/minNotional), balances, and live order state require
    Binance adapter integration and reconciliation.
    """

    def validate(
        self,
        *,
        symbol: str,
        market: MarketType,
        side: str,
        order_type: str,
        quantity: float | None,
        price: float | None = None,
        reference_price: float | None = None,
        max_notional: float | None = None,
        idempotency_key: str | None = None,
        reduce_only: bool = False,
        environment_mode: str = "demo",
        live_enabled: bool = False,
        api_permissions: list[str] | None = None,
        bypass_attempt: bool = False,
        geo_verified: bool | None = None,
        kyc_verified: bool | None = None,
        rate_limit_ok: bool | None = None,
        exchange_filters: dict | None = None,
    ) -> GatewayDecision:
        warnings: list[str] = []

        # Fail closed before compliance checks or arithmetic: NaN compares false
        # against both bounds and can otherwise evade a notional ceiling.
        try:
            if isinstance(quantity, bool) or quantity is None:
                raise ValueError("quantity")
            quantity = float(quantity)
            if not isfinite(quantity) or quantity <= 0:
                raise ValueError("quantity")
            if price is not None:
                if isinstance(price, bool):
                    raise ValueError("price")
                price = float(price)
                if not isfinite(price) or price <= 0:
                    raise ValueError("price")
            if reference_price is not None:
                if isinstance(reference_price, bool):
                    raise ValueError("reference_price")
                reference_price = float(reference_price)
                if not isfinite(reference_price) or reference_price <= 0:
                    raise ValueError("reference_price")
            if max_notional is not None:
                if isinstance(max_notional, bool):
                    raise ValueError("max_notional")
                max_notional = float(max_notional)
                if not isfinite(max_notional) or max_notional <= 0:
                    raise ValueError("max_notional")
            if exchange_filters is not None:
                if not isinstance(exchange_filters, dict):
                    raise ValueError("exchange_filters")
                for filter_name in ("tickSize", "stepSize", "minNotional"):
                    raw_filter = exchange_filters.get(filter_name, 0) or 0
                    if isinstance(raw_filter, bool):
                        raise ValueError(filter_name)
                    filter_value = float(raw_filter)
                    if not isfinite(filter_value) or filter_value < 0:
                        raise ValueError(filter_name)
                    exchange_filters[filter_name] = filter_value
        except (TypeError, ValueError, OverflowError) as exc:
            field = str(exc) or "numeric_input"
            return GatewayDecision(False, f"invalid_numeric_input:{field}", {"field": field}, warnings)

        comp = compliance_engine.check_order_action(
            market=market, symbol=symbol or "", side=side or "", quantity=float(quantity or 0), price=price,
            environment_mode=environment_mode, live_enabled=live_enabled, api_permissions=api_permissions,
            bypass_attempt=bypass_attempt, geo_verified=geo_verified, kyc_verified=kyc_verified, rate_limit_ok=rate_limit_ok,
        )
        if not comp.ok or comp.action == "block":
            return GatewayDecision(False, f"compliance_block:{comp.reason}", {"compliance": comp.to_dict()}, warnings)
        if comp.action == "review_required":
            return GatewayDecision(False, f"compliance_review_required:{comp.reason}", {"compliance": comp.to_dict()}, warnings)
        warnings.append(f"compliance:{comp.action}:{comp.reason}")
        sym = (symbol or "").strip().upper()
        if not sym or "/" not in sym and len(sym) < 5:
            return GatewayDecision(False, "invalid_symbol", {"symbol": symbol}, warnings)
        sd = (side or "").strip().lower()
        if market == MarketType.SPOT and sd not in {"buy", "sell"}:
            return GatewayDecision(False, "invalid_spot_side", {"side": side}, warnings)
        if market == MarketType.FUTURES and sd not in {"buy", "sell", "long", "short"}:
            return GatewayDecision(False, "invalid_futures_side", {"side": side}, warnings)
        if market == MarketType.EARN:
            return GatewayDecision(False, "earn_not_order_execution", {"market": market.value}, warnings)
        ot = (order_type or "").strip().lower()
        if ot not in {"market", "limit"}:
            return GatewayDecision(False, "unsupported_order_type", {"order_type": ot}, warnings)
        if quantity is None or quantity <= 0:
            return GatewayDecision(False, "invalid_quantity", {"quantity": quantity}, warnings)
        if ot == "limit" and price is None:
            return GatewayDecision(False, "limit_order_price_required", {"order_type": ot}, warnings)
        if ot == "market" and reference_price is None:
            return GatewayDecision(False, "reference_price_required_for_notional_cap", {"order_type": ot}, warnings)
        # A market order executes at the market, never at a caller-supplied limit/display price.
        # Its cap and min-notional calculations must use the trusted reference feed.
        px = reference_price if ot == "market" else price
        if px is not None and px <= 0:
            return GatewayDecision(False, "invalid_price", {"price": price}, warnings)
        if ot == "limit" and reference_price is not None and reference_price > 0:
            deviation = abs(price - reference_price) / reference_price
            if deviation > 0.2:
                return GatewayDecision(False, "price_deviation_too_large", {"deviation": deviation}, warnings)
            if deviation > 0.03:
                warnings.append("price_deviates_from_reference")
        if ot == "market" and price is not None:
            warnings.append("caller_supplied_market_price_ignored")
        notional = (px or 0.0) * quantity
        if px is None:
            return GatewayDecision(False, "reference_price_required_for_notional_cap", {"quantity": quantity}, warnings)
        if idempotency_key is not None and len(idempotency_key.strip()) < 8:
            return GatewayDecision(False, "weak_idempotency_key", {"idempotency_key": "masked"}, warnings)
        # Binance exchange filters (tickSize, stepSize, minNotional)
        filters_checked = False
        if exchange_filters:
            filters_checked = True
            try:
                tick = float(exchange_filters.get("tickSize", 0) or 0)
                step = float(exchange_filters.get("stepSize", 0) or 0)
                min_notional = float(exchange_filters.get("minNotional", 0) or 0)
                if price is not None and tick > 0:
                    rem = (price / tick) % 1
                    if abs(rem) > 1e-9 and abs(rem - 1) > 1e-9:
                        return GatewayDecision(False, "price_not_aligned_to_tick_size", {"price": price, "tickSize": tick}, warnings)
                if step > 0:
                    rem = (quantity / step) % 1
                    if abs(rem) > 1e-9 and abs(rem - 1) > 1e-9:
                        return GatewayDecision(False, "quantity_not_aligned_to_step_size", {"quantity": quantity, "stepSize": step}, warnings)
                if min_notional > 0 and notional and notional < min_notional:
                    return GatewayDecision(False, "below_min_notional", {"notional": notional, "minNotional": min_notional}, warnings)
            except Exception as e:
                return GatewayDecision(False, "exchange_filter_validation_error", {"error": str(e)}, warnings)
        normalized = {
            "symbol": sym, "market": market.value, "side": sd, "order_type": ot,
            "quantity": quantity, "price": price, "reference_price": reference_price,
            "notional_estimate": notional if px else None, "idempotency_key_present": bool(idempotency_key),
            "reduce_only": bool(reduce_only),
            "exchange_filters_checked": filters_checked,
            "exchange_balance_checked": False,
        }
        # User-approved hard notional ceiling per individual position.
        hard_cap = 80.0 if market == MarketType.SPOT else 800.0 if market == MarketType.FUTURES else 0.0
        if hard_cap <= 0:
            return GatewayDecision(False, "unsupported_market", {"market": market.value}, warnings)
        effective_cap = min(float(max_notional), hard_cap) if max_notional is not None else hard_cap
        if notional > effective_cap:
            return GatewayDecision(False, "notional_exceeds_limit", {"notional": notional, "max_notional": effective_cap, "hard_cap": hard_cap}, warnings)
        if not filters_checked:
            warnings.append("exchange_filters_balance_reconciliation_required_before_live_send")
        return GatewayDecision(True, "accepted_for_precheck", normalized, warnings)
