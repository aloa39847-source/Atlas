from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Sequence

from app.core.enums import EngineStatus, Timeframe
from .base import Engine


def _f(v: Any) -> float | None:
    if v is None:
        return None
    try:
        fv = float(v)
        return None if math.isnan(fv) or math.isinf(fv) else fv
    except Exception:
        return None


def _sma(vals: Sequence[float], n: int) -> list[float | None]:
    out: list[float | None] = [None] * len(vals)
    if n <= 0:
        return out
    s = 0.0
    for i, v in enumerate(vals):
        s += float(v)
        if i >= n:
            s -= float(vals[i - n])
        if i >= n - 1:
            out[i] = s / n
    return out


def _ema(vals: Sequence[float], n: int) -> list[float | None]:
    out: list[float | None] = [None] * len(vals)
    if n <= 0 or len(vals) < n:
        return out
    alpha = 2.0 / (n + 1.0)
    seed = sum(float(x) for x in vals[:n]) / n
    out[n - 1] = seed
    prev = seed
    for i in range(n, len(vals)):
        prev = alpha * float(vals[i]) + (1 - alpha) * prev
        out[i] = prev
    return out


def _ema_wilder(vals: Sequence[float], n: int) -> list[float | None]:
    out: list[float | None] = [None] * len(vals)
    if n <= 0 or len(vals) < n:
        return out
    alpha = 1.0 / n
    seed = sum(float(x) for x in vals[:n]) / n
    out[n - 1] = seed
    prev = seed
    for i in range(n, len(vals)):
        prev = alpha * float(vals[i]) + (1 - alpha) * prev
        out[i] = prev
    return out


def _rsi(close: Sequence[float], n: int = 14) -> list[float | None]:
    out: list[float | None] = [None] * len(close)
    if len(close) < n + 1:
        return out
    deltas = [float(close[i]) - float(close[i - 1]) for i in range(1, len(close))]
    gains = [max(d, 0.0) for d in deltas]
    losses = [max(-d, 0.0) for d in deltas]
    avg_g = _ema_wilder(gains, n)
    avg_l = _ema_wilder(losses, n)
    for i in range(len(avg_g)):
        g, l = avg_g[i], avg_l[i]
        if g is None or l is None:
            continue
        if l == 0:
            out[i + 1] = 100.0
        else:
            rs = g / l
            out[i + 1] = 100.0 - (100.0 / (1.0 + rs))
    return out


def _atr(high: Sequence[float], low: Sequence[float], close: Sequence[float], n: int = 14) -> list[float | None]:
    trs: list[float] = []
    for i in range(len(close)):
        if i == 0:
            trs.append(float(high[i]) - float(low[i]))
        else:
            pc = float(close[i - 1])
            trs.append(max(float(high[i]) - float(low[i]), abs(float(high[i]) - pc), abs(float(low[i]) - pc)))
    return _ema_wilder(trs, n)


def _macd(close: Sequence[float]) -> dict[str, list[float | None]]:
    ema12 = _ema(close, 12)
    ema26 = _ema(close, 26)
    line: list[float | None] = [None] * len(close)
    vals = []
    idxs = []
    for i in range(len(close)):
        if ema12[i] is not None and ema26[i] is not None:
            v = ema12[i] - ema26[i]  # type: ignore
            line[i] = v
            vals.append(v)
            idxs.append(i)
    signal_vals = _ema(vals, 9) if vals else []
    signal: list[float | None] = [None] * len(close)
    hist: list[float | None] = [None] * len(close)
    for j, i in enumerate(idxs):
        sv = signal_vals[j] if j < len(signal_vals) else None
        signal[i] = sv
        if line[i] is not None and sv is not None:
            hist[i] = line[i] - sv  # type: ignore
    return {"macd": line, "macd_signal": signal, "macd_hist": hist}


def _last(seq: Sequence[Any]) -> Any:
    return seq[-1] if seq else None


def _rolling_std(vals: Sequence[float], n: int) -> list[float | None]:
    out: list[float | None] = [None] * len(vals)
    for i in range(n - 1, len(vals)):
        w = [float(x) for x in vals[i - n + 1 : i + 1]]
        m = sum(w) / n
        var = sum((x - m) ** 2 for x in w) / n
        out[i] = math.sqrt(var)
    return out


@dataclass
class TimeframeAnalysis:
    timeframe: Timeframe
    trend: str
    signals: list[str]
    indicators: dict[str, Any]
    structure: dict[str, Any]
    candles: dict[str, Any]


class TechnicalAnalysisEngine(Engine):
    key = "technical_analysis"
    name = "Technical Analysis Engine"

    def status(self) -> EngineStatus:
        return EngineStatus.IMPLEMENTED_PARTIAL

    def analyze(self, df: Any, timeframe: Timeframe) -> TimeframeAnalysis:
        # df: Candles container or compatible (supports ["close"] lists, len, iloc)
        try:
            close = [float(x) for x in df["close"]]
            high = [float(x) for x in df["high"]]
            low = [float(x) for x in df["low"]]
            vol = [float(x) for x in df["volume"]] if "volume" in getattr(df, "columns", ["volume"]) or True else [0.0] * len(close)
        except Exception:
            return TimeframeAnalysis(timeframe, "unknown", ["invalid_data"], {}, {}, {})
        if len(close) < 30:
            return TimeframeAnalysis(timeframe, "unknown", ["insufficient_data"], {}, {}, {})

        rsi = _rsi(close)
        macd = _macd(close)
        bb_mid = _sma(close, 20)
        bb_std = _rolling_std(close, 20)
        atr = _atr(high, low, close)
        ema20 = _ema(close, 20)
        ema50 = _ema(close, 50) if len(close) >= 50 else _ema(close, min(21, len(close)))
        sma20 = _sma(close, 20)
        vol_sma20 = _sma(vol, 20)

        bbm = _last(bb_mid); bbs = _last(bb_std)
        last = {
            "close": _f(close[-1]),
            "rsi14": _f(_last(rsi)),
            "macd": _f(_last(macd["macd"])),
            "macd_signal": _f(_last(macd["macd_signal"])),
            "macd_hist": _f(_last(macd["macd_hist"])),
            "ema20": _f(_last(ema20)),
            "ema50": _f(_last(ema50)),
            "sma20": _f(_last(sma20)),
            "bb_upper": _f(bbm + 2 * bbs) if bbm is not None and bbs is not None else None,
            "bb_mid": _f(bbm),
            "bb_lower": _f(bbm - 2 * bbs) if bbm is not None and bbs is not None else None,
            "atr14": _f(_last(atr)),
            "volume_last": _f(vol[-1]),
            "volume_sma20": _f(_last(vol_sma20)),
        }

        signals: list[str] = []
        trend = "sideways"
        e20, e50 = last["ema20"], last["ema50"]
        c = last["close"] or 0
        if e20 is not None and e50 is not None:
            if c > e20 > e50:
                trend = "bullish"; signals.append("price_above_ema20_ema50")
            elif c < e20 < e50:
                trend = "bearish"; signals.append("price_below_ema20_ema50")
        rv = last["rsi14"]
        if rv is not None:
            if rv < 30: signals.append("rsi_oversold")
            elif rv > 70: signals.append("rsi_overbought")
        mh = last["macd_hist"]
        if mh is not None:
            signals.append("macd_hist_positive" if mh > 0 else "macd_hist_negative")

        structure = self._market_structure(high, low, close)
        candles = self._candle_patterns(df)
        signals.extend(candles.get("patterns", []))
        return TimeframeAnalysis(timeframe, trend, signals, last, structure, candles)

    def _market_structure(self, highs: list[float], lows: list[float], closes: list[float] | None = None) -> dict[str, Any]:
        n = min(len(highs), len(lows))
        if n < 7:
            return {"swing_tags": [], "bias": "neutral", "bos_choch": [], "breakout_status": "unconfirmed",
                    "note": "Insufficient candles for swing structure."}

        def swings(window: int):
            sh = []
            sl = []
            for i in range(window, n - window):
                left_high = max(highs[i - window:i])
                right_high = max(highs[i + 1:i + window + 1])
                left_low = min(lows[i - window:i])
                right_low = min(lows[i + 1:i + window + 1])
                # Strict on at least one side: flat price plateaus are not repeated pivots.
                if highs[i] >= left_high and highs[i] >= right_high and (highs[i] > left_high or highs[i] > right_high):
                    sh.append(i)
                if lows[i] <= left_low and lows[i] <= right_low and (lows[i] < left_low or lows[i] < right_low):
                    sl.append(i)
            return sh, sl

        major_sh, major_sl = swings(5) if n >= 13 else ([], [])
        minor_sh, minor_sl = swings(2)
        sh, sl = minor_sh[-4:], minor_sl[-4:]
        tags: list[str] = []
        if len(sh) >= 2:
            tags.append("HH" if highs[sh[-1]] > highs[sh[-2]] else "LH")
        if len(sl) >= 2:
            tags.append("HL" if lows[sl[-1]] > lows[sl[-2]] else "LL")
        bias = "neutral"
        if "HH" in tags and "HL" in tags:
            bias = "bullish_structure"
        elif "LH" in tags and "LL" in tags:
            bias = "bearish_structure"

        last_close = float(closes[-1]) if closes else None
        last_high, last_low = float(highs[-1]), float(lows[-1])
        prior_swing_high = float(highs[sh[-1]]) if sh else None
        prior_swing_low = float(lows[sl[-1]]) if sl else None
        bos_choch: list[dict[str, Any]] = []
        breakout_status = "unconfirmed"
        if prior_swing_high is not None and last_high > prior_swing_high:
            if last_close is not None and last_close > prior_swing_high:
                breakout_status = "confirmed_bullish_breakout"
                kind = "CHOCH" if bias == "bearish_structure" else "BOS"
                bos_choch.append({"type": kind, "direction": "bullish", "level": prior_swing_high,
                                  "confirmation": "closed_above_swing_high"})
            elif last_close is not None:
                breakout_status = "false_bullish_breakout"
                bos_choch.append({"type": "LIQUIDITY_SWEEP", "direction": "bearish", "level": prior_swing_high,
                                  "confirmation": "wick_above_then_close_back_below"})
        if prior_swing_low is not None and last_low < prior_swing_low:
            if last_close is not None and last_close < prior_swing_low:
                breakout_status = "confirmed_bearish_breakout"
                kind = "CHOCH" if bias == "bullish_structure" else "BOS"
                bos_choch.append({"type": kind, "direction": "bearish", "level": prior_swing_low,
                                  "confirmation": "closed_below_swing_low"})
            elif last_close is not None:
                breakout_status = "false_bearish_breakout"
                bos_choch.append({"type": "LIQUIDITY_SWEEP", "direction": "bullish", "level": prior_swing_low,
                                  "confirmation": "wick_below_then_close_back_above"})

        return {
            "swing_tags": tags, "bias": bias, "swing_high_count": len(minor_sh), "swing_low_count": len(minor_sl),
            "major_swings": {"highs": [float(highs[i]) for i in major_sh[-4:]], "lows": [float(lows[i]) for i in major_sl[-4:]]},
            "minor_swings": {"highs": [float(highs[i]) for i in minor_sh[-4:]], "lows": [float(lows[i]) for i in minor_sl[-4:]]},
            "bos_choch": bos_choch, "breakout_status": breakout_status,
            "liquidity_zones": {"swing_highs": [float(highs[i]) for i in sh[-3:]], "swing_lows": [float(lows[i]) for i in sl[-3:]]},
            "note": "Swing/BOS/CHOCH and wick-vs-close breakout checks are heuristic; confirm with closed candles and higher-timeframe context.",
        }

    def _candle_patterns(self, df: Any) -> dict[str, Any]:
        try:
            rows = df.rows if hasattr(df, "rows") else list(df)
        except Exception:
            return {"patterns": [], "error": "invalid_candle_rows"}
        if len(rows) < 3:
            return {"patterns": [], "error": "insufficient_candles"}

        def candle(row):
            o, h, l, c = map(float, [row["open"], row["high"], row["low"], row["close"]])
            span = max(h - l, 1e-12)
            body = abs(c - o)
            upper = max(0.0, h - max(o, c))
            lower = max(0.0, min(o, c) - l)
            return {"open": o, "high": h, "low": l, "close": c, "range": span,
                    "body": body, "upper_wick": upper, "lower_wick": lower,
                    "body_to_range": body / span,
                    "close_strength": max(0.0, min(1.0, (c - l) / span)),
                    "direction": "bullish" if c > o else "bearish" if c < o else "neutral"}

        prev2, prev1, cur = candle(rows[-3]), candle(rows[-2]), candle(rows[-1])
        patterns: list[str] = []
        if cur["direction"] == "bullish": patterns.append("bullish_candle")
        elif cur["direction"] == "bearish": patterns.append("bearish_candle")
        if cur["body_to_range"] <= 0.10:
            patterns.append("doji")

        prior_closes = [float(r["close"]) for r in rows[-7:-1]]
        prior_trend = "sideways"
        if len(prior_closes) >= 4:
            delta = prior_closes[-1] - prior_closes[0]
            if delta > abs(prior_closes[0]) * 0.002: prior_trend = "uptrend"
            elif delta < -abs(prior_closes[0]) * 0.002: prior_trend = "downtrend"

        small_body = cur["body"] <= cur["range"] * 0.35
        long_lower = cur["lower_wick"] >= max(cur["body"] * 2.0, cur["range"] * 0.35)
        long_upper = cur["upper_wick"] >= max(cur["body"] * 2.0, cur["range"] * 0.35)
        if small_body and long_lower and cur["upper_wick"] <= max(cur["body"], cur["range"] * 0.12):
            patterns.append("hammer" if prior_trend == "downtrend" else "hanging_man" if prior_trend == "uptrend" else "hammer_like")
        if small_body and long_upper and cur["lower_wick"] <= max(cur["body"], cur["range"] * 0.12):
            patterns.append("shooting_star" if prior_trend == "uptrend" else "shooting_star_like")
        if small_body and max(cur["upper_wick"], cur["lower_wick"]) >= cur["body"] * 2.0:
            patterns.append("pin_bar")
            if cur["lower_wick"] > cur["upper_wick"]: patterns.append("bullish_pin_bar")
            elif cur["upper_wick"] > cur["lower_wick"]: patterns.append("bearish_pin_bar")

        if prev1["direction"] == "bearish" and cur["direction"] == "bullish" and cur["close"] >= prev1["open"] and cur["open"] <= prev1["close"]:
            patterns.append("bullish_engulfing")
        if prev1["direction"] == "bullish" and cur["direction"] == "bearish" and cur["open"] >= prev1["close"] and cur["close"] <= prev1["open"]:
            patterns.append("bearish_engulfing")

        # Crypto trades continuously: gap rules are relaxed, but the small middle body and midpoint close remain required.
        first_mid = (prev2["open"] + prev2["close"]) / 2.0
        first_large = prev2["body_to_range"] >= 0.45
        middle_small = prev1["body"] <= max(prev2["body"] * 0.45, prev2["range"] * 0.12)
        if prev2["direction"] == "bearish" and first_large and middle_small and cur["direction"] == "bullish" and cur["close"] > first_mid:
            patterns.append("morning_star")
        if prev2["direction"] == "bullish" and first_large and middle_small and cur["direction"] == "bearish" and cur["close"] < first_mid:
            patterns.append("evening_star")

        return {
            "patterns": list(dict.fromkeys(patterns)),
            "body_to_range": round(cur["body_to_range"], 4),
            "upper_wick_to_range": round(cur["upper_wick"] / cur["range"], 4),
            "lower_wick_to_range": round(cur["lower_wick"] / cur["range"], 4),
            "upper_wick_to_body": round(cur["upper_wick"] / max(cur["body"], 1e-12), 4),
            "lower_wick_to_body": round(cur["lower_wick"] / max(cur["body"], 1e-12), 4),
            "close_strength": round(cur["close_strength"], 4),
            "candle_direction": cur["direction"],
            "prior_trend_context": prior_trend,
            "note": "Pattern labels are heuristic; location, trend, volume, volatility and candle-close confirmation matter.",
        }

