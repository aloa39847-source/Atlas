from __future__ import annotations

from typing import Any

from app.core.enums import DataSourceKind, DecisionAction, EngineStatus, EnvironmentMode, MarketType, Timeframe
from .base import Engine
from .risk import RiskEngine
from .strategies import select_strategy
from .technical import TechnicalAnalysisEngine, TimeframeAnalysis
try:
    from .hybrid.coordinator import HybridIntelligenceCoordinator
    from app.agents.coordinator import MultiAgentCoordinator
    _HYBRID_AVAILABLE = True
except Exception:
    HybridIntelligenceCoordinator = None
    MultiAgentCoordinator = None
    _HYBRID_AVAILABLE = False


class DecisionEngine(Engine):
    key = "decision_making"
    name = "Decision Making Engine"

    def __init__(self) -> None:
        self.technical = TechnicalAnalysisEngine()
        self.risk = RiskEngine()
        self.hybrid = HybridIntelligenceCoordinator() if _HYBRID_AVAILABLE and HybridIntelligenceCoordinator else None
        self.multi_agent = MultiAgentCoordinator() if _HYBRID_AVAILABLE and MultiAgentCoordinator else None

    def status(self) -> EngineStatus:
        return EngineStatus.IMPLEMENTED_PARTIAL

    def decide(
        self,
        *,
        symbol: str,
        market: MarketType,
        environment: EnvironmentMode,
        timeframe_analyses: dict[str, TimeframeAnalysis],
        balance: float = 1000.0,
        max_leverage: float = 3.0,
        risk_per_trade: float = 0.01,
        batches: dict | None = None,
        risk_context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        # Multi-timeframe synthesis (1D trend context -> 4H/1H confirmation -> 15M setup -> 5M timing)
        tf = {k.value if hasattr(k, "value") else str(k): v for k, v in timeframe_analyses.items()}
        # Ensure all required timeframes considered
        required_tfs = ["1d", "4h", "1h", "15m", "5m"]
        missing_tfs = [rtf for rtf in required_tfs if rtf not in tf]
        if missing_tfs:
            return self._wait(symbol, market, environment, "missing_required_timeframes",
                              {"missing_timeframes": missing_tfs}, timeframe_analyses)
        d1 = tf.get("1d"); h4 = tf.get("4h"); h1 = tf.get("1h"); m15 = tf.get("15m"); m5 = tf.get("5m")
        trends = [x.trend for x in [d1, h4, h1] if x]
        bull = sum(1 for t in trends if t == "bullish")
        bear = sum(1 for t in trends if t == "bearish")
        bias = "bullish" if bull > bear else "bearish" if bear > bull else "neutral"
        setup = m15 or m5 or h1
        if not setup:
            return self._wait(symbol, market, environment, "no_timeframe_data", {}, timeframe_analyses)
        
        # Hybrid intelligence layer
        hybrid_analysis = None
        if self.hybrid and batches:
            try:
                hybrid_analysis = self.hybrid.analyze_multi_timeframe(batches, timeframe_analyses)
            except Exception as e:
                hybrid_analysis = {"error": str(e), "partial": True}
        
        # Multi-agent deliberation
        agent_delib = None
        if self.multi_agent:
            try:
                agent_delib = self.multi_agent.deliberate({
                    "symbol": symbol,
                    "bias": bias,
                    "evidence": hybrid_analysis.get("evidence", []) if hybrid_analysis else [],
                    "strategy": None,
                })
            except Exception as e:
                agent_delib = {"error": str(e), "partial": True}

        all_signals = [s for a in timeframe_analyses.values() for s in a.signals]
        strategy = select_strategy(market, bias, all_signals)
        price = float(setup.indicators.get("close") or 0.0)
        atr = float(setup.indicators.get("atr14") or (price * 0.01) or 1.0)
        if price <= 0:
            return self._wait(symbol, market, environment, "invalid_price", {"strategy": strategy}, timeframe_analyses)

        # Conflict/uncertainty => WAIT (important safety behavior)
        has_conflict = (bull > 0 and bear > 0 and abs(bull - bear) <= 1) or bias == "neutral"
        confidence = 0.35
        if not has_conflict:
            confidence += 0.2
        if d1 and h4 and d1.trend == h4.trend and d1.trend != "sideways":
            confidence += 0.15
        if m15 and ("rsi_oversold" in m15.signals or "rsi_overbought" in m15.signals):
            confidence += 0.05
        confidence = round(min(confidence, 0.85), 3)  # never claim certainty

        action = DecisionAction.WAIT
        reason = "No clear, risk-acceptable setup after multi-timeframe synthesis."
        if not has_conflict and confidence >= 0.55:
            if bias == "bullish":
                action = DecisionAction.BUY if market == MarketType.SPOT else DecisionAction.LONG
                reason = "Higher-timeframe bullish bias with confirming setup; risk checks applied."
            elif bias == "bearish":
                if market == MarketType.SPOT:
                    action = DecisionAction.WAIT
                    reason = "Bearish bias on spot: prefer WAIT/SELL-only-if-position context (no short)."
                else:
                    action = DecisionAction.SHORT
                    reason = "Higher-timeframe bearish bias with confirming setup; futures short considered."

        if market == MarketType.EARN:
            return self._wait(symbol, market, environment, "earn_is_analysis_recommendation_not_trade_execution", {"strategy": strategy, "bias": bias}, timeframe_analyses)

        sl_mult = 1.2
        tp_mult = 2.0
        if action in (DecisionAction.BUY, DecisionAction.LONG):
            stop_loss = price - atr * sl_mult
            take_profit = price + atr * tp_mult
        elif action in (DecisionAction.SELL, DecisionAction.SHORT):
            stop_loss = price + atr * sl_mult
            take_profit = price - atr * tp_mult
        else:
            stop_loss = None
            take_profit = None

        lev = 1.0
        if market == MarketType.FUTURES and action in (DecisionAction.LONG, DecisionAction.SHORT):
            # Independent leverage choice within caps, based on confidence/uncertainty (not fixed 1x).
            lev = 1.0 + min(max((confidence - 0.55) * 10, 0.0), max(0.0, max_leverage - 1.0))
            lev = round(min(lev, max_leverage), 2)
        elif market == MarketType.SPOT:
            lev = 1.0

        risk_result = None
        costs = None
        rr = None
        if action != DecisionAction.WAIT and stop_loss and take_profit:
            context = risk_context or {}
            risk_result = self.risk.validate_trade(
                environment=environment, market=market, balance=balance, risk_per_trade=risk_per_trade,
                entry=price, stop_loss=stop_loss, leverage=lev, max_leverage=max_leverage,
                daily_loss_used=float(context.get("daily_loss_used", 0.0)),
                max_daily_loss=context.get("max_daily_loss"),
                open_positions=int(context.get("open_positions", 0)),
                max_open_positions=context.get("max_open_positions"),
                current_exposure=float(context.get("current_exposure", 0.0)),
                max_exposure=context.get("max_exposure"),
            )
            notional = float(risk_result.get("position_notional_estimate") or 0.0)
            costs = self.risk.estimate_costs(notional, market).to_dict()
            reward = abs(take_profit - price)
            risk_amt = abs(price - stop_loss)
            rr = round(reward / risk_amt, 3) if risk_amt else None
            if not risk_result.get("ok"):
                action = DecisionAction.WAIT
                reason = "Risk engine blocked the setup: " + ",".join(risk_result.get("issues") or [])
            elif rr is not None and rr < 1.2:
                action = DecisionAction.WAIT
                reason = f"Rejected due to weak risk/reward estimate ({rr})."

        return {
            "symbol": symbol,
            "environment_mode": environment.value,
            "market_type": market.value,
            "action": action.value,
            "strategy": strategy["key"],
            "strategy_name": strategy["name"],
            "confidence": confidence,
            "confidence_note": "Heuristic confidence estimate (0-1). NOT certainty and NOT a profit guarantee.",
            "bias": bias,
            "reason": reason,
            "entry_price": price if action != DecisionAction.WAIT else None,
            "stop_loss": round(stop_loss, 8) if stop_loss else None,
            "take_profit": round(take_profit, 8) if take_profit else None,
            "risk_reward": rr,
            "leverage": lev,
            "risk": risk_result,
            "costs": costs,
            "timeframes": {k: {"trend": v.trend, "signals": v.signals[:8], "structure": v.structure} for k, v in tf.items()},
            "data_sources": {k: (batches[Timeframe(k)].source.value if batches and Timeframe(k) in batches else "unknown") for k in tf.keys()},
            "data_source_warning": ("Live read-only Binance public candles used; no account credentials or order access." if batches and all(b.source == DataSourceKind.LIVE_PUBLIC for b in batches.values()) else "Decision uses LABELED synthetic data; it is not a real-market signal." if batches and all(b.source == DataSourceKind.SYNTHETIC_LABELED for b in batches.values()) else "Data provenance unavailable; do not use this decision for execution."),
            "hybrid_intelligence": hybrid_analysis,
            "multi_agent_deliberation": agent_delib,
            "timeframes_analyzed_required": ["1d", "4h", "1h", "15m", "5m"],
        }

    def _wait(self, symbol, market, environment, reason, extra, tf) -> dict[str, Any]:
        return {
            "symbol": symbol, "environment_mode": environment.value, "market_type": market.value,
            "action": DecisionAction.WAIT.value, "strategy": (extra.get("strategy") or {}).get("key") if isinstance(extra.get("strategy"), dict) else extra.get("strategy"),
            "confidence": 0.0, "reason": reason, "extra": extra,
            "timeframes": {k.value if hasattr(k, "value") else k: {"trend": v.trend, "signals": v.signals[:8]} for k, v in tf.items()},
        }
