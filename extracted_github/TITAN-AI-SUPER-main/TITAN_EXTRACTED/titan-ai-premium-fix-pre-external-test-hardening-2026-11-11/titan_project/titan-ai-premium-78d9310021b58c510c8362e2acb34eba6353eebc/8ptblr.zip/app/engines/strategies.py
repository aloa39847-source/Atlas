from __future__ import annotations

from app.core.enums import MarketType


# Extensible strategy registry (examples + metadata). Not a claim of completeness or profitability.
STRATEGIES = [
    {"key": "trend_following_ema", "name": "Trend Following (EMA)", "category": "trend", "markets": ["spot", "futures"], "status": "implemented_partial"},
    {"key": "momentum_macd_rsi", "name": "Momentum (MACD/RSI)", "category": "momentum", "markets": ["spot", "futures"], "status": "implemented_partial"},
    {"key": "mean_reversion_bbands", "name": "Mean Reversion (Bollinger Bands)", "category": "mean_reversion", "markets": ["spot", "futures"], "status": "implemented_partial"},
    {"key": "breakout_structure", "name": "Breakout / Market Structure", "category": "breakout", "markets": ["spot", "futures"], "status": "implemented_partial"},
    {"key": "scalping_m5", "name": "Scalping (M5 timing)", "category": "scalping", "markets": ["spot", "futures"], "status": "planned"},
    {"key": "swing_h1_h4", "name": "Swing (H1/H4)", "category": "swing", "markets": ["spot", "futures"], "status": "planned"},
    {"key": "liquidity_orderflow", "name": "Liquidity/Order Flow", "category": "order_flow", "markets": ["futures"], "status": "needs_external_service"},
    {"key": "arbitrage", "name": "Arbitrage", "category": "arbitrage", "markets": ["spot", "futures"], "status": "needs_external_service"},
]


def list_strategies() -> list[dict]:
    return list(STRATEGIES)


def select_strategy(market: MarketType, bias: str, signals: list[str]) -> dict:
    # Simple transparent selector for the current partial build; full strategy engine will evaluate/test many strategies.
    candidates = [s for s in STRATEGIES if market.value in s["markets"] and s["status"] != "disabled"]
    if bias in ("bullish", "bearish") and "price_above_ema20_ema50" in " ".join(signals):
        for s in candidates:
            if s["key"] == "trend_following_ema":
                return s
    if "macd_hist_positive" in signals or "macd_hist_negative" in signals:
        for s in candidates:
            if s["key"] == "momentum_macd_rsi":
                return s
    if "rsi_oversold" in signals or "rsi_overbought" in signals:
        for s in candidates:
            if s["key"] == "mean_reversion_bbands":
                return s
    return candidates[0] if candidates else {"key": "unknown", "name": "Unknown", "category": "unknown", "markets": [], "status": "error"}
