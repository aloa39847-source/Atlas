"""Continuous Learning System - Measurable, Auditable, Reversible
No auto-apply to live without explicit approval.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any
from math import isfinite
import json


class StrategyVersion:
    def __init__(self, strategy_key: str, version: int, params: dict, metrics: dict):
        self.strategy_key = strategy_key
        self.version = version
        self.params = params
        self.metrics = metrics
        self.created_at = datetime.now(timezone.utc).isoformat()
        self.approved_for_live = False


class ContinuousLearningSystem:
    def __init__(self, *, knowledge_foundation_ready: bool = False):
        self.knowledge_foundation_ready = bool(knowledge_foundation_ready)
        self.versions = {}
        self.proposals = []
        self.audit_log = []

    def propose_improvement(self, strategy_key: str, current_params: dict, proposed_params: dict, rationale: str, metrics_before: dict) -> dict[str, Any]:
        if not self.knowledge_foundation_ready:
            return {"ok": False, "error": "knowledge_foundation_incomplete", "proposal_created": False}
        proposal = {
            "id": len(self.proposals) + 1,
            "strategy_key": strategy_key,
            "current_params": current_params,
            "proposed_params": proposed_params,
            "rationale": rationale,
            "metrics_before": metrics_before,
            "status": "proposed",
            "tested": False,
            "approved_for_live": False,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        self.proposals.append(proposal)
        self.audit_log.append({"action": "proposal_created", "proposal_id": proposal["id"], "ts": proposal["created_at"]})
        return proposal

    def test_proposal(self, proposal_id: int, metrics_after_paper: dict) -> dict[str, Any]:
        for p in self.proposals:
            if p["id"] == proposal_id:
                metrics = metrics_after_paper if isinstance(metrics_after_paper, dict) else {}
                before = p.get("metrics_before", {})
                failures = []
                if not isinstance(metrics_after_paper, dict):
                    failures.append("performance_metrics_must_be_object")
                if not isinstance(before, dict):
                    failures.append("baseline_metrics_must_be_object")
                    before = {}

                def finite_number(source: dict, key: str) -> float | None:
                    value = source.get(key)
                    if isinstance(value, bool):
                        return None
                    try:
                        number = float(value)
                    except (TypeError, ValueError, OverflowError):
                        return None
                    return number if isfinite(number) else None

                def whole_count(key: str) -> int | None:
                    number = finite_number(metrics, key)
                    if number is None or number < 0 or not number.is_integer():
                        return None
                    return int(number)

                days = whole_count("paper_trading_days")
                samples = whole_count("sample_size")
                breaches = whole_count("risk_breaches")
                if days is None:
                    failures.append("paper_trading_days_invalid")
                    if "paper_trading_days" not in metrics:
                        failures.append("minimum_30_paper_days_required")
                elif days < 30:
                    failures.append("minimum_30_paper_days_required")
                if samples is None:
                    failures.append("sample_size_invalid")
                    if "sample_size" not in metrics:
                        failures.append("minimum_100_closed_trades_required")
                elif samples < 100:
                    failures.append("minimum_100_closed_trades_required")
                if metrics.get("out_of_sample") is not True:
                    failures.append("out_of_sample_validation_required")
                if metrics.get("walk_forward") is not True:
                    failures.append("walk_forward_validation_required")
                if metrics.get("no_lookahead") is not True:
                    failures.append("no_lookahead_evidence_required")
                if metrics.get("net_after_fees") is not True:
                    failures.append("net_after_fees_validation_required")
                if metrics.get("source_verified") is not True:
                    failures.append("verified_data_source_required")
                if breaches is None:
                    failures.append("risk_breach_count_invalid")
                elif breaches != 0:
                    failures.append("risk_breaches_must_be_zero")

                profit_factor = finite_number(metrics, "profit_factor")
                if profit_factor is None:
                    failures.append("profit_factor_invalid")
                elif profit_factor < 1.1:
                    failures.append("profit_factor_below_1_1")

                max_drawdown = finite_number(metrics, "max_drawdown")
                if max_drawdown is None or not 0 <= max_drawdown <= 1:
                    failures.append("max_drawdown_invalid")
                elif max_drawdown > 0.15:
                    failures.append("max_drawdown_above_15_percent")

                expectancy = finite_number(metrics, "expectancy")
                baseline_expectancy = finite_number(before, "expectancy")
                if expectancy is None or baseline_expectancy is None:
                    failures.append("expectancy_metrics_invalid")
                elif expectancy <= baseline_expectancy:
                    failures.append("expectancy_did_not_improve")

                p["tested"] = True
                p["metrics_after_paper"] = metrics
                p["validation_failures"] = failures
                p["test_passed"] = not failures
                p["status"] = "tested_passed" if not failures else "tested_failed"
                self.audit_log.append({"action": "proposal_tested", "proposal_id": proposal_id,
                                       "passed": p["test_passed"], "failures": failures})
                return p
        return {"error": "not_found"}

    def approve_for_live(self, proposal_id: int, explicit_approval: bool = False) -> dict[str, Any]:
        if not explicit_approval:
            return {"ok": False, "error": "explicit_approval_required", "note": "Changes cannot be applied to live without explicit approval"}
        for p in self.proposals:
            if p["id"] == proposal_id:
                if not p.get("tested"):
                    return {"ok": False, "error": "must_test_first"}
                if not p.get("test_passed"):
                    return {"ok": False, "error": "all_validation_gates_must_pass", "failures": p.get("validation_failures", [])}
                p["approved_for_live"] = True
                p["status"] = "approved_pending_apply"
                self.audit_log.append({"action": "approved_for_live", "proposal_id": proposal_id, "explicit": True})
                return {"ok": True, "proposal_id": proposal_id}
        return {"error": "not_found"}

    def rollback(self, strategy_key: str, to_version: int) -> dict[str, Any]:
        self.audit_log.append({"action": "rollback_requested", "strategy_key": strategy_key, "to_version": to_version,
                               "applied": False})
        return {"ok": False, "error": "rollback_not_applied_version_store_required",
                "requested_version": to_version, "applied": False, "auditable": True}
