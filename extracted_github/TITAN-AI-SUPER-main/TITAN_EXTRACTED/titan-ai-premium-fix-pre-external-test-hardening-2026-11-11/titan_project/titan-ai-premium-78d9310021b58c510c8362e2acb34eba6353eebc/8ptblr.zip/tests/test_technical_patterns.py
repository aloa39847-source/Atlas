from app.core.enums import Timeframe
from app.engines.market_data import Candles
from app.engines.technical import TechnicalAnalysisEngine


def _base_rows(n=30, start=100.0, direction=0.0):
    rows = []
    price = start
    for _ in range(n):
        close = price + direction
        rows.append({"open": price, "high": max(price, close) + 0.1,
                     "low": min(price, close) - 0.1, "close": close, "volume": 100.0})
        price = close
    return rows


def _patterns(rows):
    return TechnicalAnalysisEngine().analyze(Candles(rows), Timeframe.M5).candles["patterns"]


def test_hammer_pattern_after_downtrend():
    rows = _base_rows(start=20.0, direction=-0.2)
    rows[-1] = {"open": 14.2, "high": 14.28, "low": 13.6, "close": 14.3, "volume": 120}
    assert "hammer" in _patterns(rows)


def test_hanging_man_pattern_after_uptrend():
    rows = _base_rows(start=10.0, direction=0.2)
    rows[-1] = {"open": 15.2, "high": 15.28, "low": 14.6, "close": 15.3, "volume": 120}
    assert "hanging_man" in _patterns(rows)


def test_shooting_star_after_uptrend():
    rows = _base_rows(start=10.0, direction=0.2)
    rows[-1] = {"open": 15.2, "high": 15.9, "low": 15.12, "close": 15.1, "volume": 120}
    assert "shooting_star" in _patterns(rows)


def test_doji_and_close_strength_are_reported():
    rows = _base_rows()
    rows[-1] = {"open": 100.0, "high": 100.5, "low": 99.5, "close": 100.02, "volume": 100}
    result = TechnicalAnalysisEngine().analyze(Candles(rows), Timeframe.M5).candles
    assert "doji" in result["patterns"]
    assert 0.0 <= result["close_strength"] <= 1.0
    assert "upper_wick_to_body" in result and "lower_wick_to_body" in result


def test_morning_star_three_candle_pattern():
    rows = _base_rows()
    rows[-3] = {"open": 10.0, "high": 10.1, "low": 7.9, "close": 8.0, "volume": 100}
    rows[-2] = {"open": 8.0, "high": 8.2, "low": 7.8, "close": 8.05, "volume": 100}
    rows[-1] = {"open": 8.1, "high": 9.3, "low": 8.0, "close": 9.2, "volume": 100}
    assert "morning_star" in _patterns(rows)


def test_evening_star_three_candle_pattern():
    rows = _base_rows()
    rows[-3] = {"open": 8.0, "high": 10.1, "low": 7.9, "close": 10.0, "volume": 100}
    rows[-2] = {"open": 10.0, "high": 10.2, "low": 9.8, "close": 10.05, "volume": 100}
    rows[-1] = {"open": 9.9, "high": 10.0, "low": 8.7, "close": 8.8, "volume": 100}
    assert "evening_star" in _patterns(rows)


def test_structure_marks_close_confirmed_breakout_as_bos_when_bias_is_not_opposite():
    engine = TechnicalAnalysisEngine()
    highs = [10.0] * 20
    lows = [8.0] * 20
    closes = [9.0] * 20
    highs[4] = 12.0
    highs[10] = 11.0
    lows[6] = 6.0
    lows[13] = 7.0
    highs[-1] = 12.5
    closes[-1] = 12.3
    lows[-1] = 9.0
    result = engine._market_structure(highs, lows, closes)
    assert result["breakout_status"] == "confirmed_bullish_breakout"
    assert any(x["type"] == "BOS" and x["direction"] == "bullish" for x in result["bos_choch"])


def test_structure_marks_countertrend_breakout_as_choch():
    engine = TechnicalAnalysisEngine()
    highs = [10.0] * 20
    lows = [8.0] * 20
    closes = [9.0] * 20
    highs[4] = 12.0
    highs[10] = 11.0
    lows[6] = 7.0
    lows[13] = 6.0
    highs[-1] = 12.5
    closes[-1] = 12.3
    lows[-1] = 8.0
    result = engine._market_structure(highs, lows, closes)
    assert result["bias"] == "bearish_structure"
    assert result["breakout_status"] == "confirmed_bullish_breakout"
    assert any(x["type"] == "CHOCH" and x["direction"] == "bullish" for x in result["bos_choch"])


def test_structure_distinguishes_wick_only_false_breakout():
    engine = TechnicalAnalysisEngine()
    highs = [10.0] * 20
    lows = [8.0] * 20
    closes = [9.0] * 20
    highs[4] = 12.0
    highs[10] = 11.0
    lows[6] = 6.0
    lows[13] = 7.0
    highs[-1] = 12.0
    closes[-1] = 10.5
    lows[-1] = 9.0
    result = engine._market_structure(highs, lows, closes)
    assert result["breakout_status"] == "false_bullish_breakout"
    assert any(x["type"] == "LIQUIDITY_SWEEP" for x in result["bos_choch"])
