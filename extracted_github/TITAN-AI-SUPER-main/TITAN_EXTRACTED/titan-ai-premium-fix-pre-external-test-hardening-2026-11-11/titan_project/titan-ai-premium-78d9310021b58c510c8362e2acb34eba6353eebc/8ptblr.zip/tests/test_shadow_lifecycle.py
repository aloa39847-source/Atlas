from __future__ import annotations

from app.models import db as dbmod
from app.services.shadow_trading import ShadowTradingService
from app.models.entities import SystemState
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker


def _db(tmp_path):
    db_path = tmp_path / "shadow.db"
    dbmod.engine.dispose()
    dbmod.engine = create_engine(f"sqlite:///{db_path}", connect_args={"check_same_thread": False}, future=True)
    dbmod.SessionLocal = sessionmaker(bind=dbmod.engine, autoflush=False, autocommit=False, future=True)
    dbmod.Base.metadata.create_all(bind=dbmod.engine)
    db = dbmod.SessionLocal()
    db.add(SystemState(id=1, emergency_stop=False))
    db.commit()
    return db


def test_shadow_full_fill_and_portfolio(tmp_path):
    db = _db(tmp_path)
    try:
        svc = ShadowTradingService()
        r = svc.create_shadow_order(db, env="demo", market="spot", symbol="BTC/USDT", side="buy", order_type="limit",
                                    quantity=0.1, price=500, reference_price=500, idempotency_key="shadow-key-001", simulate="fill", fill_ratio=1.0)
        db.commit()
        assert r.ok and r.order.status == "filled" and r.order.fees_paid > 0
        p = svc.get_portfolio(db, env="demo", market="spot")
        assert p["snapshot"]["positions_open"] == 1
        assert p["positions"][0]["quantity"] == 0.1
        assert p["snapshot"]["fees_total"] > 0
    finally:
        db.close()


def test_partial_fill(tmp_path):
    db = _db(tmp_path)
    try:
        svc = ShadowTradingService()
        r = svc.create_shadow_order(db, env="demo", market="spot", symbol="BTC/USDT", side="buy", order_type="limit",
                                    quantity=1.0, price=50, reference_price=50, idempotency_key="shadow-key-002", simulate="fill", fill_ratio=0.4)
        db.commit()
        assert r.ok and r.order.status == "partially_filled" and r.order.filled_quantity == 0.4
    finally:
        db.close()


def test_cancel(tmp_path):
    db = _db(tmp_path)
    try:
        svc = ShadowTradingService()
        r = svc.create_shadow_order(db, env="demo", market="spot", symbol="BTC/USDT", side="buy", order_type="limit",
                                    quantity=1.0, price=50, reference_price=50, idempotency_key="shadow-key-003", simulate="cancel")
        db.commit()
        assert r.ok and r.order.status == "cancelled"
    finally:
        db.close()


def test_duplicate_idempotency_no_duplicate_order(tmp_path):
    db = _db(tmp_path)
    try:
        svc = ShadowTradingService()
        r1 = svc.create_shadow_order(db, env="demo", market="spot", symbol="BTC/USDT", side="buy", order_type="limit",
                                     quantity=1.0, price=50, reference_price=50, idempotency_key="shadow-dup-0001", simulate="fill")
        db.commit()
        r2 = svc.create_shadow_order(db, env="demo", market="spot", symbol="BTC/USDT", side="buy", order_type="limit",
                                     quantity=1.0, price=50, reference_price=50, idempotency_key="shadow-dup-0001", simulate="fill")
        db.commit()
        assert r1.ok and r2.ok
        assert r2.details.get("duplicate") is True
        assert r2.order.id == r1.order.id
        p = svc.get_portfolio(db, env="demo", market="spot")
        assert len(p["orders"]) == 1  # no duplicate
    finally:
        db.close()


def test_connection_loss_recovery_requires_reconciliation(tmp_path):
    db = _db(tmp_path)
    try:
        svc = ShadowTradingService()
        r = svc.create_shadow_order(db, env="demo", market="spot", symbol="BTC/USDT", side="buy", order_type="limit",
                                    quantity=1.0, price=50, reference_price=50, idempotency_key="shadow-loss-001", simulate="connection_loss")
        db.commit()
        assert r.ok and r.details.get("reconcile_required") is True
        # retry with same idempotency key returns existing (no duplicate)
        r2 = svc.create_shadow_order(db, env="demo", market="spot", symbol="BTC/USDT", side="buy", order_type="limit",
                                     quantity=1.0, price=50, reference_price=50, idempotency_key="shadow-loss-001", simulate="fill")
        db.commit()
        assert r2.details.get("duplicate") is True
    finally:
        db.close()


def test_snapshot_counts_fees_once_and_retains_closed_realized_pnl(tmp_path):
    db = _db(tmp_path)
    try:
        svc = ShadowTradingService()
        opened = svc.create_shadow_order(
            db, env="demo", market="spot", symbol="BTC/USDT", side="buy", order_type="limit",
            quantity=0.8, price=100.0, reference_price=100.0,
            idempotency_key="shadow-accounting-open-01", simulate="fill", fee_rate=0.001,
        )
        db.commit()
        assert opened.ok and opened.position is not None
        before = svc.get_portfolio(db, env="demo", market="spot")
        assert abs(before["snapshot"]["fees_total"] - 0.08) < 1e-8

        closed = svc.close_shadow_position(db, position_id=opened.position.id, close_price=110.0, fee_rate=0.001)
        db.commit()
        assert closed["ok"] is True
        assert abs(closed["realized_pnl_gross"] - 8.0) < 1e-8
        assert abs(closed["realized_pnl"] - 7.912) < 1e-8
        after = svc.get_portfolio(db, env="demo", market="spot")
        assert after["snapshot"]["positions_open"] == 0
        assert abs(after["snapshot"]["realized_pnl"] - 8.0) < 1e-8
        assert abs(after["snapshot"]["fees_total"] - 0.168) < 1e-8
        assert abs(after["snapshot"]["equity_estimate"] - 10007.832) < 1e-8
    finally:
        db.close()
