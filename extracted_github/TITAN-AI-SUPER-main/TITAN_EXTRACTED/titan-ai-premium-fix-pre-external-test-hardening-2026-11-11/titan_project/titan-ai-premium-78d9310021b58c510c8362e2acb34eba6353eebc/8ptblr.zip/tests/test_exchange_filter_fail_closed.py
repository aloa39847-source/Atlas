from app.core.enums import MarketType
from app.integrations.binance_adapter import BinanceConfig, BinanceTestnetAdapter


def _exchange_info(filters=None, status="TRADING"):
    return {"symbols": [{
        "symbol": "BTCUSDT", "status": status,
        "filters": filters if filters is not None else [
            {"filterType": "PRICE_FILTER", "tickSize": "0.10"},
            {"filterType": "LOT_SIZE", "stepSize": "0.001"},
            {"filterType": "MARKET_LOT_SIZE", "stepSize": "0.001"},
            {"filterType": "MIN_NOTIONAL", "minNotional": "5"},
        ],
    }]}


def test_exchange_filter_loader_normalizes_spot_and_market_rules(monkeypatch):
    adapter = BinanceTestnetAdapter(BinanceConfig(market="spot"))
    monkeypatch.setattr(adapter, "get_exchange_info", lambda symbol: _exchange_info())
    filters, error = adapter._load_order_filters("BTC/USDT", "MARKET")
    assert error is None
    assert filters == {"tickSize": 0.1, "stepSize": 0.001, "minNotional": 5.0}


def test_futures_filter_loader_supports_binance_notional_field(monkeypatch):
    adapter = BinanceTestnetAdapter(BinanceConfig(market="futures"))
    info = _exchange_info([
        {"filterType": "PRICE_FILTER", "tickSize": "0.01"},
        {"filterType": "LOT_SIZE", "stepSize": "0.001"},
        {"filterType": "MIN_NOTIONAL", "notional": "10"},
    ])
    monkeypatch.setattr(adapter, "get_exchange_info", lambda symbol: info)
    filters, error = adapter._load_order_filters("BTCUSDT", "MARKET")
    assert error is None
    assert filters == {"tickSize": 0.01, "stepSize": 0.001, "minNotional": 10.0}


def test_exchange_filter_loader_fails_closed_on_missing_symbol_or_filters(monkeypatch):
    adapter = BinanceTestnetAdapter(BinanceConfig(market="futures"))
    monkeypatch.setattr(adapter, "get_exchange_info", lambda symbol: {"symbols": []})
    filters, error = adapter._load_order_filters("BTCUSDT", "MARKET")
    assert filters is None
    assert error == "exchange_symbol_filter_match_missing_or_ambiguous"


def test_exchange_filter_loader_rejects_malformed_numeric_filters(monkeypatch):
    adapter = BinanceTestnetAdapter(BinanceConfig(market="spot"))
    malformed = _exchange_info()
    malformed["symbols"][0]["filters"][0]["tickSize"] = "not-a-number"
    monkeypatch.setattr(adapter, "get_exchange_info", lambda symbol: malformed)
    filters, error = adapter._load_order_filters("BTCUSDT", "LIMIT")
    assert filters is None
    assert error == "exchange_tick_or_step_filter_invalid"


def test_exchange_filter_loader_rejects_non_trading_symbol(monkeypatch):
    adapter = BinanceTestnetAdapter(BinanceConfig(market="spot"))
    monkeypatch.setattr(adapter, "get_exchange_info", lambda symbol: _exchange_info(status="BREAK"))
    filters, error = adapter._load_order_filters("BTCUSDT", "LIMIT")
    assert filters is None
    assert error == "exchange_symbol_not_trading"


def test_testnet_place_order_never_sends_when_exchange_filters_unavailable(monkeypatch):
    adapter = BinanceTestnetAdapter(BinanceConfig(
        enabled=True, environment="testnet", market="spot",
        api_key_ref="test-key", api_secret_ref="test-secret"))
    monkeypatch.setattr(adapter, "_api_key", lambda: "test-key")
    monkeypatch.setattr(adapter, "_api_secret", lambda: "test-secret")
    monkeypatch.setattr(adapter, "get_order_by_client_id",
                        lambda symbol, client_id: {"found": False, "confirmed_absent": True})
    monkeypatch.setattr(adapter, "_load_order_filters",
                        lambda symbol, order_type: (None, "exchange_symbol_filters_unavailable"))
    sent = []
    monkeypatch.setattr(adapter, "_request", lambda *a, **k: sent.append((a, k)) or {"orderId": 1})
    result = adapter.place_order("BTCUSDT", "BUY", "LIMIT", 0.001, price=50,
                                 reference_price=50, idempotency_key="titan-test-001")
    assert result["sent_to_exchange"] is False
    assert result["error"] == "exchange_symbol_filters_unavailable"
    assert sent == []
