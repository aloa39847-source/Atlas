import time
import pytest
from app.core.config import settings
from app.core.enums import DataSourceKind, Timeframe
from app.engines.market_data import MarketDataEngine


class FakeBinancePublic:
    def __init__(self, fail=False):
        self.fail = fail
        self.markets = []

    def get_klines(self, symbol, interval, limit=500, market="spot"):
        self.markets.append((symbol, interval, market))
        if self.fail:
            raise RuntimeError("feed_down")
        now = int(time.time() * 1000)
        step = {"1d": 1440, "4h": 240, "1h": 60, "15m": 15, "5m": 5}[interval] * 60_000
        return [[now - (120 - i) * step - step, "100", "101", "99", "100.5", "10", now - (120 - i) * step - 60_000] for i in range(120)]

    def klines_to_candles(self, klines):
        return [{"timestamp": int(k[0]), "open": float(k[1]), "high": float(k[2]), "low": float(k[3]), "close": float(k[4]), "volume": float(k[5]), "close_time": int(k[6])} for k in klines]


def test_live_public_market_data_uses_all_five_closed_timeframes(monkeypatch):
    monkeypatch.setattr(settings, "binance_public_data_enabled", True)
    md = MarketDataEngine()
    fake = FakeBinancePublic()
    md.public_data = fake
    batches = md.get_multi_timeframe("BTC/USDT", market_type="futures")
    assert set(batches) == {Timeframe.D1, Timeframe.H4, Timeframe.H1, Timeframe.M15, Timeframe.M5}
    assert all(b.source == DataSourceKind.LIVE_PUBLIC for b in batches.values())
    assert all("read-only" in b.note for b in batches.values())
    assert all(m == "futures" for _, _, m in fake.markets)


def test_live_data_failure_does_not_fall_back_to_synthetic(monkeypatch):
    monkeypatch.setattr(settings, "binance_public_data_enabled", True)
    md = MarketDataEngine()
    md.public_data = FakeBinancePublic(fail=True)
    with pytest.raises(RuntimeError, match="feed_down"):
        md.get_multi_timeframe("BTC/USDT", market_type="spot")


def test_synthetic_data_remains_default(monkeypatch):
    monkeypatch.setattr(settings, "binance_public_data_enabled", False)
    md = MarketDataEngine()
    batches = md.get_multi_timeframe("BTC/USDT")
    assert all(b.source == DataSourceKind.SYNTHETIC_LABELED for b in batches.values())
