from types import SimpleNamespace

import pytest

from app.integrations.binance_adapter import BinanceConfig, BinanceTestnetAdapter


@pytest.mark.parametrize(
    ("dual_side", "requested_side", "expected_side", "expected_position_side"),
    [
        (False, "LONG", "BUY", None),
        (False, "SHORT", "SELL", None),
        (True, "LONG", "BUY", "LONG"),
        (True, "SHORT", "SELL", "SHORT"),
    ],
)
def test_futures_side_normalization_reads_position_mode_once(
    monkeypatch, dual_side, requested_side, expected_side, expected_position_side
):
    adapter = BinanceTestnetAdapter(BinanceConfig(
        enabled=True, environment="testnet", market="futures",
        api_key_ref="env:BINANCE_TESTNET_API_KEY",
        api_secret_ref="env:BINANCE_TESTNET_API_SECRET",
    ))
    monkeypatch.setattr(adapter, "_api_key", lambda: "test-key")
    monkeypatch.setattr(adapter, "_api_secret", lambda: "test-secret")
    monkeypatch.setattr(adapter, "get_order_by_client_id",
                        lambda *_: {"found": False, "confirmed_absent": True})
    calls = {"position_mode": 0, "request": []}

    def position_mode():
        calls["position_mode"] += 1
        return {"dualSidePosition": dual_side}

    monkeypatch.setattr(adapter, "get_position_mode", position_mode)
    monkeypatch.setattr(adapter.public_data, "get_ticker_price", lambda *_args, **_kwargs: 100.0)
    monkeypatch.setattr(adapter, "_load_order_filters",
                        lambda *_: ({"tickSize": 0.01, "stepSize": 0.001, "minNotional": 5.0}, None))
    monkeypatch.setattr(adapter.gateway, "validate",
                        lambda **_kwargs: SimpleNamespace(ok=True, to_dict=lambda: {"ok": True}))
    def request(method, path, signed=False, params=None):
        calls["request"].append((method, path, params or {}))
        return {"orderId": 123, "status": "NEW"}
    monkeypatch.setattr(adapter, "_request", request)

    result = adapter.place_order(
        "BTCUSDT", requested_side, "MARKET", 0.1,
        reference_price=100.0, idempotency_key="titan-futures-01",
    )

    assert result["ok"] is True
    assert calls["position_mode"] == 1
    assert len(calls["request"]) == 1
    params = calls["request"][0][2]
    assert params["side"] == expected_side
    if expected_position_side:
        assert params["positionSide"] == expected_position_side
    else:
        assert "positionSide" not in params
