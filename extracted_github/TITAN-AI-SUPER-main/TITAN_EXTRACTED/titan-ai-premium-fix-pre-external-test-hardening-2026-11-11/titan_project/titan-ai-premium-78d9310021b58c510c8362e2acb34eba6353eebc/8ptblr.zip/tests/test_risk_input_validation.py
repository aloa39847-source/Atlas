import math
import pytest

from app.core.enums import EnvironmentMode, MarketType
from app.engines.risk import RiskEngine


def _valid(**overrides):
    values = dict(
        environment=EnvironmentMode.DEMO, market=MarketType.SPOT, balance=1000.0,
        risk_per_trade=0.01, entry=100.0, stop_loss=99.0, leverage=1.0,
    )
    values.update(overrides)
    return RiskEngine().validate_trade(**values)


@pytest.mark.parametrize("field,value", [
    ("balance", math.nan), ("entry", math.inf), ("stop_loss", -math.inf),
    ("risk_per_trade", math.nan), ("leverage", math.inf),
    ("daily_loss_used", math.nan), ("current_exposure", math.inf),
    ("max_exposure", math.nan), ("max_daily_loss", math.inf),
    ("max_leverage", math.nan), ("max_risk_per_trade", math.inf),
    ("open_positions", math.nan), ("max_open_positions", math.inf),
])
def test_trade_validation_fails_closed_for_non_finite_inputs(field, value):
    result = _valid(**{field: value})
    assert result["ok"] is False
    assert result["position_size"] == 0.0
    assert result["issues"][0].endswith("_must_be_finite_number")


@pytest.mark.parametrize("field,value", [
    ("daily_loss_used", -1), ("current_exposure", -1),
    ("max_exposure", 0), ("max_open_positions", 0),
    ("open_positions", -1), ("leverage", 0),
])
def test_trade_validation_rejects_invalid_negative_or_zero_controls(field, value):
    result = _valid(**{field: value})
    assert result["ok"] is False
    assert result["position_size"] == 0.0


@pytest.mark.parametrize("kwargs", [
    {"notional": math.nan},
    {"notional": math.inf},
    {"maker_fee_rate": math.nan},
    {"taker_fee_rate": -0.001},
    {"slippage_rate": math.inf},
    {"funding_periods": -1},
    {"maker_taker": "unknown"},
])
def test_cost_estimation_rejects_invalid_inputs(kwargs):
    args = dict(notional=100.0, market=MarketType.FUTURES)
    args.update(kwargs)
    with pytest.raises(ValueError):
        RiskEngine().estimate_costs(**args)


def test_valid_trade_still_respects_user_approved_position_caps():
    spot = _valid(balance=10000, risk_per_trade=0.02, entry=100, stop_loss=99, leverage=1)
    futures = _valid(market=MarketType.FUTURES, balance=100000, risk_per_trade=0.02,
                     entry=100, stop_loss=99, leverage=3)
    assert spot["ok"] is True and spot["position_notional_estimate"] <= 80
    assert futures["ok"] is True and futures["position_notional_estimate"] <= 800
