import json
import os
import pytest

from app.core.config import settings
from app.services import credentials


def test_credential_encryption_is_authenticated_and_randomized(monkeypatch):
    monkeypatch.setattr(settings, "secret_key", "a-strong-test-secret-key-with-32-bytes-minimum")
    one = credentials.encrypt_secret("testnet-api-secret")
    two = credentials.encrypt_secret("testnet-api-secret")
    assert one != two
    assert "testnet-api-secret" not in one
    assert credentials.decrypt_secret(one) == "testnet-api-secret"
    tampered = one[:-2] + ("AA" if one[-2:] != "AA" else "BB")
    assert credentials.decrypt_secret(tampered) == ""


def test_credential_storage_fails_closed_with_default_weak_secret(monkeypatch, tmp_path):
    monkeypatch.setattr(settings, "secret_key", "dev-only-change-locally")
    monkeypatch.setattr(credentials, "_storage_path", lambda: tmp_path / "credentials.json")
    with pytest.raises(RuntimeError, match="strong_titan_secret_key_required"):
        credentials.save_testnet_credentials("test-key", "test-secret", "spot")
    assert not (tmp_path / "credentials.json").exists()


def test_credentials_are_encrypted_market_scoped_and_permission_restricted(monkeypatch, tmp_path):
    monkeypatch.setattr(settings, "secret_key", "another-strong-test-secret-key-with-at-least-32-bytes")
    path = tmp_path / "credentials.json"
    monkeypatch.setattr(credentials, "_storage_path", lambda: path)
    saved = credentials.save_testnet_credentials("futures-key", "futures-secret", "futures")
    assert saved["ok"] is True
    raw = path.read_text()
    assert "futures-key" not in raw
    assert "futures-secret" not in raw
    loaded = credentials.load_testnet_credentials()
    assert loaded["configured"] is True
    assert loaded["market"] == "futures"
    assert loaded["api_key"] == "futures-key"
    assert loaded["api_secret"] == "futures-secret"
    if os.name == "posix":
        assert os.stat(path).st_mode & 0o777 == 0o600


def test_old_xor_credential_format_is_not_loaded_as_valid(monkeypatch, tmp_path):
    monkeypatch.setattr(settings, "secret_key", "another-strong-test-secret-key-with-at-least-32-bytes")
    path = tmp_path / "credentials.json"
    path.write_text(json.dumps({"market": "spot", "api_key_enc": "legacy", "api_secret_enc": "legacy",
                                "has_key": True, "has_secret": True}))
    monkeypatch.setattr(credentials, "_storage_path", lambda: path)
    result = credentials.load_testnet_credentials()
    assert result["configured"] is False
    assert result["reason"] == "credential_format_upgrade_required"
