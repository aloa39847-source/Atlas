from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from app.models.db import Base
from app.models.entities import PositionRecord
from app.services.position_management import PositionManagementService
from app.services.shadow_trading import ShadowTradingService


def _db(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'protection-cycle.db'}")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine, autoflush=False, autocommit=False)()


def _position(db, *, environment="demo", market="spot", shadow=True):
    row = PositionRecord(
        environment_mode=environment, market_type=market, symbol="BTC/USDT",
        side="long_spot" if market == "spot" else "long", quantity=1.0,
        entry_avg_price=100.0, mark_price=100.0, status="open", shadow=shadow,
        metadata_json={"protection": {"stop_loss": 95.0, "take_profit": 110.0,
                     "trailing_stop_pct": None, "triggered": False}},
    )
    db.add(row)
    db.flush()
    return row


def test_protection_evaluation_is_scoped_to_environment_and_market(tmp_path):
    db = _db(tmp_path)
    try:
        demo_spot = _position(db, environment="demo", market="spot")
        _position(db, environment="demo", market="futures")
        _position(db, environment="live", market="spot")
        events = PositionManagementService().evaluate_prices(
            db, prices={"BTC/USDT": 94}, environment_mode="demo", market_type="spot",
        )
        assert [event["position_id"] for event in events] == [demo_spot.id]
    finally:
        db.close()


def test_shadow_close_refuses_real_position_and_invalid_prices(tmp_path):
    db = _db(tmp_path)
    try:
        real = _position(db, shadow=False)
        shadow = _position(db, shadow=True)
        service = ShadowTradingService()
        assert service.close_shadow_position(db, position_id=real.id, close_price=90)["reason"] == "real_position_close_not_supported_by_shadow_service"
        assert service.close_shadow_position(db, position_id=shadow.id, close_price=float("nan"))["reason"] == "positive_finite_close_price_required"
        assert service.close_shadow_position(db, position_id=shadow.id, close_price=90, fee_rate=0.2)["reason"] == "fee_rate_out_of_range"
        assert shadow.status == "open"
    finally:
        db.close()


def test_triggered_shadow_protection_can_be_closed_once_with_fees(tmp_path):
    db = _db(tmp_path)
    try:
        position = _position(db)
        protection = PositionManagementService()
        events = protection.evaluate_prices(
            db, prices={"BTC/USDT": 94}, environment_mode="demo", market_type="spot",
        )
        assert len(events) == 1
        closed = ShadowTradingService().close_shadow_position(
            db, position_id=position.id, close_price=94, fee_rate=0.001,
        )
        db.commit()
        assert closed["ok"] is True
        assert position.status == "closed" and position.quantity == 0
        assert position.realized_pnl == -6.0
        assert position.fees_total > 0
        assert protection.evaluate_prices(
            db, prices={"BTC/USDT": 90}, environment_mode="demo", market_type="spot",
        ) == []
    finally:
        db.close()


def test_orchestrator_closes_shadow_position_on_live_public_protection_trigger(tmp_path, monkeypatch):
    from app.services import orchestrator as orchestrator_module
    from app.services.orchestrator import TradingOrchestrator

    db = _db(tmp_path)
    try:
        position = _position(db)
        monkeypatch.setattr(
            orchestrator_module.core_service, "analyze",
            lambda *args, **kwargs: {
                "action": "wait", "market_price_source": "live_public",
                "market_prices": {"BTC/USDT": 94.0}, "decision_id": 10,
            },
        )
        result = TradingOrchestrator().run_cycle(
            db, symbol="BTC/USDT", market="spot", environment="demo",
        )
        assert result["protection_monitoring"]["evaluated"] is True
        assert len(result["protection_events"]) == 1
        assert result["protection_events"][0]["close_result"]["ok"] is True
        assert position.status == "closed"
        assert result["executed"] is False
    finally:
        db.close()


def test_orchestrator_never_triggers_protection_from_synthetic_prices(tmp_path, monkeypatch):
    from app.services import orchestrator as orchestrator_module
    from app.services.orchestrator import TradingOrchestrator

    db = _db(tmp_path)
    try:
        position = _position(db)
        monkeypatch.setattr(
            orchestrator_module.core_service, "analyze",
            lambda *args, **kwargs: {
                "action": "wait", "market_price_source": "synthetic_labeled",
                "market_prices": {"BTC/USDT": 94.0}, "decision_id": 11,
            },
        )
        result = TradingOrchestrator().run_cycle(
            db, symbol="BTC/USDT", market="spot", environment="demo",
        )
        assert result["protection_monitoring"]["evaluated"] is False
        assert result["protection_events"] == []
        assert position.status == "open"
    finally:
        db.close()
