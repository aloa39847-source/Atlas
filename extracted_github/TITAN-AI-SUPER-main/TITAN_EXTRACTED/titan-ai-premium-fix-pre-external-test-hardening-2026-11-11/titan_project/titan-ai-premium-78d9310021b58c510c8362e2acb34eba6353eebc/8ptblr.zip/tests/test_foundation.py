from __future__ import annotations

from app.core.enums import DataSourceKind, DecisionAction, EnvironmentMode, MarketType, Timeframe
from app.engines.decision import DecisionEngine
from app.engines.market_data import MarketDataEngine
from app.engines.risk import RiskEngine
from app.engines.technical import TechnicalAnalysisEngine


def test_separation_enums():
    assert EnvironmentMode.DEMO.value == "demo"
    assert EnvironmentMode.LIVE.value == "live"
    assert {m.value for m in MarketType} == {"spot", "futures", "earn"}


def test_market_data_is_labeled_synthetic():
    md = MarketDataEngine()
    batch = md.get_synthetic_candles("BTC/USDT", Timeframe.M5, limit=60, seed=1)
    assert batch.source == DataSourceKind.SYNTHETIC_LABELED
    assert "SYNTHETIC_LABELED" in batch.note
    assert len(batch.df) == 60
    cols = set(getattr(batch.df, "columns", []))
    assert {"open", "high", "low", "close", "volume"}.issubset(cols)


def test_technical_analysis_returns_structure():
    md = MarketDataEngine()
    ta = TechnicalAnalysisEngine()
    df = md.get_synthetic_candles("ETH/USDT", Timeframe.H1, limit=80, seed=2).df
    res = ta.analyze(df, Timeframe.H1)
    assert res.timeframe == Timeframe.H1
    assert res.trend in {"bullish", "bearish", "sideways", "unknown"}
    assert "rsi14" in res.indicators
    assert "bias" in res.structure


def test_risk_spot_has_no_leverage_and_earn_blocked():
    risk = RiskEngine()
    spot = risk.validate_trade(environment=EnvironmentMode.DEMO, market=MarketType.SPOT, balance=1000, risk_per_trade=0.01,
                               entry=100, stop_loss=99, leverage=5)
    assert spot["leverage_used"] == 1.0
    earn = risk.validate_trade(environment=EnvironmentMode.DEMO, market=MarketType.EARN, balance=1000, risk_per_trade=0.01,
                               entry=100, stop_loss=99, leverage=1)
    assert earn["ok"] is False


def test_risk_leverage_is_capped():
    risk = RiskEngine()
    fut = risk.validate_trade(environment=EnvironmentMode.DEMO, market=MarketType.FUTURES, balance=1000, risk_per_trade=0.01,
                              entry=100, stop_loss=99, leverage=999, max_leverage=5)
    assert fut["leverage_used"] <= 5


def test_cost_estimate_is_labeled():
    risk = RiskEngine()
    c = risk.estimate_costs(1000, MarketType.FUTURES).to_dict()
    assert c["is_estimate"] is True
    assert c["total_cost_estimate"] >= 0


def test_decision_returns_valid_action_and_labels_data():
    md = MarketDataEngine()
    ta = TechnicalAnalysisEngine()
    de = DecisionEngine()
    batches = md.get_multi_timeframe("BTC/USDT", seed=42)
    analyses = {tf: ta.analyze(b.df, tf) for tf, b in batches.items()}
    result = de.decide(symbol="BTC/USDT", market=MarketType.SPOT, environment=EnvironmentMode.DEMO, timeframe_analyses=analyses, batches=batches)
    assert result["action"] in {a.value for a in DecisionAction}
    assert result["data_source_warning"]
    assert "synthetic_labeled" in str(result["data_sources"])
