from app.core.enums import MarketType
from app.integrations.binance_adapter import BinanceAdapter, BinanceConfig
from app.integrations.telegram_adapter import TelegramAdapter


def test_binance_shadow_order_does_not_send():
    b = BinanceAdapter(BinanceConfig(enabled=False, environment="demo"))
    r = b.place_order_shadow(symbol="BTC/USDT", market=MarketType.SPOT, side="buy", order_type="limit", quantity=0.01, price=50000, reference_price=50000)
    assert r["mode"] == "shadow"
    assert r["sent_to_exchange"] is False
    assert "precheck" in r


def test_binance_live_blocked_in_foundation():
    b = BinanceAdapter()
    r = b.place_order_live(symbol="BTC/USDT")
    assert r["ok"] is False and r["sent_to_exchange"] is False


def test_telegram_sensitive_command_not_executed():
    t = TelegramAdapter()
    r = t.parse_command("123", "/startbot")
    assert r["sensitive"] is True
    assert r["executed"] is False
    assert r["authorized"] is None
