import math
import pytest

from app.core.enums import MarketType
from app.engines.order_gateway import PreTradeOrderGateway


@pytest.mark.parametrize("field,value", [
    ("quantity", math.nan), ("quantity", math.inf), ("quantity", -math.inf),
    ("price", math.nan), ("price", math.inf), ("price", -math.inf),
    ("reference_price", math.nan), ("reference_price", math.inf),
    ("max_notional", math.nan), ("max_notional", math.inf),
])
def test_gateway_rejects_non_finite_order_inputs_before_compliance(field, value):
    args = dict(symbol="BTCUSDT", market=MarketType.SPOT, side="buy",
                order_type="limit", quantity=0.001, price=50.0,
                reference_price=50.0, environment_mode="demo")
    args[field] = value
    result = PreTradeOrderGateway().validate(**args)
    assert result.ok is False
    assert result.reason.startswith("invalid_numeric_input:")


@pytest.mark.parametrize("field,value", [
    ("tickSize", math.nan), ("tickSize", math.inf),
    ("stepSize", -math.inf), ("minNotional", math.nan),
    ("minNotional", -1.0),
])
def test_gateway_rejects_invalid_exchange_filter_values(field, value):
    args = dict(symbol="BTCUSDT", market=MarketType.SPOT, side="buy",
                order_type="limit", quantity=0.001, price=50.0,
                reference_price=50.0, environment_mode="demo",
                exchange_filters={"tickSize": 0.01, "stepSize": 0.001, "minNotional": 5.0})
    args["exchange_filters"][field] = value
    result = PreTradeOrderGateway().validate(**args)
    assert result.ok is False
    assert result.reason.startswith("invalid_numeric_input:")


def test_gateway_rejects_boolean_numeric_values():
    result = PreTradeOrderGateway().validate(
        symbol="BTCUSDT", market=MarketType.SPOT, side="buy",
        order_type="limit", quantity=True, price=50.0,
        reference_price=50.0, environment_mode="demo")
    assert result.ok is False
    assert result.reason == "invalid_numeric_input:quantity"


def test_gateway_still_enforces_hard_spot_notional_cap():
    result = PreTradeOrderGateway().validate(
        symbol="BTCUSDT", market=MarketType.SPOT, side="buy",
        order_type="limit", quantity=2.0, price=50.0,
        reference_price=50.0, environment_mode="demo")
    assert result.ok is False
    assert result.reason == "notional_exceeds_limit"


def test_market_order_notional_uses_trusted_reference_not_caller_price():
    result = PreTradeOrderGateway().validate(
        symbol="BTCUSDT", market=MarketType.SPOT, side="buy",
        order_type="market", quantity=0.002, price=1.0,
        reference_price=50000.0, environment_mode="demo")
    assert result.ok is False
    assert result.reason == "notional_exceeds_limit"


def test_market_order_ignores_caller_price_when_within_notional_cap():
    result = PreTradeOrderGateway().validate(
        symbol="BTCUSDT", market=MarketType.SPOT, side="buy",
        order_type="market", quantity=0.001, price=1.0,
        reference_price=50000.0, environment_mode="demo")
    assert result.ok is True
    assert result.normalized["notional_estimate"] == 50.0
    assert "caller_supplied_market_price_ignored" in result.warnings


def test_gateway_rejects_order_types_without_complete_exchange_parameters():
    for order_type in ("stop", "stop_limit", "trailing_stop_market", "unknown"):
        result = PreTradeOrderGateway().validate(
            symbol="BTCUSDT", market=MarketType.SPOT, side="buy",
            order_type=order_type, quantity=0.001, price=50.0,
            reference_price=50.0, environment_mode="demo")
        assert result.ok is False
        assert result.reason == "unsupported_order_type"


def test_gateway_requires_limit_price_and_trusted_market_reference():
    gateway = PreTradeOrderGateway()
    missing_limit = gateway.validate(
        symbol="BTCUSDT", market=MarketType.SPOT, side="buy",
        order_type="limit", quantity=0.001, reference_price=50.0)
    missing_market_ref = gateway.validate(
        symbol="BTCUSDT", market=MarketType.SPOT, side="buy",
        order_type="market", quantity=0.001)
    assert missing_limit.reason == "limit_order_price_required"
    assert missing_market_ref.reason == "reference_price_required_for_notional_cap"
