from app.integrations.binance_adapter import BinanceConfig, BinanceTestnetAdapter



def _fake_symbol_info(symbol):
    return {"symbols": [{
        "symbol": symbol.replace("/", "").upper(), "status": "TRADING",
        "filters": [
            {"filterType": "PRICE_FILTER", "tickSize": "0.10"},
            {"filterType": "LOT_SIZE", "stepSize": "0.001"},
            {"filterType": "MARKET_LOT_SIZE", "stepSize": "0.001"},
            {"filterType": "MIN_NOTIONAL", "minNotional": "5"},
        ],
    }]}


def _adapter(monkeypatch):
    monkeypatch.setenv("TITAN_TEST_API_KEY", "test-key")
    monkeypatch.setenv("TITAN_TEST_API_SECRET", "test-secret")
    adapter = BinanceTestnetAdapter(BinanceConfig(
        enabled=True, environment="testnet", market="spot",
        api_key_ref="env:TITAN_TEST_API_KEY",
        api_secret_ref="env:TITAN_TEST_API_SECRET",
    ))
    monkeypatch.setattr(adapter, "get_exchange_info", lambda symbol: _fake_symbol_info(symbol))
    return adapter


def test_testnet_order_duplicate_lookup_prevents_second_submission(monkeypatch):
    adapter = _adapter(monkeypatch)
    calls = []

    def fake_request(method, path, signed=False, params=None):
        calls.append(method)
        if method == "GET":
            return {"orderId": 99, "clientOrderId": "titan-order-0001", "status": "NEW"}
        return {"orderId": 100}

    monkeypatch.setattr(adapter, "_request", fake_request)
    result = adapter.place_order("BTC/USDT", "BUY", "LIMIT", 0.001, price=50000,
                                 idempotency_key="titan-order-0001")
    assert result["duplicate"] is True
    assert calls == ["GET"]


def test_testnet_order_uncertain_lookup_blocks_submission(monkeypatch):
    adapter = _adapter(monkeypatch)
    calls = []

    def fake_request(method, path, signed=False, params=None):
        calls.append(method)
        return {"error": "http_error", "status": 500, "body": "unknown"}

    monkeypatch.setattr(adapter, "_request", fake_request)
    result = adapter.place_order("BTC/USDT", "BUY", "LIMIT", 0.001, price=50000,
                                 idempotency_key="titan-order-0002")
    assert result["error"] == "order_status_uncertain_blocked"
    assert calls == ["GET"]


def test_testnet_order_confirmed_absent_then_submits_once(monkeypatch):
    adapter = _adapter(monkeypatch)
    calls = []

    def fake_request(method, path, signed=False, params=None):
        calls.append((method, params))
        if method == "GET":
            return {"error": "http_error", "status": 400, "body": '{"code":-2013,"msg":"Order does not exist."}'}
        return {"orderId": 100}

    monkeypatch.setattr(adapter, "_request", fake_request)
    result = adapter.place_order("BTC/USDT", "BUY", "LIMIT", 0.001, price=50000,
                                 idempotency_key="titan-order-0003")
    assert result["ok"] is True
    assert calls[1][0] == "POST"
    assert calls[1][1]["newClientOrderId"] == "titan-order-0003"


def test_futures_close_is_blocked_until_reduce_only_position_sync_is_verified():
    adapter = BinanceTestnetAdapter(BinanceConfig(enabled=True, environment="testnet", market="futures"))
    result = adapter.close_position("BTC/USDT", "LONG", 0.001, reference_price=50000,
                                    idempotency_key="close-order-0001")
    assert result["ok"] is False
    assert result["sent_to_exchange"] is False
    assert result["error"] == "testnet_credentials_required"


def test_binance_order_guard_fails_closed_when_system_state_is_missing(monkeypatch):
    from app import star_app
    class DummyDB:
        def get(self, model, key):
            return None
        def close(self):
            pass
    monkeypatch.setattr(star_app, "db_sess", lambda: DummyDB())
    result = star_app._binance_emergency_stop_error()
    assert result.status_code == 503


def test_market_order_uses_server_fetched_price_not_caller_price(monkeypatch):
    adapter = _adapter(monkeypatch)
    calls = []
    monkeypatch.setattr(adapter.public_data, "get_ticker_price", lambda symbol, market: 50000.0)

    def fake_request(method, path, signed=False, params=None):
        calls.append(method)
        if method == "GET":
            return {"error": "http_error", "status": 400, "body": '{"code":-2013,"msg":"Order does not exist."}'}
        return {"orderId": 101}

    monkeypatch.setattr(adapter, "_request", fake_request)
    result = adapter.place_order("BTC/USDT", "BUY", "MARKET", 0.002,
                                 reference_price=1.0, idempotency_key="titan-order-0004")
    assert result["error"] == "pretrade_blocked"
    assert calls == ["GET"]


def test_market_order_fails_closed_if_server_price_is_unavailable(monkeypatch):
    adapter = _adapter(monkeypatch)
    calls = []

    def fail_price(symbol, market):
        raise RuntimeError("public feed offline")

    monkeypatch.setattr(adapter.public_data, "get_ticker_price", fail_price)

    def fake_request(method, path, signed=False, params=None):
        calls.append(method)
        return {"error": "http_error", "status": 400, "body": '{"code":-2013,"msg":"Order does not exist."}'}

    monkeypatch.setattr(adapter, "_request", fake_request)
    result = adapter.place_order("BTC/USDT", "BUY", "MARKET", 0.001,
                                 reference_price=1.0, idempotency_key="titan-order-0005")
    assert result["error"] == "market_reference_price_unavailable"
    assert calls == ["GET"]


def _futures_close_adapter(monkeypatch):
    monkeypatch.setenv("TITAN_TEST_API_KEY", "test-key")
    monkeypatch.setenv("TITAN_TEST_API_SECRET", "test-secret")
    adapter = BinanceTestnetAdapter(BinanceConfig(
        enabled=True, environment="testnet", market="futures",
        api_key_ref="env:TITAN_TEST_API_KEY", api_secret_ref="env:TITAN_TEST_API_SECRET",
    ))
    monkeypatch.setattr(adapter, "get_exchange_info", lambda symbol: _fake_symbol_info(symbol))
    monkeypatch.setattr(adapter.public_data, "get_ticker_price", lambda symbol, market: 50000.0)
    return adapter


def test_futures_close_uses_synced_long_position_and_reduce_only(monkeypatch):
    adapter = _futures_close_adapter(monkeypatch)
    calls = []
    def fake_request(method, path, signed=False, params=None):
        calls.append((method, path, params))
        if method == "GET" and path == "/fapi/v1/order":
            return {"error": "http_error", "status": 400, "body": '{"code":-2013,"msg":"Order does not exist."}'}
        if method == "GET" and path == "/fapi/v2/account":
            return {"positions": [{"symbol": "BTCUSDT", "positionAmt": "0.005", "positionSide": "BOTH"}]}
        return {"orderId": 777, "status": "NEW"}
    monkeypatch.setattr(adapter, "_request", fake_request)
    result = adapter.close_position("BTCUSDT", "SELL", 0.005, reference_price=1.0, idempotency_key="futures-close-001")
    assert result["ok"] is True and result["reduce_only_close"] is True
    post = [x for x in calls if x[0] == "POST"][0]
    assert post[1] == "/fapi/v1/order" and post[2]["side"] == "SELL"
    assert post[2]["reduceOnly"] == "true"


def test_futures_close_uses_buy_side_for_synced_short_position(monkeypatch):
    adapter = _futures_close_adapter(monkeypatch)
    calls = []
    def fake_request(method, path, signed=False, params=None):
        calls.append((method, path, params))
        if method == "GET" and path == "/fapi/v1/order":
            return {"error": "http_error", "status": 400, "body": '{"code":-2013,"msg":"Order does not exist."}'}
        if method == "GET" and path == "/fapi/v2/account":
            return {"positions": [{"symbol": "BTCUSDT", "positionAmt": "-0.004", "positionSide": "BOTH"}]}
        return {"orderId": 778, "status": "NEW"}
    monkeypatch.setattr(adapter, "_request", fake_request)
    result = adapter.close_position("BTCUSDT", "BUY", 0.004, idempotency_key="futures-close-002")
    assert result["ok"] is True
    post = [x for x in calls if x[0] == "POST"][0]
    assert post[2]["side"] == "BUY" and post[2]["reduceOnly"] == "true"


def test_futures_close_rejects_quantity_above_synced_position(monkeypatch):
    adapter = _futures_close_adapter(monkeypatch)
    calls = []
    def fake_request(method, path, signed=False, params=None):
        calls.append(method)
        if method == "GET" and path == "/fapi/v1/order":
            return {"error": "http_error", "status": 400, "body": '{"code":-2013,"msg":"Order does not exist."}'}
        if method == "GET" and path == "/fapi/v2/account":
            return {"positions": [{"symbol": "BTCUSDT", "positionAmt": "0.002", "positionSide": "BOTH"}]}
        raise AssertionError("close must not be sent")
    monkeypatch.setattr(adapter, "_request", fake_request)
    result = adapter.close_position("BTCUSDT", "SELL", 0.003, idempotency_key="futures-close-003")
    assert result["error"] == "close_quantity_exceeds_synced_position"
    assert "POST" not in calls


def test_futures_close_fails_closed_when_position_sync_is_unavailable(monkeypatch):
    adapter = _futures_close_adapter(monkeypatch)
    calls = []
    def fake_request(method, path, signed=False, params=None):
        calls.append(method)
        if method == "GET" and path == "/fapi/v1/order":
            return {"error": "http_error", "status": 400, "body": '{"code":-2013,"msg":"Order does not exist."}'}
        return {"error": "http_error", "status": 503, "body": "offline"}
    monkeypatch.setattr(adapter, "_request", fake_request)
    result = adapter.close_position("BTCUSDT", "SELL", 0.001, idempotency_key="futures-close-004")
    assert result["error"] == "futures_position_sync_unavailable"
    assert "POST" not in calls


def test_hedge_mode_futures_close_uses_position_side_without_reduce_only(monkeypatch):
    adapter = _futures_close_adapter(monkeypatch)
    calls = []
    def fake_request(method, path, signed=False, params=None):
        calls.append((method, path, params))
        if method == "GET" and path == "/fapi/v1/order":
            return {"error": "http_error", "status": 400, "body": '{"code":-2013,"msg":"Order does not exist."}'}
        if method == "GET" and path == "/fapi/v2/account":
            return {"positions": [{"symbol": "BTCUSDT", "positionAmt": "0.002", "positionSide": "LONG"}]}
        return {"orderId": 779, "status": "NEW"}
    monkeypatch.setattr(adapter, "_request", fake_request)
    result = adapter.close_position("BTCUSDT", "LONG", 0.002, idempotency_key="futures-close-005")
    assert result["ok"] is True
    post = [x for x in calls if x[0] == "POST"][0]
    assert post[2]["side"] == "SELL" and post[2]["positionSide"] == "LONG"
    assert "reduceOnly" not in post[2]


def test_futures_close_post_timeout_is_marked_uncertain(monkeypatch):
    adapter = _futures_close_adapter(monkeypatch)
    def fake_request(method, path, signed=False, params=None):
        if method == "GET" and path == "/fapi/v1/order":
            return {"error": "http_error", "status": 400, "body": '{"code":-2013,"msg":"Order does not exist."}'}
        if method == "GET" and path == "/fapi/v2/account":
            return {"positions": [{"symbol": "BTCUSDT", "positionAmt": "0.002", "positionSide": "BOTH"}]}
        if method == "POST":
            raise TimeoutError("simulated timeout after request dispatch")
        raise AssertionError("unexpected request")
    monkeypatch.setattr(adapter, "_request", fake_request)
    result = adapter.close_position("BTCUSDT", "SELL", 0.002, idempotency_key="futures-close-timeout")
    assert result["order_status_uncertain"] is True
    assert result["error"] == "order_status_uncertain_blocked"
