import json
from types import SimpleNamespace
import asyncio

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from app import star_app
from app.models.db import Base
from app.models.entities import OrderRecord, SystemState


class _Request:
    def __init__(self, payload=None, query=None):
        self._payload = payload or {}
        self.query_params = query or {}
        self.headers = {}
        self.cookies = {}

    async def body(self):
        return json.dumps(self._payload).encode()


def _setup(tmp_path, monkeypatch):
    engine = create_engine(f"sqlite:///{tmp_path / 'testnet-orders.db'}")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    with Session() as db:
        db.add(SystemState(id=1, emergency_stop=False, status_summary={}))
        db.commit()
    monkeypatch.setattr(star_app, "db_sess", lambda: Session())
    monkeypatch.setattr(star_app, "require_user", lambda request, db: (SimpleNamespace(is_admin=True), None))
    return Session


class _FakeAdapter:
    def __init__(self, result):
        self.result = result
        self.calls = 0
        self.local_orders = None
        self.reconcile_result = {"ok": True, "action": "ok"}

    def place_order(self, **kwargs):
        self.calls += 1
        return self.result

    def close_position(self, **kwargs):
        self.calls += 1
        return self.result

    def reconcile(self, local_open_orders=None):
        self.local_orders = local_open_orders
        return dict(self.reconcile_result)


def _response(response):
    return json.loads(response.body.decode())


def test_testnet_order_is_persisted_and_duplicate_key_does_not_create_second_row(tmp_path, monkeypatch):
    Session = _setup(tmp_path, monkeypatch)
    adapter = _FakeAdapter({"ok": True, "sent_to_exchange": True,
        "response": {"orderId": 123, "clientOrderId": "persist-order-0001", "status": "NEW", "executedQty": "0"}})
    monkeypatch.setattr(star_app, "_get_binance_adapter", lambda market=None: adapter)
    payload = {"market": "spot", "symbol": "BTCUSDT", "side": "BUY", "order_type": "LIMIT",
               "quantity": 0.001, "price": 50000, "idempotency_key": "persist-order-0001"}
    first = _response(asyncio.run(star_app.binance_testnet_order(_Request(payload))))
    assert first["ok"] is True and first["local_status"] == "submitted"
    with Session() as db:
        rows = db.execute(select(OrderRecord)).scalars().all()
        assert len(rows) == 1 and rows[0].shadow is False
        assert rows[0].exchange_order_id == "123"
        assert rows[0].client_order_id == "persist-order-0001"
    adapter.result = {"ok": True, "duplicate": True, "sent_to_exchange": False,
        "response": {"orderId": 123, "clientOrderId": "persist-order-0001", "status": "NEW"}}
    second = _response(asyncio.run(star_app.binance_testnet_order(_Request(payload))))
    assert second["duplicate"] is True
    with Session() as db:
        assert len(db.execute(select(OrderRecord)).scalars().all()) == 1
    assert adapter.calls == 2


def test_uncertain_testnet_order_blocks_different_new_orders(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    adapter = _FakeAdapter({"ok": False, "sent_to_exchange": False,
        "order_status_uncertain": True, "error": "order_status_uncertain_blocked"})
    monkeypatch.setattr(star_app, "_get_binance_adapter", lambda market=None: adapter)
    first_payload = {"market": "spot", "symbol": "BTCUSDT", "side": "BUY", "order_type": "LIMIT",
        "quantity": 0.001, "price": 50000, "idempotency_key": "uncertain-order-0001"}
    first = _response(asyncio.run(star_app.binance_testnet_order(_Request(first_payload))))
    assert first["local_status"] == "uncertain"
    second_payload = {**first_payload, "idempotency_key": "different-order-0002"}
    second = _response(asyncio.run(star_app.binance_testnet_order(_Request(second_payload))))
    assert second["error"] == "unresolved_testnet_order_status"
    assert second["new_orders_blocked"] is True
    assert adapter.calls == 1


def test_reconciliation_uses_persisted_local_orders_and_clears_block_on_success(tmp_path, monkeypatch):
    Session = _setup(tmp_path, monkeypatch)
    with Session() as db:
        state = db.get(SystemState, 1)
        state.status_summary = {"binance_testnet_reconciliation_blocked": True}
        db.add(OrderRecord(environment_mode="demo", market_type="futures", symbol="BTCUSDT", side="buy",
            order_type="market", quantity=0.001, status="submitted", shadow=False,
            idempotency_key="reconcile-order-0001", client_order_id="reconcile-order-0001"))
        db.commit()
    adapter = _FakeAdapter({})
    monkeypatch.setattr(star_app, "_get_binance_adapter", lambda market=None: adapter)
    response = _response(asyncio.run(star_app.binance_testnet_reconcile(_Request(query={"market": "futures"}))))
    assert response["ok"] is True
    assert adapter.local_orders == [{"id": "reconcile-order-0001", "clientOrderId": "reconcile-order-0001",
                                     "orderId": None, "symbol": "BTCUSDT"}]
    with Session() as db:
        assert "binance_testnet_reconciliation_blocked" not in (db.get(SystemState, 1).status_summary or {})


def test_reconciliation_mismatch_blocks_future_testnet_orders(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    adapter = _FakeAdapter({})
    adapter.reconcile_result = {"ok": False, "action": "review_required_halt_new_orders"}
    monkeypatch.setattr(star_app, "_get_binance_adapter", lambda market=None: adapter)
    response = _response(asyncio.run(star_app.binance_testnet_reconcile(_Request(query={"market": "spot"}))))
    assert response["new_orders_blocked"] is True
    blocked = star_app._binance_emergency_stop_error()
    assert blocked.status_code == 423
    assert _response(blocked)["error"] == "testnet_reconciliation_required"


def test_idempotency_key_cannot_be_reused_with_different_order_parameters(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    adapter = _FakeAdapter({"ok": True, "sent_to_exchange": True,
        "response": {"orderId": 321, "clientOrderId": "fixed-order-0001", "status": "NEW"}})
    monkeypatch.setattr(star_app, "_get_binance_adapter", lambda market=None: adapter)
    payload = {"market": "spot", "symbol": "BTCUSDT", "side": "BUY", "order_type": "LIMIT",
        "quantity": 0.001, "price": 50000, "idempotency_key": "fixed-order-0001"}
    assert _response(asyncio.run(star_app.binance_testnet_order(_Request(payload))))["ok"] is True
    changed = {**payload, "quantity": 0.002}
    second = _response(asyncio.run(star_app.binance_testnet_order(_Request(changed))))
    assert second["error"] == "idempotency_key_reused_for_different_order"
    assert adapter.calls == 1


def test_shadow_order_idempotency_key_cannot_be_reused_for_testnet(tmp_path, monkeypatch):
    Session = _setup(tmp_path, monkeypatch)
    with Session() as db:
        db.add(OrderRecord(environment_mode="demo", market_type="spot", symbol="BTCUSDT", side="buy",
            order_type="limit", quantity=0.001, status="filled", shadow=True,
            idempotency_key="shadow-key-reuse-01"))
        db.commit()
    adapter = _FakeAdapter({"ok": True, "sent_to_exchange": True, "response": {"orderId": 999, "status": "NEW"}})
    monkeypatch.setattr(star_app, "_get_binance_adapter", lambda market=None: adapter)
    payload = {"market": "spot", "symbol": "BTCUSDT", "side": "BUY", "order_type": "LIMIT",
        "quantity": 0.001, "price": 50000, "idempotency_key": "shadow-key-reuse-01"}
    response = _response(asyncio.run(star_app.binance_testnet_order(_Request(payload))))
    assert response["error"] == "idempotency_key_reused_for_non_testnet_order"
    assert adapter.calls == 0


def test_testnet_close_uses_reduce_only_adapter_and_persists_same_order_ledger(tmp_path, monkeypatch):
    Session = _setup(tmp_path, monkeypatch)
    adapter = _FakeAdapter({"ok": True, "sent_to_exchange": True, "reduce_only_close": True,
        "response": {"orderId": 777, "clientOrderId": "reduce-close-0001", "status": "NEW"}})
    monkeypatch.setattr(star_app, "_get_binance_adapter", lambda market=None: adapter)
    payload = {"market": "futures", "symbol": "BTCUSDT", "side": "SELL", "quantity": 0.001,
               "idempotency_key": "reduce-close-0001"}
    response = _response(asyncio.run(star_app.binance_testnet_close(_Request(payload))))
    assert response["ok"] is True
    assert response["local_status"] == "submitted"
    with Session() as db:
        row = db.execute(select(OrderRecord)).scalar_one()
        assert row.shadow is False
        assert row.metadata_json["reduce_only"] is True
        assert row.exchange_order_id == "777"
    assert adapter.calls == 1
