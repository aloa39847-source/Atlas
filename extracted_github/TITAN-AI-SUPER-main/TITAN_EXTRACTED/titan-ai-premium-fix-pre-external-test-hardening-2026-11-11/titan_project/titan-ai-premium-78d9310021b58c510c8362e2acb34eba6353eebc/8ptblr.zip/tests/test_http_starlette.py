from __future__ import annotations

import os
import socket
import subprocess
import sys
import time

import httpx

from app.core.config import settings
from app.models import db as dbmod
from app.services import auth_service
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker


def _setup_test_db(db_path):
    settings.database_url = f"sqlite:///{db_path}"
    dbmod.engine.dispose()
    dbmod.engine = create_engine(settings.database_url, connect_args={"check_same_thread": False}, future=True)
    dbmod.SessionLocal = sessionmaker(bind=dbmod.engine, autoflush=False, autocommit=False, future=True)
    dbmod.Base.metadata.create_all(bind=dbmod.engine)


def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def test_http_endpoints_real_server(tmp_path, monkeypatch):
    from pathlib import Path
    db_path = tmp_path / "http.db"
    port = _free_port()
    backend_dir = str(Path(__file__).resolve().parents[1])
    env = os.environ.copy()
    env.update({
        "TITAN_DATABASE_URL": f"sqlite:///{db_path}",
        "TITAN_AUTH_REQUIRED": "false",
        "TITAN_ALLOWED_EMAILS": "abdoavm02@gmail.com",
        "TITAN_LIVE_TRADING_ENABLED": "false",
        "PYTHONPATH": backend_dir,
    })
    proc = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", str(port), "--log-level", "warning"],
        cwd=backend_dir, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
    )
    base = f"http://127.0.0.1:{port}"
    try:
        # wait for server
        ready = False
        for _ in range(60):
            try:
                r = httpx.get(f"{base}/api/health", timeout=1.0)
                if r.status_code == 200:
                    ready = True; break
            except Exception:
                time.sleep(0.25)
        if not ready:
            out = ""
            try: out = proc.stdout.read() if proc.stdout else ""
            except Exception: pass
            raise AssertionError(f"Server did not start. Output: {out[-2000:]}")
        with httpx.Client(base_url=base, timeout=10.0) as c:
            r = c.get("/api/health")
            assert r.status_code == 200 and r.json()["ok"] is True
            r = c.get("/api/system/status")
            assert r.status_code == 200
            j = r.json()
            assert j["state"]["environment_mode"] == "demo"
            assert any(e["key"] == "compliance_policy" for e in j["engines"])
            r = c.post("/api/analysis/decision", json={"symbol": "BTC/USDT", "market_type": "spot", "environment_mode": "demo"})
            assert r.status_code == 200
            a = r.json()
            assert a["action"] in {"buy","sell","long","short","wait"} and a["recorded"] is True
            assert "synthetic_labeled" in str(a["data_sources"])
            r = c.post("/api/master/start", json={"account_target": "demo"})
            assert r.status_code == 400
            assert "knowledge foundation is incomplete" in r.json().get("detail", "")
            r = c.post("/api/master/stop", json={"reason": "test"})
            assert r.status_code == 200 and r.json()["state"]["bot_run_state"] == "stopped"
            r = c.post("/api/compliance/check-order", json={"symbol": "BTC/USDT", "market_type": "spot", "environment_mode": "demo"})
            assert r.status_code == 200 and "gateway" in r.json()
            r = c.get("/api/knowledge/concepts", params={"q": "BOS"})
            assert r.status_code == 200 and len(r.json()["items"]) >= 1
            r = c.post("/api/chat", json={"message": "ما حالة النظام؟"})
            assert r.status_code == 200 and r.json()["grounded"] is True
    finally:
        proc.terminate()
        try: proc.wait(timeout=5)
        except Exception: proc.kill()
        try:
            if proc.stdout: proc.stdout.close()
        except Exception:
            pass
