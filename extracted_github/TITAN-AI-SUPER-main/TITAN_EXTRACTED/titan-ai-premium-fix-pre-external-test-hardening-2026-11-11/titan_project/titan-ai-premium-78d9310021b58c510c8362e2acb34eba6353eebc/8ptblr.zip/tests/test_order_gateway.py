from app.core.enums import MarketType
from app.engines.order_gateway import PreTradeOrderGateway


def test_spot_valid_order_passes_precheck():
    g = PreTradeOrderGateway()
    r = g.validate(symbol="BTC/USDT", market=MarketType.SPOT, side="buy", order_type="limit", quantity=0.001, price=50000, reference_price=50050)
    assert r.ok is True
    assert r.normalized["exchange_filters_checked"] is False


def test_earn_rejected():
    g = PreTradeOrderGateway()
    r = g.validate(symbol="BTC/USDT", market=MarketType.EARN, side="buy", order_type="market", quantity=1)
    assert r.ok is False and r.reason == "earn_not_order_execution"


def test_price_deviation_rejected():
    g = PreTradeOrderGateway()
    r = g.validate(symbol="BTC/USDT", market=MarketType.SPOT, side="buy", order_type="limit", quantity=1, price=100, reference_price=50000)
    assert r.ok is False
