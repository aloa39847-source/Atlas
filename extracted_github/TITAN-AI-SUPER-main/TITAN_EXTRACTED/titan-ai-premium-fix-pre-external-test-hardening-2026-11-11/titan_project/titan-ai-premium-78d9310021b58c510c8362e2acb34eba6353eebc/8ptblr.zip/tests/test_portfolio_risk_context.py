from app.core.enums import EnvironmentMode, MarketType, Timeframe
from app.engines.decision import DecisionEngine
from app.engines.technical import TimeframeAnalysis


def _analyses():
    return {
        tf: TimeframeAnalysis(tf, "bullish", [], {"close": 100.0, "atr14": 1.0}, {}, {})
        for tf in (Timeframe.D1, Timeframe.H4, Timeframe.H1, Timeframe.M15, Timeframe.M5)
    }


def _decide(context):
    return DecisionEngine().decide(
        symbol="BTC/USDT", market=MarketType.SPOT, environment=EnvironmentMode.DEMO,
        timeframe_analyses=_analyses(), risk_context=context,
    )


def test_decision_blocks_when_max_open_positions_reached():
    result = _decide({"open_positions": 5, "max_open_positions": 5})
    assert result["action"] == "wait"
    assert "max_open_positions_reached" in result["reason"]


def test_decision_blocks_when_daily_loss_limit_reached():
    result = _decide({"daily_loss_used": 50, "max_daily_loss": 0.05})
    assert result["action"] == "wait"
    assert "daily_loss_limit_reached" in result["reason"]


def test_decision_blocks_when_portfolio_exposure_would_be_exceeded():
    result = _decide({"current_exposure": 2000, "max_exposure": 2000})
    assert result["action"] == "wait"
    assert "max_exposure_exceeded" in result["reason"]


def test_decision_allows_when_portfolio_risk_context_is_within_limits():
    result = _decide({"daily_loss_used": 0, "max_daily_loss": 0.05,
                      "open_positions": 0, "max_open_positions": 5,
                      "current_exposure": 0, "max_exposure": 2000})
    assert result["action"] == "buy"
    assert result["risk"]["ok"] is True
