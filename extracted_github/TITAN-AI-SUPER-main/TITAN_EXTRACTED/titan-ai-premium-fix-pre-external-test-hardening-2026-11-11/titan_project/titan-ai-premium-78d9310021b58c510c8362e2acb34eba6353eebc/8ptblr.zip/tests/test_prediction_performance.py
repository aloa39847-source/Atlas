from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from app.models.db import Base
from app.models.entities import PredictionRecord, PositionRecord
from app.services.performance import PredictionTrackingService, PerformanceEvaluationService


def _session(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'prediction-performance.db'}")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine, autoflush=False, autocommit=False)()


def test_prediction_record_resolve_and_manual_verification(tmp_path):
    db = _session(tmp_path)
    try:
        service = PredictionTrackingService()
        row = service.record_decision(
            db, decision_id=7, symbol="BTC/USDT", environment_mode="demo", market_type="spot",
            action="buy", confidence=0.82, reference_price=50000, horizon="5m",
            strategy="trend_following", data_source="synthetic_labeled",
        )
        db.commit()
        assert row is not None and row.predicted_direction == "bullish" and row.verified is False
        result = service.resolve(db, prediction_id=row.id, observed_price=50100, outcome_source="paper candle close")
        db.commit()
        assert result["ok"] is True and result["correct"] is True
        assert row.outcome["price_change_pct"] > 0 and row.verified is False
        assert service.resolve(db, prediction_id=row.id, observed_price=50200, outcome_source="duplicate")["error"] == "prediction_already_resolved"
        verified = service.verify(db, prediction_id=row.id, verification_notes="Reviewed against an independent archived candle source.")
        db.commit()
        assert verified["ok"] is True and row.verified is True
    finally:
        db.close()


def test_prediction_rejects_invalid_reference_and_observed_prices(tmp_path):
    db = _session(tmp_path)
    try:
        service = PredictionTrackingService()
        assert service.record_decision(
            db, decision_id=1, symbol="BTC/USDT", environment_mode="demo", market_type="spot",
            action="buy", confidence=0.7, reference_price=0,
        ) is None
        row = service.record_decision(
            db, decision_id=2, symbol="BTC/USDT", environment_mode="demo", market_type="spot",
            action="buy", confidence=0.7, reference_price=100,
        )
        db.commit()
        result = service.resolve(db, prediction_id=row.id, observed_price=float("nan"), outcome_source="source")
        assert result["ok"] is False and result["error"] == "valid_observed_and_reference_prices_required"
        assert row.resolved_at is None
    finally:
        db.close()


def test_performance_summary_uses_only_verified_predictions_and_shadow_positions(tmp_path):
    db = _session(tmp_path)
    try:
        service = PredictionTrackingService()
        verified = service.record_decision(
            db, decision_id=1, symbol="BTC/USDT", environment_mode="demo", market_type="spot",
            action="buy", confidence=0.8, reference_price=100,
        )
        unverified = service.record_decision(
            db, decision_id=2, symbol="BTC/USDT", environment_mode="demo", market_type="spot",
            action="sell", confidence=0.7, reference_price=100,
        )
        db.flush()
        service.resolve(db, prediction_id=verified.id, observed_price=105, outcome_source="archived candle")
        service.verify(db, prediction_id=verified.id, verification_notes="Cross-checked with two independent candle records.")
        service.resolve(db, prediction_id=unverified.id, observed_price=95, outcome_source="unreviewed source")
        db.add(PositionRecord(environment_mode="demo", market_type="spot", symbol="BTC/USDT", side="long_spot",
                              quantity=0, entry_avg_price=100, mark_price=105, realized_pnl=10,
                              fees_total=1, status="closed", shadow=True))
        db.add(PositionRecord(environment_mode="demo", market_type="spot", symbol="BTC/USDT", side="long_spot",
                              quantity=0, entry_avg_price=100, mark_price=105, realized_pnl=999,
                              fees_total=0, status="closed", shadow=False))
        db.commit()
        result = PerformanceEvaluationService().summary(db, environment_mode="demo", market_type="spot")
        assert result["predictions"]["total"] == 2
        assert result["predictions"]["resolved"] == 2
        assert result["predictions"]["verified"] == 1
        assert result["predictions"]["directional_accuracy"] == 1.0
        assert result["closed_positions"]["count"] == 1
        assert result["closed_positions"]["net_pnl_after_fees"] == 9.0
        assert result["closed_positions"]["scope"] == "closed_shadow_positions_only"
    finally:
        db.close()


def test_non_directional_wait_decisions_do_not_create_predictions(tmp_path):
    db = _session(tmp_path)
    try:
        service = PredictionTrackingService()
        result = service.record_decision(
            db, decision_id=1, symbol="BTC/USDT", environment_mode="demo", market_type="spot",
            action="wait", confidence=0.9, reference_price=100,
        )
        assert result is None
        assert db.execute(select(PredictionRecord)).scalars().all() == []
    finally:
        db.close()
