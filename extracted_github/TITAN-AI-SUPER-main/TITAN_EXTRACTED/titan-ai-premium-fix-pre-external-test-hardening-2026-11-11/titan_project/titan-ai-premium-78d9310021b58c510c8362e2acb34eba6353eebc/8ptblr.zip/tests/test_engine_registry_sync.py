from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models.db import Base
from app.models.entities import EngineState
from app.services.core_service import TitanCoreService


def test_bootstrap_syncs_changed_implementation_status_without_overwriting_runtime_state(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'engine-registry.db'}")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    with Session() as db:
        db.add_all([
            EngineState(engine_key="portfolio_management", name="Portfolio Management Engine",
                        status="not_implemented", message="Old registry status"),
            EngineState(engine_key="technical_analysis", name="Technical Analysis Engine",
                        status="running", message="Started by operator"),
            EngineState(engine_key="fundamental_analysis", name="Fundamental Analysis Engine",
                        status="not_implemented", message="No provider"),
        ])
        db.commit()
        TitanCoreService().ensure_bootstrap(db)
        portfolio = db.query(EngineState).filter_by(engine_key="portfolio_management").one()
        technical = db.query(EngineState).filter_by(engine_key="technical_analysis").one()
        fundamental = db.query(EngineState).filter_by(engine_key="fundamental_analysis").one()
        assert portfolio.status == "implemented_partial"
        assert "synchronized" in portfolio.message
        assert technical.status == "running"
        assert technical.message == "Started by operator"
        assert fundamental.status == "not_implemented"
