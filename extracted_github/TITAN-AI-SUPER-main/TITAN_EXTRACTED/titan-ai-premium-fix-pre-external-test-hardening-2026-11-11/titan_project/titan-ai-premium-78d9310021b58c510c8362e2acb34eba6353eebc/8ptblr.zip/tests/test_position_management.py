from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models.db import Base
from app.models.entities import PositionRecord
from app.services.position_management import PositionManagementService


def _db(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'position-management.db'}")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine, autoflush=False, autocommit=False)()


def _position(db, *, side="long_spot", shadow=True, entry=100.0):
    row = PositionRecord(
        environment_mode="demo", market_type="spot", symbol="BTC/USDT", side=side,
        quantity=1.0, entry_avg_price=entry, mark_price=entry,
        status="open", shadow=shadow, metadata_json={},
    )
    db.add(row)
    db.flush()
    return row


def test_configure_long_position_protection_and_trigger_stop_loss(tmp_path):
    db = _db(tmp_path)
    try:
        row = _position(db)
        service = PositionManagementService()
        configured = service.configure_protection(db, position_id=row.id, stop_loss=95, take_profit=110)
        db.commit()
        assert configured["ok"] is True
        signals = service.evaluate_prices(db, prices={"BTC/USDT": 94})
        db.commit()
        assert len(signals) == 1
        assert signals[0]["reason"] == "stop_loss"
        assert signals[0]["order_submitted"] is False
        assert service.evaluate_prices(db, prices={"BTC/USDT": 93}) == []
    finally:
        db.close()


def test_short_position_trailing_stop_moves_down_and_triggers_on_rebound(tmp_path):
    db = _db(tmp_path)
    try:
        row = _position(db, side="short", entry=100)
        service = PositionManagementService()
        assert service.configure_protection(db, position_id=row.id, trailing_stop_pct=0.05)["ok"] is True
        assert service.evaluate_prices(db, prices={"BTC/USDT": 90}) == []
        signals = service.evaluate_prices(db, prices={"BTC/USDT": 95})
        assert len(signals) == 1
        assert signals[0]["reason"] == "trailing_stop"
    finally:
        db.close()


def test_rejects_invalid_stop_target_direction_and_real_positions(tmp_path):
    db = _db(tmp_path)
    try:
        service = PositionManagementService()
        long = _position(db)
        assert service.configure_protection(db, position_id=long.id, stop_loss=101)["error"] == "long_stop_loss_must_be_below_entry"
        assert service.configure_protection(db, position_id=long.id, take_profit=99)["error"] == "long_take_profit_must_be_above_entry"
        real = _position(db, shadow=False)
        assert service.configure_protection(db, position_id=real.id, stop_loss=95)["error"] == "only_shadow_positions_supported"
    finally:
        db.close()


def test_protection_requires_at_least_one_rule_and_bounds_trailing_pct(tmp_path):
    db = _db(tmp_path)
    try:
        row = _position(db)
        service = PositionManagementService()
        assert service.configure_protection(db, position_id=row.id)["error"] == "at_least_one_protection_rule_required"
        assert service.configure_protection(db, position_id=row.id, trailing_stop_pct=0.8)["error"] == "trailing_stop_pct_out_of_range"
    finally:
        db.close()
