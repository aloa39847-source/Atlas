from app.integrations.binance_adapter import BinanceConfig, BinanceTestnetAdapter


def _adapter(monkeypatch, dual_side):
    monkeypatch.setenv("TITAN_FUTURES_KEY", "test-key")
    monkeypatch.setenv("TITAN_FUTURES_SECRET", "test-secret")
    adapter = BinanceTestnetAdapter(BinanceConfig(
        enabled=True, environment="testnet", market="futures",
        api_key_ref="env:TITAN_FUTURES_KEY", api_secret_ref="env:TITAN_FUTURES_SECRET"))
    monkeypatch.setattr(adapter, "get_order_by_client_id",
                        lambda symbol, client_id: {"found": False, "confirmed_absent": True})
    monkeypatch.setattr(adapter, "get_exchange_info", lambda symbol: {"symbols": [{
        "symbol": symbol.replace("/", "").upper(), "status": "TRADING", "filters": [
            {"filterType": "PRICE_FILTER", "tickSize": "0.1"},
            {"filterType": "LOT_SIZE", "stepSize": "0.001"},
            {"filterType": "MARKET_LOT_SIZE", "stepSize": "0.001"},
            {"filterType": "MIN_NOTIONAL", "notional": "5"},
        ]}]})
    monkeypatch.setattr(adapter, "get_position_mode", lambda: {"dualSidePosition": dual_side})
    monkeypatch.setattr(adapter.public_data, "get_ticker_price", lambda symbol, market: 50000.0)
    return adapter


def test_futures_one_way_mode_maps_long_short_to_exchange_buy_sell(monkeypatch):
    adapter = _adapter(monkeypatch, False)
    posts = []
    monkeypatch.setattr(adapter, "_request", lambda method, path, signed=False, params=None:
                        posts.append(params) or {"orderId": 10} if method == "POST" else {"ok": True})
    result = adapter.place_order("BTCUSDT", "LONG", "LIMIT", 0.001, price=50000,
                                 idempotency_key="futures-oneway-001")
    assert result["ok"] is True
    assert posts[0]["side"] == "BUY"
    assert "positionSide" not in posts[0]


def test_futures_hedge_mode_sets_exchange_side_and_position_side(monkeypatch):
    adapter = _adapter(monkeypatch, True)
    posts = []
    monkeypatch.setattr(adapter, "_request", lambda method, path, signed=False, params=None:
                        posts.append(params) or {"orderId": 11} if method == "POST" else {"ok": True})
    result = adapter.place_order("BTCUSDT", "SHORT", "LIMIT", 0.001, price=50000,
                                 idempotency_key="futures-hedge-001")
    assert result["ok"] is True
    assert posts[0]["side"] == "SELL"
    assert posts[0]["positionSide"] == "SHORT"


def test_futures_hedge_mode_rejects_ambiguous_buy_sell_intent(monkeypatch):
    adapter = _adapter(monkeypatch, True)
    sent = []
    monkeypatch.setattr(adapter, "_request", lambda *a, **k: sent.append((a, k)) or {"orderId": 12})
    result = adapter.place_order("BTCUSDT", "BUY", "LIMIT", 0.001, price=50000,
                                 idempotency_key="futures-hedge-002")
    assert result["sent_to_exchange"] is False
    assert result["error"] == "hedge_mode_requires_explicit_long_or_short"
    assert sent == []


def test_futures_order_blocks_when_position_mode_cannot_be_verified(monkeypatch):
    adapter = _adapter(monkeypatch, False)
    monkeypatch.setattr(adapter, "get_position_mode", lambda: {"error": "futures_position_mode_unavailable"})
    sent = []
    monkeypatch.setattr(adapter, "_request", lambda *a, **k: sent.append((a, k)) or {"orderId": 13})
    result = adapter.place_order("BTCUSDT", "BUY", "LIMIT", 0.001, price=50000,
                                 idempotency_key="futures-mode-unknown")
    assert result["sent_to_exchange"] is False
    assert result["error"] == "futures_position_mode_unavailable"
    assert sent == []
