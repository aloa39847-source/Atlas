from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models.db import Base
from app.models.entities import SystemState, OrderRecord
from app.services.core_service import core_service
from app.services.orchestrator import TradingOrchestrator


def _db(tmp_path, emergency_stop=False):
    engine = create_engine(f"sqlite:///{tmp_path / 'orchestrator.db'}")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    db = Session()
    db.add(SystemState(id=1, emergency_stop=emergency_stop))
    db.commit()
    return db


def _analysis(action="buy", price=50000.0, decision_id=11):
    return {"action": action, "entry_price": price, "decision_id": decision_id}


def test_orchestrator_reports_shadow_fill_only_after_real_fill(monkeypatch, tmp_path):
    db = _db(tmp_path)
    monkeypatch.setattr(core_service.market_data, "get_multi_timeframe", lambda *a, **k: {})
    monkeypatch.setattr(core_service, "analyze", lambda *a, **k: _analysis())
    try:
        result = TradingOrchestrator().run_cycle(db, symbol="BTC/USDT", market="spot", environment="demo", execute_testnet=True)
        assert result["executed"] is True
        assert result["execution_mode"] == "shadow_simulation"
        assert result["execution_result"]["status"] == "filled"
        order = db.query(OrderRecord).one()
        assert order.quantity * order.avg_fill_price <= 80.0
        assert order.idempotency_key == "cycle-11"
    finally:
        db.close()


def test_orchestrator_does_not_claim_execution_when_emergency_stop_blocks(monkeypatch, tmp_path):
    db = _db(tmp_path, emergency_stop=True)
    monkeypatch.setattr(core_service.market_data, "get_multi_timeframe", lambda *a, **k: {})
    monkeypatch.setattr(core_service, "analyze", lambda *a, **k: _analysis())
    try:
        result = TradingOrchestrator().run_cycle(db, symbol="BTC/USDT", market="spot", environment="demo", execute_testnet=True)
        assert result["executed"] is False
        assert result["execution_mode"] == "blocked"
        assert db.query(OrderRecord).count() == 0
    finally:
        db.close()


def test_orchestrator_blocks_spot_sell_without_inventory_sync(monkeypatch, tmp_path):
    db = _db(tmp_path)
    monkeypatch.setattr(core_service.market_data, "get_multi_timeframe", lambda *a, **k: {})
    monkeypatch.setattr(core_service, "analyze", lambda *a, **k: _analysis(action="sell"))
    try:
        result = TradingOrchestrator().run_cycle(db, symbol="BTC/USDT", market="spot", environment="demo", execute_testnet=True)
        assert result["executed"] is False
        assert result["execution_mode"] == "blocked_spot_sell_requires_inventory_sync"
        assert db.query(OrderRecord).count() == 0
    finally:
        db.close()


def test_orchestrator_blocks_missing_reference_price(monkeypatch, tmp_path):
    db = _db(tmp_path)
    monkeypatch.setattr(core_service.market_data, "get_multi_timeframe", lambda *a, **k: {})
    monkeypatch.setattr(core_service, "analyze", lambda *a, **k: _analysis(price=None))
    try:
        result = TradingOrchestrator().run_cycle(db, symbol="BTC/USDT", market="spot", environment="demo", execute_testnet=True)
        assert result["executed"] is False
        assert result["execution_mode"] == "blocked_missing_reference_price_or_decision_id"
        assert db.query(OrderRecord).count() == 0
    finally:
        db.close()
