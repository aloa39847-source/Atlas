import json

from app.engines.hybrid.coordinator import HybridIntelligenceCoordinator
from app.engines.market_data import MarketDataEngine
from app.engines.technical import TimeframeAnalysis


def test_hybrid_analysis_is_json_serializable():
    batches = MarketDataEngine().get_multi_timeframe("BTC/USDT", seed=42)
    analyses = {
        tf: TimeframeAnalysis(
            timeframe=tf, trend="bullish", signals=["higher_high"],
            indicators={"close": 100.0, "rsi14": 55.0},
            structure={"bias": "bullish"}, candles={"pattern": "bullish"},
        )
        for tf in batches
    }
    result = HybridIntelligenceCoordinator().analyze_multi_timeframe(batches, analyses)
    encoded = json.dumps(result)
    assert '"trend": "bullish"' in encoded
    assert result["per_timeframe"]["1d"]["analysis"]["timeframe"] == "1d"
