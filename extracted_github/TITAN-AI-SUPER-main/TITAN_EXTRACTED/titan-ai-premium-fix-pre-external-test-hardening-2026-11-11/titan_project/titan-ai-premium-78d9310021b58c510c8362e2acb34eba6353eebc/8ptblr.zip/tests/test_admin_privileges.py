from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.core.config import settings
from app.models.db import Base
from app.services import auth_service


def _db(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'admin.db'}")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)()


def test_auth_required_without_allowlist_fails_closed(monkeypatch):
    monkeypatch.setattr(settings, "auth_required", True)
    monkeypatch.delenv("TITAN_AUTH_REQUIRED", raising=False)
    monkeypatch.delenv("TITAN_ALLOWED_EMAILS", raising=False)
    assert auth_service.auth_required() is True
    assert auth_service.email_allowed("anyone@example.com") is False


def test_single_allowlisted_owner_is_initial_admin(tmp_path, monkeypatch):
    monkeypatch.setenv("TITAN_AUTH_REQUIRED", "true")
    monkeypatch.setenv("TITAN_ALLOWED_EMAILS", "owner@example.com")
    monkeypatch.delenv("TITAN_ADMIN_EMAILS", raising=False)
    db = _db(tmp_path)
    try:
        user = auth_service.ensure_user(db, "OWNER@example.com")
        assert user.is_admin is True
    finally:
        db.close()


def test_multiple_allowlisted_users_are_not_automatically_admins(tmp_path, monkeypatch):
    monkeypatch.setenv("TITAN_AUTH_REQUIRED", "true")
    monkeypatch.setenv("TITAN_ALLOWED_EMAILS", "owner@example.com,staff@example.com")
    monkeypatch.delenv("TITAN_ADMIN_EMAILS", raising=False)
    db = _db(tmp_path)
    try:
        owner = auth_service.ensure_user(db, "owner@example.com")
        staff = auth_service.ensure_user(db, "staff@example.com")
        assert owner.is_admin is False
        assert staff.is_admin is False
    finally:
        db.close()


def test_explicit_admin_allowlist_grants_only_named_admin(tmp_path, monkeypatch):
    monkeypatch.setenv("TITAN_AUTH_REQUIRED", "true")
    monkeypatch.setenv("TITAN_ALLOWED_EMAILS", "owner@example.com,staff@example.com")
    monkeypatch.setenv("TITAN_ADMIN_EMAILS", "owner@example.com")
    db = _db(tmp_path)
    try:
        owner = auth_service.ensure_user(db, "owner@example.com")
        staff = auth_service.ensure_user(db, "staff@example.com")
        assert owner.is_admin is True
        assert staff.is_admin is False
    finally:
        db.close()


def test_existing_admin_bit_is_demoted_when_email_is_not_admin_allowlisted(tmp_path, monkeypatch):
    from app.models.entities import AppUser
    monkeypatch.setenv("TITAN_AUTH_REQUIRED", "true")
    monkeypatch.setenv("TITAN_ALLOWED_EMAILS", "owner@example.com,staff@example.com")
    monkeypatch.setenv("TITAN_ADMIN_EMAILS", "owner@example.com")
    db = _db(tmp_path)
    try:
        user = AppUser(email="staff@example.com", is_active=True, is_admin=True)
        db.add(user)
        db.commit()
        reconciled = auth_service.ensure_user(db, "staff@example.com")
        assert reconciled.is_admin is False
    finally:
        db.close()
