from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models.db import Base
from app.models.entities import PositionRecord
from app.services.portfolio_management import PortfolioManagementService


def _db(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'portfolio-management.db'}")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine, autoflush=False, autocommit=False)()


def _add(db, *, symbol, market, side, qty, mark, leverage=1, shadow=True, status="open"):
    row = PositionRecord(
        environment_mode="demo", market_type=market, symbol=symbol, side=side,
        quantity=qty, entry_avg_price=mark, mark_price=mark, leverage=leverage,
        unrealized_pnl=2.5, realized_pnl=1.0, fees_total=0.2,
        status=status, shadow=shadow, metadata_json={},
    )
    db.add(row)
    db.flush()
    return row


def test_portfolio_report_groups_spot_and_futures_and_uses_notional_not_margin(tmp_path):
    db = _db(tmp_path)
    try:
        _add(db, symbol="BTC/USDT", market="spot", side="long_spot", qty=0.001, mark=60000)
        _add(db, symbol="ETH/USDT", market="futures", side="short", qty=0.1, mark=3000, leverage=5)
        result = PortfolioManagementService().build_report(db)
        assert result["positions_count"] == 2
        assert result["gross_notional_exposure"] == 360.0
        assert result["net_directional_exposure"] == -240.0
        assert result["by_market"]["spot"]["gross_notional"] == 60.0
        assert result["by_market"]["futures"]["gross_notional"] == 300.0
        assert result["exchange_balance"] is None and result["equity"] is None
    finally:
        db.close()


def test_portfolio_report_flags_existing_spot_and_futures_notional_cap_breaches(tmp_path):
    db = _db(tmp_path)
    try:
        _add(db, symbol="BTC/USDT", market="spot", side="long_spot", qty=0.002, mark=50000)
        _add(db, symbol="ETH/USDT", market="futures", side="long", qty=0.3, mark=3000, leverage=2)
        result = PortfolioManagementService().build_report(db)
        rules = {item["rule"] for item in result["risk_limit_violations"]}
        assert "spot_position_notional_cap_80_usdt" in rules
        assert "futures_position_notional_cap_800_usdt" in rules
    finally:
        db.close()


def test_portfolio_report_excludes_real_positions_and_filters_market(tmp_path):
    db = _db(tmp_path)
    try:
        _add(db, symbol="BTC/USDT", market="spot", side="long_spot", qty=0.001, mark=50000)
        _add(db, symbol="ETH/USDT", market="futures", side="long", qty=0.1, mark=3000)
        _add(db, symbol="XRP/USDT", market="spot", side="long_spot", qty=1, mark=1, shadow=False)
        result = PortfolioManagementService().build_report(db, market_type="futures")
        assert result["positions_count"] == 1
        assert result["positions"][0]["symbol"] == "ETH/USDT"
        assert result["scope"] == "persisted_shadow_positions_only"
    finally:
        db.close()


def test_closed_positions_are_excluded_unless_requested(tmp_path):
    db = _db(tmp_path)
    try:
        _add(db, symbol="BTC/USDT", market="spot", side="long_spot", qty=0.001, mark=50000, status="closed")
        service = PortfolioManagementService()
        assert service.build_report(db)["positions_count"] == 0
        assert service.build_report(db, include_closed=True)["positions_count"] == 1
    finally:
        db.close()
