from app.integrations.binance_adapter import BinanceConfig, BinanceTestnetAdapter


def _adapter(monkeypatch, market="spot", response=None):
    monkeypatch.setenv("TITAN_STATUS_KEY", "test-key")
    monkeypatch.setenv("TITAN_STATUS_SECRET", "test-secret")
    adapter = BinanceTestnetAdapter(BinanceConfig(
        enabled=True, environment="testnet", market=market,
        api_key_ref="env:TITAN_STATUS_KEY", api_secret_ref="env:TITAN_STATUS_SECRET"))
    monkeypatch.setattr(adapter, "_request", lambda *a, **k: response)
    return adapter


def test_spot_status_requires_expected_account_shape(monkeypatch):
    adapter = _adapter(monkeypatch, response={"balances": [], "canTrade": True})
    result = adapter.status()
    assert result["connected"] is True
    assert result["account_check"] == "ok"
    assert result["trading_allowed"] is True


def test_negative_api_code_is_not_reported_as_connected(monkeypatch):
    adapter = _adapter(monkeypatch, response={"code": -2015, "msg": "Invalid API-key"})
    result = adapter.status()
    assert result["connected"] is False
    assert result["account_check"] == "invalid_or_error_account_payload"
    assert result["trading_allowed"] is None


def test_futures_status_requires_assets_and_positions(monkeypatch):
    adapter = _adapter(monkeypatch, market="futures", response={"positions": [], "canTrade": True})
    result = adapter.status()
    assert result["connected"] is False
    assert result["account_check"] == "invalid_or_error_account_payload"


def test_connected_account_can_be_read_only_without_trade_permission(monkeypatch):
    adapter = _adapter(monkeypatch, response={"balances": [], "canTrade": False})
    result = adapter.status()
    assert result["connected"] is True
    assert result["trading_allowed"] is False


def test_adapter_does_not_claim_api_key_withdrawals_are_disabled(monkeypatch):
    adapter = _adapter(monkeypatch, response={"balances": [], "canTrade": True})
    result = adapter.status()
    assert result["withdrawal_permissions"] is None
    assert result["withdrawal_permission_status"] == "unknown_not_checked"
    assert result["withdrawal_operations_supported"] is False
