from app.core.enums import MarketType
from app.engines.order_gateway import PreTradeOrderGateway
from app.integrations.binance_adapter import BinanceConfig, BinanceTestnetAdapter


def test_spot_hard_cap_is_80_usdt_even_if_caller_requests_more():
    g = PreTradeOrderGateway()
    r = g.validate(symbol="BTC/USDT", market=MarketType.SPOT, side="buy",
                   order_type="market", quantity=0.002, reference_price=50000,
                   max_notional=100000)
    assert not r.ok
    assert r.reason == "notional_exceeds_limit"
    assert r.normalized["max_notional"] == 80.0


def test_spot_order_at_80_usdt_passes_hard_cap():
    g = PreTradeOrderGateway()
    r = g.validate(symbol="BTC/USDT", market=MarketType.SPOT, side="buy",
                   order_type="market", quantity=0.0016, reference_price=50000)
    assert r.ok
    assert r.normalized["notional_estimate"] == 80.0


def test_futures_hard_cap_is_800_usdt_even_if_caller_requests_more():
    g = PreTradeOrderGateway()
    r = g.validate(symbol="BTC/USDT", market=MarketType.FUTURES, side="long",
                   order_type="market", quantity=0.02, reference_price=50000,
                   max_notional=100000)
    assert not r.ok
    assert r.reason == "notional_exceeds_limit"
    assert r.normalized["max_notional"] == 800.0


def test_notional_cap_requires_reference_price_for_market_order():
    g = PreTradeOrderGateway()
    r = g.validate(symbol="BTC/USDT", market=MarketType.SPOT, side="buy",
                   order_type="market", quantity=0.001)
    assert not r.ok
    assert r.reason == "reference_price_required_for_notional_cap"


def test_disabled_testnet_adapter_never_sends_order():
    adapter = BinanceTestnetAdapter(BinanceConfig(enabled=False))
    r = adapter.place_order("BTC/USDT", "BUY", "MARKET", 0.001, price=50000)
    assert r["ok"] is False
    assert r["sent_to_exchange"] is False
    assert r["error"] == "testnet_adapter_disabled"


def test_emergency_stop_blocks_new_shadow_orders(tmp_path):
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from app.models.db import Base
    from app.models.entities import SystemState, OrderRecord
    from app.services.shadow_trading import ShadowTradingService

    engine = create_engine(f"sqlite:///{tmp_path / 'emergency.db'}")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    with Session() as db:
        db.add(SystemState(id=1, emergency_stop=True))
        db.commit()
        result = ShadowTradingService().create_shadow_order(
            db, env="demo", market="spot", symbol="BTC/USDT", side="buy",
            order_type="limit", quantity=0.001, price=50000,
            reference_price=50000, idempotency_key="emergency-stop-001",
        )
        assert not result.ok
        assert result.message == "emergency_stop_active"
        assert db.query(OrderRecord).count() == 0


def test_binance_auth_helper_propagates_authentication_error(monkeypatch):
    from app import star_app
    expected = object()

    class DummyDB:
        def close(self):
            pass

    monkeypatch.setattr(star_app, "db_sess", lambda: DummyDB())
    monkeypatch.setattr(star_app, "require_user", lambda request, db: (None, expected))
    assert star_app._binance_auth_error(object()) is expected


def test_spot_credentials_are_not_reused_for_futures(monkeypatch):
    from app import star_app
    monkeypatch.setattr(star_app, "load_testnet_credentials",
                        lambda: {"configured": True, "market": "spot", "api_key": "spot-key", "api_secret": "spot-secret"})
    monkeypatch.delenv("BINANCE_FUTURES_TESTNET_API_KEY", raising=False)
    monkeypatch.delenv("BINANCE_FUTURES_TESTNET_API_SECRET", raising=False)
    adapter = star_app._get_binance_adapter("futures")
    assert adapter.config.market == "futures"
    assert adapter.config.enabled is False
    assert adapter._api_key() is None
    assert adapter._api_secret() is None

def test_futures_uses_dedicated_testnet_environment_credentials(monkeypatch):
    from app import star_app
    monkeypatch.setattr(star_app, "load_testnet_credentials", lambda: {"configured": False})
    monkeypatch.setenv("BINANCE_FUTURES_TESTNET_API_KEY", "futures-test-key")
    monkeypatch.setenv("BINANCE_FUTURES_TESTNET_API_SECRET", "futures-test-secret")
    adapter = star_app._get_binance_adapter("futures")
    assert adapter.config.enabled is True
    assert adapter.config.api_key_ref == "env:BINANCE_FUTURES_TESTNET_API_KEY"
    assert adapter.config.api_secret_ref == "env:BINANCE_FUTURES_TESTNET_API_SECRET"


def test_shadow_order_fails_closed_when_system_state_is_missing(tmp_path):
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from app.models.db import Base
    from app.services.shadow_trading import ShadowTradingService
    engine = create_engine(f"sqlite:///{tmp_path / 'missing-state.db'}")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    with Session() as db:
        result = ShadowTradingService().create_shadow_order(
            db, env="demo", market="spot", symbol="BTC/USDT", side="buy",
            order_type="limit", quantity=0.001, price=50000,
            reference_price=50000, idempotency_key="missing-state-001",
        )
        assert not result.ok
        assert result.message == "system_state_unavailable"


def test_binance_emergency_stop_helper_blocks_new_orders(monkeypatch):
    from types import SimpleNamespace
    from app import star_app
    class DummyDB:
        def get(self, model, key):
            return SimpleNamespace(emergency_stop=True)
        def close(self):
            pass
    monkeypatch.setattr(star_app, "db_sess", lambda: DummyDB())
    result = star_app._binance_emergency_stop_error()
    assert result.status_code == 423


def test_decision_waits_when_an_approved_timeframe_is_missing():
    from app.core.enums import EnvironmentMode, MarketType, Timeframe
    from app.engines.decision import DecisionEngine
    from app.engines.technical import TimeframeAnalysis
    analyses = {
        tf: TimeframeAnalysis(tf, "bullish", [], {"close": 100.0, "atr14": 1.0}, {}, {})
        for tf in (Timeframe.D1, Timeframe.H4, Timeframe.H1, Timeframe.M15)
    }
    result = DecisionEngine().decide(
        symbol="BTC/USDT", market=MarketType.SPOT, environment=EnvironmentMode.DEMO,
        timeframe_analyses=analyses,
    )
    assert result["action"] == "wait"
    assert result["reason"] == "missing_required_timeframes"
    assert result["extra"]["missing_timeframes"] == ["5m"]
