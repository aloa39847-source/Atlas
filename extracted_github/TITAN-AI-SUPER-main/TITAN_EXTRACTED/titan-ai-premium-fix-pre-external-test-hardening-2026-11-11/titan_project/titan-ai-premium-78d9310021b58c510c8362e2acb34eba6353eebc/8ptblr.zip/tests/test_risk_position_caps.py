from app.core.enums import EnvironmentMode, MarketType
from app.engines.risk import RiskEngine


def test_spot_risk_sizing_never_exceeds_80_usdt_notional():
    result = RiskEngine().validate_trade(
        environment=EnvironmentMode.DEMO, market=MarketType.SPOT,
        balance=10000, risk_per_trade=0.01, entry=100, stop_loss=99.9,
        leverage=1, max_leverage=10,
    )
    assert result["ok"] is True
    assert result["position_notional_estimate"] <= 80.0
    assert "per_position_notional_capped:80.0" in result["issues"]


def test_futures_risk_sizing_never_exceeds_800_usdt_notional():
    result = RiskEngine().validate_trade(
        environment=EnvironmentMode.DEMO, market=MarketType.FUTURES,
        balance=10000, risk_per_trade=0.01, entry=100, stop_loss=99.9,
        leverage=10, max_leverage=10,
    )
    assert result["ok"] is True
    assert result["position_notional_estimate"] <= 800.0
    assert "per_position_notional_capped:800.0" in result["issues"]


def test_risk_engine_does_not_apply_leverage_to_raise_notional_ceiling():
    result = RiskEngine().validate_trade(
        environment=EnvironmentMode.DEMO, market=MarketType.FUTURES,
        balance=10000, risk_per_trade=0.01, entry=100, stop_loss=99.9,
        leverage=20, max_leverage=20,
    )
    assert result["position_notional_estimate"] <= 800.0


def test_zero_max_leverage_fails_closed_instead_of_falling_back_to_default():
    result = RiskEngine().validate_trade(
        environment=EnvironmentMode.DEMO, market=MarketType.FUTURES,
        balance=1000, risk_per_trade=0.01, entry=100, stop_loss=99,
        leverage=1, max_leverage=0,
    )
    assert result["ok"] is False
    assert "max_leverage_must_be_positive" in result["issues"]


def test_zero_max_risk_per_trade_fails_closed():
    result = RiskEngine().validate_trade(
        environment=EnvironmentMode.DEMO, market=MarketType.SPOT,
        balance=1000, risk_per_trade=0.01, entry=100, stop_loss=99,
        leverage=1, max_leverage=1, max_risk_per_trade=0,
    )
    assert result["ok"] is False
    assert "max_risk_per_trade_must_be_positive" in result["issues"]


def test_zero_requested_risk_per_trade_fails_closed():
    result = RiskEngine().validate_trade(
        environment=EnvironmentMode.DEMO, market=MarketType.SPOT,
        balance=1000, risk_per_trade=0, entry=100, stop_loss=99,
        leverage=1, max_leverage=1,
    )
    assert result["ok"] is False
    assert "risk_per_trade_must_be_positive" in result["issues"]
