from types import SimpleNamespace
import pytest
from fastapi import HTTPException
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models.db import Base
from app.models.entities import KnowledgeSource
from app.api.routes import KnowledgeCreate, KnowledgeVerify, KnowledgeConceptCreate, add_knowledge, verify_knowledge_source, add_knowledge_concept
from app.knowledge.base import coverage_report


def _db(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'knowledge.db'}")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)()


def test_knowledge_foundation_starts_incomplete_and_reports_gaps(tmp_path):
    db = _db(tmp_path)
    try:
        report = coverage_report(db)
        assert report["foundation_ready"] is False
        assert report["coverage_percent"] == 0.0
        assert report["required_domains"] >= 30
        assert len(report["missing_domains"]) == report["required_domains"]
    finally:
        db.close()


def test_user_cannot_mark_a_new_knowledge_source_verified(tmp_path):
    db = _db(tmp_path)
    try:
        result = add_knowledge(
            KnowledgeCreate(title="Official exchange documentation", source_type="official",
                            url="https://example.org/docs", reliability_score=1.0,
                            verified=True, notes="submitted by user", concept_keys=["market_structure_bos"]),
            db,
            _user=SimpleNamespace(is_admin=False),
        )
        source = db.get(KnowledgeSource, result["id"])
        assert source.verified is False
        assert source.metadata_json["concept_keys"] == ["market_structure_bos"]
    finally:
        db.close()


def test_only_admin_can_manually_verify_a_source_with_evidence(tmp_path):
    db = _db(tmp_path)
    try:
        source = KnowledgeSource(title="Official exchange docs", source_type="official",
                                 url="https://example.org/docs", reliability_score=0.9,
                                 verified=False, metadata_json={"concept_keys": ["market_structure_bos"]})
        db.add(source)
        db.commit()
        db.refresh(source)
        with pytest.raises(HTTPException) as exc:
            verify_knowledge_source(source.id,
                KnowledgeVerify(concept_keys=["market_structure_bos"], reliability_score=0.9,
                                verification_notes="Checked official documentation and confirmed the claims."),
                db, user=SimpleNamespace(is_admin=False))
        assert exc.value.status_code == 403
        result = verify_knowledge_source(source.id,
            KnowledgeVerify(concept_keys=["market_structure_bos"], reliability_score=0.9,
                            verification_notes="Checked official documentation and confirmed the claims."),
            db, user=SimpleNamespace(is_admin=True, id=7))
        assert result["verified"] is True
        stored = db.get(KnowledgeSource, source.id)
        assert stored.verified is True
        assert stored.metadata_json["verification_method"] == "manual_admin_review"
    finally:
        db.close()


def test_unverified_sources_do_not_increase_knowledge_coverage(tmp_path):
    db = _db(tmp_path)
    try:
        db.add(KnowledgeSource(title="Unverified", source_type="manual", url="https://example.org",
                               reliability_score=1.0, verified=False,
                               metadata_json={"concept_keys": ["market_structure_bos"]}))
        db.commit()
        report = coverage_report(db)
        assert report["verified_sources"] == 0
        assert report["verified_concepts"] == 0
        assert report["foundation_ready"] is False
    finally:
        db.close()


def test_admin_can_add_concepts_for_missing_domains(tmp_path):
    db = _db(tmp_path)
    try:
        result = add_knowledge_concept(
            KnowledgeConceptCreate(key="indicators_ema", category="indicators", title="Exponential moving average",
                                  summary="An exponential moving average weights recent prices more heavily than older observations.",
                                  details=["It is a lagging indicator."], tags=["EMA"]),
            db, user=SimpleNamespace(is_admin=True, id=7),
        )
        from app.models.entities import KnowledgeConceptRecord
        record = db.query(KnowledgeConceptRecord).filter_by(key="indicators_ema").one()
        assert result["verified"] is False
        assert record.confidence == 0.0
    finally:
        db.close()


def test_coverage_counts_domain_only_after_three_concepts_and_two_verified_sources(tmp_path):
    db = _db(tmp_path)
    try:
        from app.models.entities import KnowledgeConceptRecord
        for key, title in (("indicators_ema", "EMA"), ("indicators_rsi", "RSI"), ("indicators_macd", "MACD")):
            db.add(KnowledgeConceptRecord(key=key, category="indicators", title=title,
                                          summary=f"Verified educational description for {title} indicator.",
                                          details=[], tags=[title], confidence=0.0))
        db.commit()
        for i in range(2):
            db.add(KnowledgeSource(title=f"Official technical reference {i}", source_type="official",
                url=f"https://example.org/technical-{i}", reliability_score=0.95, verified=True,
                metadata_json={"concept_keys": ["indicators_ema", "indicators_rsi", "indicators_macd"],
                               "verification_method": "manual_admin_review"}))
        db.commit()
        report = coverage_report(db)
        domain = next(x for x in report["domains"] if x["key"] == "technical_indicators")
        assert domain["ready"] is True
        assert domain["verified_concepts"] == 3
        assert domain["verified_sources"] == 2
        assert report["foundation_ready"] is False
    finally:
        db.close()


def test_every_required_domain_has_at_least_three_seeded_concepts():
    from app.knowledge.base import SEED_CONCEPTS, REQUIRED_KNOWLEDGE_DOMAINS
    for domain, spec in REQUIRED_KNOWLEDGE_DOMAINS.items():
        count = sum(1 for concept in SEED_CONCEPTS
                    if concept.category in spec["categories"] or concept.category == domain)
        assert count >= 3, f"knowledge domain under-seeded: {domain} ({count})"
    assert all(not concept.verified and concept.confidence == 0.0 for concept in SEED_CONCEPTS
               if concept.key not in {"market_structure_bos", "candlestick_context", "liquidity_sweep"})
    

def test_seed_source_catalog_is_visible_but_never_auto_verified():
    from app.knowledge.base import source_catalog
    catalog = source_catalog()
    assert len(catalog) >= 15
    assert all(x["url"].startswith("https://") for x in catalog)
    assert all(x["verified"] is False and x["status"] == "pending_admin_review" for x in catalog)
