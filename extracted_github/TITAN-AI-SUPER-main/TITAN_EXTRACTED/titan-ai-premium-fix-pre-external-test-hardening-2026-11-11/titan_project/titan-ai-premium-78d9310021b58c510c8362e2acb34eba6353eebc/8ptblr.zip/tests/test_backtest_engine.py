from app.engines.backtest import BacktestEngine


def _candles():
    return [
        {"timestamp": str(i), "open": o, "high": h, "low": l, "close": c}
        for i, (o, h, l, c) in enumerate([
            (100, 101, 99, 100),
            (100, 103, 99, 102),
            (102, 106, 101, 105),
            (105, 107, 104, 106),
            (106, 108, 105, 107),
        ])
    ]


def test_backtest_enters_next_bar_and_uses_real_candle_exit():
    result = BacktestEngine(fee_rate=0, slippage_rate=0).run(
        _candles(), [{"index": 0, "action": "buy", "quantity": 1}],
    )
    assert result["total_trades"] == 1
    trade = result["trades"][0]
    assert trade["entry_index"] == 1
    assert trade["entry_price"] == 100
    assert trade["exit_price"] == 107
    assert trade["exit_reason"] == "end_of_data"
    assert result["no_lookahead"] is True
    assert result["walk_forward_ready"] is False
    assert result["out_of_sample_ready"] is False


def test_backtest_stop_loss_wins_if_stop_and_target_touch_same_candle():
    candles = _candles()
    candles[1].update({"high": 110, "low": 90})
    result = BacktestEngine(fee_rate=0, slippage_rate=0).run(
        candles, [{"index": 0, "action": "buy", "quantity": 1, "stop_loss": 95, "take_profit": 108}],
    )
    assert result["trades"][0]["exit_reason"] == "stop_loss"
    assert result["trades"][0]["exit_price"] == 95


def test_backtest_spot_skips_short_signals_but_futures_accepts_them():
    signals = [{"index": 0, "action": "short", "quantity": 1}]
    spot = BacktestEngine(fee_rate=0, slippage_rate=0).run(_candles(), signals, market_type="spot")
    futures = BacktestEngine(fee_rate=0, slippage_rate=0).run(_candles(), signals, market_type="futures")
    assert spot["total_trades"] == 0
    assert spot["skipped_spot_shorts"] == 1
    assert futures["total_trades"] == 1


def test_backtest_skips_unanchored_signals_instead_of_guessing_timing():
    result = BacktestEngine().run(_candles(), [{"action": "buy", "price": 100}])
    assert result["total_trades"] == 0
    assert result["skipped_unanchored_signals"] == 1
