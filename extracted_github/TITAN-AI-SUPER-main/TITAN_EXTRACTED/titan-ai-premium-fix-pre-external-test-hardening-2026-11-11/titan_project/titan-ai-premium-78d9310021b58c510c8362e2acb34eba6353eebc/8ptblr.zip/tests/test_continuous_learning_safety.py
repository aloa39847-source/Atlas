from app.learning.continuous import ContinuousLearningSystem


def _metrics(**overrides):
    data = {
        "paper_trading_days": 45,
        "sample_size": 150,
        "out_of_sample": True,
        "walk_forward": True,
        "no_lookahead": True,
        "net_after_fees": True,
        "source_verified": True,
        "risk_breaches": 0,
        "profit_factor": 1.4,
        "max_drawdown": 0.10,
        "expectancy": 2.0,
    }
    data.update(overrides)
    return data


def test_expectancy_improvement_alone_cannot_pass_learning_gate():
    learner = ContinuousLearningSystem(knowledge_foundation_ready=True)
    proposal = learner.propose_improvement("ema", {}, {"period": 21}, "test", {"expectancy": 1.0})
    result = learner.test_proposal(proposal["id"], {"expectancy": 2.0})
    assert result["test_passed"] is False
    assert "minimum_30_paper_days_required" in result["validation_failures"]


def test_learning_gate_requires_zero_risk_breaches_and_verified_source():
    learner = ContinuousLearningSystem(knowledge_foundation_ready=True)
    proposal = learner.propose_improvement("ema", {}, {"period": 21}, "test", {"expectancy": 1.0})
    result = learner.test_proposal(proposal["id"], _metrics(risk_breaches=1, source_verified=False))
    assert result["test_passed"] is False
    assert "risk_breaches_must_be_zero" in result["validation_failures"]
    assert "verified_data_source_required" in result["validation_failures"]


def test_live_approval_requires_successful_validation_and_explicit_approval():
    learner = ContinuousLearningSystem(knowledge_foundation_ready=True)
    proposal = learner.propose_improvement("ema", {}, {"period": 21}, "test", {"expectancy": 1.0})
    learner.test_proposal(proposal["id"], _metrics())
    assert learner.approve_for_live(proposal["id"], explicit_approval=False)["error"] == "explicit_approval_required"
    approved = learner.approve_for_live(proposal["id"], explicit_approval=True)
    assert approved["ok"] is True


def test_failed_validation_cannot_be_approved_for_live():
    learner = ContinuousLearningSystem(knowledge_foundation_ready=True)
    proposal = learner.propose_improvement("ema", {}, {"period": 21}, "test", {"expectancy": 1.0})
    learner.test_proposal(proposal["id"], _metrics(max_drawdown=0.40))
    result = learner.approve_for_live(proposal["id"], explicit_approval=True)
    assert result["ok"] is False
    assert result["error"] == "all_validation_gates_must_pass"


def test_rollback_does_not_claim_to_apply_without_version_store():
    learner = ContinuousLearningSystem(knowledge_foundation_ready=True)
    result = learner.rollback("ema", 1)
    assert result["ok"] is False
    assert result["applied"] is False


def test_continuous_learning_is_disabled_by_default_until_knowledge_foundation_ready():
    learner = ContinuousLearningSystem()
    result = learner.propose_improvement("ema", {}, {"period": 21}, "test", {"expectancy": 1.0})
    assert result["ok"] is False
    assert result["error"] == "knowledge_foundation_incomplete"
    assert result["proposal_created"] is False


def test_learning_gate_rejects_non_finite_metrics():
    import math
    learner = ContinuousLearningSystem(knowledge_foundation_ready=True)
    proposal = learner.propose_improvement("ema", {}, {"period": 21}, "test", {"expectancy": 1.0})
    result = learner.test_proposal(proposal["id"], _metrics(
        profit_factor=math.nan, max_drawdown=math.inf, expectancy=math.nan))
    assert result["test_passed"] is False
    assert "profit_factor_invalid" in result["validation_failures"]
    assert "max_drawdown_invalid" in result["validation_failures"]
    assert "expectancy_metrics_invalid" in result["validation_failures"]


def test_learning_gate_rejects_invalid_counts_and_negative_drawdown():
    learner = ContinuousLearningSystem(knowledge_foundation_ready=True)
    proposal = learner.propose_improvement("ema", {}, {"period": 21}, "test", {"expectancy": 1.0})
    result = learner.test_proposal(proposal["id"], _metrics(
        paper_trading_days=float("nan"), sample_size=100.5,
        risk_breaches=float("inf"), max_drawdown=-0.01))
    assert result["test_passed"] is False
    assert "paper_trading_days_invalid" in result["validation_failures"]
    assert "sample_size_invalid" in result["validation_failures"]
    assert "risk_breach_count_invalid" in result["validation_failures"]
    assert "max_drawdown_invalid" in result["validation_failures"]


def test_learning_gate_rejects_non_object_metrics_without_crashing():
    learner = ContinuousLearningSystem(knowledge_foundation_ready=True)
    proposal = learner.propose_improvement("ema", {}, {"period": 21}, "test", {"expectancy": 1.0})
    result = learner.test_proposal(proposal["id"], [1, 2, 3])
    assert result["test_passed"] is False
    assert "performance_metrics_must_be_object" in result["validation_failures"]
