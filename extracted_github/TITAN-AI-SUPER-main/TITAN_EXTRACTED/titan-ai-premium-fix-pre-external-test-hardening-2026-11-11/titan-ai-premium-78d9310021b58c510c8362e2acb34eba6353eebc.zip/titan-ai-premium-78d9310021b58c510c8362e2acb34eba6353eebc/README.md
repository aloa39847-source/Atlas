# TITAN AI PREMIUM (Foundation Build)

This workspace contains an **integrated, extensible foundation** for TITAN AI PREMIUM (Backend + Frontend + SQLite + tests/docs). It follows the core safety and architecture requirements from the master specification, but **it is not the full final system**. Many advanced engines/integrations are registered and intentionally marked as `not_implemented` or `needs_external_service`.

## What is real in this build
- **Separation enforced in design/state**: `demo/live` and `spot/futures/earn` are explicit. Auto demo→live is disabled. Withdrawal permissions are not supported.
- **TITAN AI CORE foundation**: engine registry/status, system state, audit logging, knowledge/learning records (SQLite).
- **Working analysis pipeline (tested)** using **LABELED SYNTHETIC** candles for research/testing and **Binance Public read-only** candles for live market analysis:
  - Multi-timeframe provider (1D/4H/1H/15M/5M) supports labeled synthetic data and Binance Public klines (read-only, no API key). In-progress candles are excluded from public-data analysis.
  - Technical analysis (EMA/SMA/RSI/MACD/Bollinger/ATR heuristics, basic candle/structure signals).
  - Risk/cost engine (estimates; fee/slippage assumptions labeled; leverage capped; Spot has no leverage; Earn not treated as trade execution).
  - Decision engine (BUY/SELL/LONG/SHORT/WAIT) with rationale, confidence note, and data-source warning.
- **Backend API code** (Starlette runtime with service layer) for status, state, strategies, analysis, decisions, audit, knowledge, learning, and read-only Smart Scanner.
- **Frontend** (React + Vite, mobile-responsive PWA shell) that consumes `/api/*` and shows honest statuses (no fake data).
- **Supervised Demo/Shadow worker**: Master Start/Stop/Emergency Stop controls a joinable in-process worker for the selected Spot or USD-M Futures market. Automatic mode uses the Spot BUY scanner or the dedicated USDT-perpetual Futures LONG/SHORT scanner; existing positions are always cycled first for protection. It uses public read-only data and internal Shadow records only; it never sends Binance orders.
- **Smart Scanners**: bounded liquid Spot discovery and a separate active USDT-perpetual Futures discovery path; both analyze 1D/4H/1H/15M/5M with freshness/coverage checks, ranked results and explicit skipped-candidate reasons.
- **Backtesting**: four existing Spot strategies connected to a causal next-candle-open simulator with fees/slippage and deterministic rolling Walk-Forward/OOS folds. Each signal uses only history available up to the current test candle; no real orders are sent.

## What remains incomplete or requires external configuration

- **Deferred to Binance Testnet:** authenticated account/balance sync, Spot/Futures order submit/cancel/modify, exchange-side SL/TP/trailing orders, order-state reconciliation, reconnect/resynchronization, and end-to-end execution tests. Live execution remains disabled and requires separate explicit approval.
- **Still partial without Testnet:** knowledge-source verification/provenance; full continuous-learning integration into strategy parameters; planned dedicated M5 scalping, H1/H4 swing, liquidity/order-flow trading and arbitrage strategies; complete on-chain/tokenomics due diligence; broad news coverage and economic-calendar/NLP analysis; real-time WebSocket order flow; exchange-exact Futures margin/liquidation/funding behavior (the Demo worker uses conservative estimates, and funding payments use the latest mark rather than a historical funding-time mark); wider ML calibration/OOS validation; and full agent orchestration.
- **Research-only outputs:** performance analytics use the internal Demo/Shadow ledger; prediction tracking is a single mark-to-market observation, not realized PnL. The ML model is a baseline and cannot independently authorize trades.
- **External configuration:** Telegram requires a Bot Token and allowlisted Chat IDs in server environment variables. AI-provider features require provider keys. Public CoinGecko/RSS endpoints have coverage and rate-limit constraints.
- **Deployment:** production multi-process worker supervision, 24/7 monitoring, and Android APK packaging remain separate work. The current worker is managed inside one application process.

## Verification

The last fully successful CI run before the current Futures-worker expansion is [run 42526011590](https://github.com/unkn11527-ux/titan-ai-premium/actions/runs/42526011590). The new Futures-worker commits have triggered CI, but the recent jobs have failed before runner assignment (runner ID 0 and no executed steps); therefore, the Futures expansion is **not yet CI-verified**. Do not interpret those infrastructure failures as passing tests or as proof of code failure.

- No Binance Testnet or Live orders were used.
- The Futures worker and its new tests require a successful CI run before being treated as verified.

See [Demo USD-M Futures worker operation and safety](docs/DEMO_FUTURES_WORKER.md), [the detailed Arabic implementation status](docs/IMPLEMENTATION_STATUS_2026-11-08_AR.md), and [the implementation update](docs/IMPLEMENTATION_UPDATE_2026-11-08_AR.md).

## Run (standard environment)
### Backend
```bash
python3 -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r backend/requirements.txt
# run from backend/ with app import path
cd backend
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```
Vite proxies `/api` to `http://127.0.0.1:8000` by default.

## Safety rules
- Never commit `.env`, API keys, Telegram tokens, or secrets.
- Use Binance Demo/Testnet before any live environment; verify environment support.
- No auto demo→live. No withdrawal permissions.
- Do not present synthetic/test data as real market data.
- No profit guarantees.

## Recovered previous material
Files provided in chat were preserved unchanged under `recovered/titan_ai_premium_demo_starter/` (the starter is incomplete; missing `titan.strategy` implementation).
