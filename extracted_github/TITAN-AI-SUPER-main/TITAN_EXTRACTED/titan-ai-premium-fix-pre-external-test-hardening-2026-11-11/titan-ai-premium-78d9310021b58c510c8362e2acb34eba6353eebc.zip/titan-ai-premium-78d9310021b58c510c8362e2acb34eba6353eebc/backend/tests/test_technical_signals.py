from app.core.enums import Timeframe
from app.engines.market_data import Candles
from app.engines.technical import TechnicalAnalysisEngine


def test_confirmed_close_breakout_is_exposed_as_strategy_signal():
    rows = []
    for index in range(40):
        rows.append({
            "open": 100.0,
            "high": 101.0,
            "low": 99.0,
            "close": 100.0,
            "volume": 100.0,
        })
    rows[-1] = {
        "open": 103.0,
        "high": 105.0,
        "low": 102.5,
        "close": 104.0,
        "volume": 250.0,
    }
    result = TechnicalAnalysisEngine().analyze(Candles(rows), Timeframe.M15)
    assert "breakout_bullish" in result.signals
    assert any(event["direction"] == "bullish" for event in result.structure["bos_choch"])


def test_ema50_is_not_substituted_with_a_shorter_ema():
    rows = []
    for index in range(40):
        price = 100.0 + index
        rows.append({
            "open": price - 0.2, "high": price + 0.5,
            "low": price - 0.5, "close": price, "volume": 100.0,
        })
    short = TechnicalAnalysisEngine().analyze(Candles(rows), Timeframe.H1)
    assert short.indicators["ema50"] is None
    assert "price_above_ema20_ema50" not in short.signals

    for index in range(20):
        price = 140.0 + index
        rows.append({
            "open": price - 0.2, "high": price + 0.5,
            "low": price - 0.5, "close": price, "volume": 100.0,
        })
    full = TechnicalAnalysisEngine().analyze(Candles(rows), Timeframe.H1)
    assert full.indicators["ema50"] is not None
    assert "price_above_ema20_ema50" in full.signals


def test_technical_analysis_rejects_non_finite_or_inconsistent_ohlcv():
    rows = []
    for index in range(40):
        price = 100.0 + index
        rows.append({
            "open": price - 0.2, "high": price + 0.5,
            "low": price - 0.5, "close": price, "volume": 100.0,
        })
    rows[-1] = {**rows[-1], "high": 1.0}
    invalid_ohlc = TechnicalAnalysisEngine().analyze(Candles(rows), Timeframe.M5)
    assert "invalid_ohlcv_integrity" in invalid_ohlc.signals

    rows[-1] = {**rows[-1], "high": 140.5, "volume": float("nan")}
    invalid_volume = TechnicalAnalysisEngine().analyze(Candles(rows), Timeframe.M5)
    assert "invalid_ohlcv_integrity" in invalid_volume.signals
