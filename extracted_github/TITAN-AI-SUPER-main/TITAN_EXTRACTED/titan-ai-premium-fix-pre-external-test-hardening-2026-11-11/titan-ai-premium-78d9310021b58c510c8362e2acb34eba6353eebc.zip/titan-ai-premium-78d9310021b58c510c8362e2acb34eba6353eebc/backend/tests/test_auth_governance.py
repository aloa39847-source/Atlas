from __future__ import annotations

from app.models import db as dbmod
from app.models.db import SessionLocal
from app.services import auth_service
from app.services.governance import record_config_change
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from app.models.entities import ConfigChange


def test_password_hash_and_verify():
    ph, salt = auth_service.hash_password("CorrectHorseBatteryStaple123")
    assert auth_service.verify_password("CorrectHorseBatteryStaple123", ph, salt) is True
    assert auth_service.verify_password("wrong", ph, salt) is False


def test_allowlist_enforced_when_required(monkeypatch):
    monkeypatch.setenv("TITAN_AUTH_REQUIRED", "true")
    monkeypatch.setenv("TITAN_ALLOWED_EMAILS", "abdoavm02@gmail.com")
    assert auth_service.email_allowed("abdoavm02@gmail.com") is True
    assert auth_service.email_allowed("other@example.com") is False


def test_config_change_recorded(tmp_path, monkeypatch):
    db_path = tmp_path / "gov.db"
    dbmod.engine.dispose()
    dbmod.engine = create_engine(f"sqlite:///{db_path}", connect_args={"check_same_thread": False}, future=True)
    dbmod.SessionLocal = sessionmaker(bind=dbmod.engine, autoflush=False, autocommit=False, future=True)
    dbmod.Base.metadata.create_all(bind=dbmod.engine)
    db = dbmod.SessionLocal()
    try:
        record_config_change(db, actor="test", scope="risk", key="max_leverage", old_value={"v": 3}, new_value={"v": 2}, reason="test", approved=True)
        db.commit()
        row = db.execute(select(ConfigChange)).scalar_one()
        assert row.scope == "risk" and row.approved is True
    finally:
        db.close()
