from __future__ import annotations

import base64

from app.core.config import settings
from app.services.credentials import _key_bytes, _xor, _storage_path, decrypt_secret, encrypt_secret


def test_testnet_credentials_require_strong_application_secret(monkeypatch):
    monkeypatch.setattr(settings, "secret_key", "dev-only-change-locally")
    try:
        encrypt_secret("test-secret")
        assert False, "weak application secret must be rejected"
    except RuntimeError as exc:
        assert "strong_titan_secret_key_required" in str(exc)


def test_testnet_credentials_use_authenticated_fernet_encryption(monkeypatch):
    monkeypatch.setattr(settings, "secret_key", "A" * 48)
    token = encrypt_secret("binance-testnet-secret")
    assert token.startswith("v2:")
    assert "binance-testnet-secret" not in token
    assert decrypt_secret(token) == "binance-testnet-secret"

    tampered = token[:-1] + ("A" if token[-1] != "A" else "B")
    assert decrypt_secret(tampered) == ""


def test_legacy_testnet_credentials_remain_readable(monkeypatch):
    monkeypatch.setattr(settings, "secret_key", "legacy-secret-key-for-migration")
    raw = b"legacy-api-secret"
    legacy = base64.urlsafe_b64encode(_xor(raw, _key_bytes())).decode()
    assert decrypt_secret(legacy) == "legacy-api-secret"


def test_testnet_credential_storage_respects_persistent_data_directory(tmp_path, monkeypatch):
    target = tmp_path / "persistent-volume"
    monkeypatch.setenv("TITAN_DATA_DIR", str(target))
    path = _storage_path()
    assert path == target / "binance_testnet_creds.json"
    assert target.is_dir()
