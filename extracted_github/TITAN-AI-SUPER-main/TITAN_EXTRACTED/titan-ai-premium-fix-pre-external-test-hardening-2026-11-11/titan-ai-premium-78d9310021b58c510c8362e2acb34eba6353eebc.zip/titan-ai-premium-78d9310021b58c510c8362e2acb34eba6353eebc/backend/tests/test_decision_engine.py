from app.core.enums import EnvironmentMode, MarketType, Timeframe
from app.engines.decision import DecisionEngine
from app.engines.technical import TimeframeAnalysis


def _analysis(timeframe, trend, signals):
    return TimeframeAnalysis(
        timeframe=timeframe,
        trend=trend,
        signals=list(signals),
        indicators={"close": 100.0, "atr14": 1.0},
        structure={"bias": "neutral", "breakouts": []},
        candles={"patterns": []},
    )


def test_decision_waits_when_entry_timeframe_conflicts_with_higher_timeframes():
    engine = DecisionEngine()
    engine.hybrid = None
    engine.multi_agent = None
    analyses = {
        Timeframe.D1: _analysis(Timeframe.D1, "bullish", ["price_above_ema20_ema50", "macd_hist_positive"]),
        Timeframe.H4: _analysis(Timeframe.H4, "bullish", ["price_above_ema20_ema50", "macd_hist_positive"]),
        Timeframe.H1: _analysis(Timeframe.H1, "bullish", ["price_above_ema20_ema50", "macd_hist_positive"]),
        Timeframe.M15: _analysis(Timeframe.M15, "bearish", ["price_below_ema20_ema50", "macd_hist_negative"]),
        Timeframe.M5: _analysis(Timeframe.M5, "sideways", []),
    }
    result = engine.decide(
        symbol="BTC/USDT", market=MarketType.SPOT, environment=EnvironmentMode.DEMO,
        timeframe_analyses=analyses, balance=150.0, max_leverage=1.0,
        risk_per_trade=0.005,
    )
    assert result["bias"] == "bullish"
    assert result["entry_timeframe"] == "15m"
    assert result["entry_timeframe_aligned"] is False
    assert result["action"] == "wait"
    assert "conflicts" in result["reason"]


def test_decision_allows_direction_only_when_selected_entry_timeframe_aligns():
    engine = DecisionEngine()
    engine.hybrid = None
    engine.multi_agent = None
    analyses = {
        Timeframe.D1: _analysis(Timeframe.D1, "bullish", ["price_above_ema20_ema50", "macd_hist_positive"]),
        Timeframe.H4: _analysis(Timeframe.H4, "bullish", ["price_above_ema20_ema50", "macd_hist_positive"]),
        Timeframe.H1: _analysis(Timeframe.H1, "bullish", ["price_above_ema20_ema50", "macd_hist_positive"]),
        Timeframe.M15: _analysis(Timeframe.M15, "bullish", ["price_above_ema20_ema50", "macd_hist_positive"]),
        Timeframe.M5: _analysis(Timeframe.M5, "bullish", ["price_above_ema20_ema50", "macd_hist_positive"]),
    }
    result = engine.decide(
        symbol="BTC/USDT", market=MarketType.SPOT, environment=EnvironmentMode.DEMO,
        timeframe_analyses=analyses, balance=150.0, max_leverage=1.0,
        risk_per_trade=0.005,
    )
    assert result["entry_timeframe_aligned"] is True
    assert result["action"] == "buy"


def test_decision_waits_when_any_approved_timeframe_is_missing():
    engine = DecisionEngine()
    engine.hybrid = None
    engine.multi_agent = None
    analyses = {
        Timeframe.D1: _analysis(Timeframe.D1, "bullish", ["price_above_ema20_ema50", "macd_hist_positive"]),
        Timeframe.H4: _analysis(Timeframe.H4, "bullish", ["price_above_ema20_ema50", "macd_hist_positive"]),
        Timeframe.H1: _analysis(Timeframe.H1, "bullish", ["price_above_ema20_ema50", "macd_hist_positive"]),
        Timeframe.M15: _analysis(Timeframe.M15, "bullish", ["price_above_ema20_ema50", "macd_hist_positive"]),
        # M5 intentionally absent: the approved five-timeframe stack is incomplete.
    }
    result = engine.decide(
        symbol="BTC/USDT", market=MarketType.SPOT, environment=EnvironmentMode.DEMO,
        timeframe_analyses=analyses, balance=150.0, max_leverage=1.0,
        risk_per_trade=0.005,
    )
    assert result["action"] == "wait"
    assert result["reason"] == "required_timeframe_data_missing"
    assert result["extra"]["missing_timeframes"] == ["5m"]
