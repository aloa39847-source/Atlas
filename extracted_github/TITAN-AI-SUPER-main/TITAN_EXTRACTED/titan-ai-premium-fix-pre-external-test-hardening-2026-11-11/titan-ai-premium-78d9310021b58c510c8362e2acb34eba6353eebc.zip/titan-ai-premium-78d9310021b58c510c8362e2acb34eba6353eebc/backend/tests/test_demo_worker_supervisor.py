from __future__ import annotations

from app.models import db as dbmod
from app.models.entities import SystemState
from app.scripts import run_demo_loop
from app.services.core_service import core_service
from app.services.demo_worker_supervisor import DemoWorkerSupervisor
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker


def test_supervisor_owns_one_joinable_worker_and_stops_it(tmp_path, monkeypatch):
    engine = create_engine(
        f"sqlite:///{tmp_path / 'supervisor.db'}",
        connect_args={"check_same_thread": False},
        future=True,
    )
    monkeypatch.setattr(dbmod, "engine", engine)
    monkeypatch.setattr(dbmod, "SessionLocal", sessionmaker(
        bind=engine, autoflush=False, autocommit=False, future=True,
    ))
    monkeypatch.setattr(dbmod, "init_db", lambda: dbmod.Base.metadata.create_all(bind=engine))
    dbmod.init_db()
    db = dbmod.SessionLocal()
    core_service.ensure_bootstrap(db)
    state = db.get(SystemState, 1)
    state.bot_run_state = "starting"
    db.add(state)
    db.commit()
    db.close()

    def fake_run(*, interval_seconds, symbols, once, stop_event, market="spot"):
        session = dbmod.SessionLocal()
        try:
            row = session.get(SystemState, 1)
            row.bot_run_state = "running"
            session.add(row)
            session.commit()
        finally:
            session.close()
        assert stop_event.wait(2.0)
        session = dbmod.SessionLocal()
        try:
            row = session.get(SystemState, 1)
            row.bot_run_state = "stopped"
            row.bot_stop_reason = "user_stop"
            session.add(row)
            session.commit()
        finally:
            session.close()
        return 0

    monkeypatch.setattr(run_demo_loop, "run", fake_run)
    supervisor = DemoWorkerSupervisor()
    try:
        started = supervisor.start(interval_seconds=30, symbols=["BTC/USDT"])
        assert started["ok"] is True
        assert supervisor.status()["running"] is True
        assert supervisor.start()["error"] == "demo_worker_already_running"

        stopped = supervisor.stop(timeout=2.0)
        assert stopped["ok"] is True
        assert supervisor.status()["running"] is False
        db = dbmod.SessionLocal()
        try:
            assert db.get(SystemState, 1).bot_run_state == "stopped"
        finally:
            db.close()
    finally:
        supervisor.stop(timeout=2.0)
        engine.dispose()


def test_core_start_claims_demo_spot_or_futures_and_blocks_duplicate_start(tmp_path, monkeypatch):
    engine = create_engine(
        f"sqlite:///{tmp_path / 'master_start.db'}",
        connect_args={"check_same_thread": False},
        future=True,
    )
    monkeypatch.setattr(dbmod, "engine", engine)
    monkeypatch.setattr(dbmod, "SessionLocal", sessionmaker(
        bind=engine, autoflush=False, autocommit=False, future=True,
    ))
    monkeypatch.setattr(dbmod, "init_db", lambda: dbmod.Base.metadata.create_all(bind=engine))
    dbmod.init_db()
    db = dbmod.SessionLocal()
    try:
        core_service.ensure_bootstrap(db)
        prepared = core_service.start_bot(db, account_target="demo")
        assert prepared["ok"] is True
        assert prepared["state"]["bot_run_state"] == "starting"
        assert prepared["checks"]["continuous_worker_available"] is True
        try:
            core_service.start_bot(db, account_target="demo")
            assert False, "duplicate startup must be rejected"
        except ValueError as exc:
            assert "duplicate" in str(exc).lower()
        core_service.stop_bot(db, reason="test_cleanup")
        state = db.get(SystemState, 1)
        state.market_type = "futures"
        db.add(state)
        db.commit()
        futures_prepared = core_service.start_bot(db, account_target="demo")
        assert futures_prepared["ok"] is True
        assert futures_prepared["state"]["market_type"] == "futures"
        core_service.stop_bot(db, reason="test_cleanup_futures")
        try:
            core_service.start_bot(db, account_target="testnet")
            assert False, "Testnet must not be started by the internal Demo worker"
        except ValueError as exc:
            assert str(exc) == "continuous_worker_demo_spot_or_futures_only"
    finally:
        db.close()
        engine.dispose()


def test_supervisor_defaults_to_automatic_smart_scan_mode(tmp_path, monkeypatch):
    engine = create_engine(
        f"sqlite:///{tmp_path / 'supervisor_auto.db'}",
        connect_args={"check_same_thread": False},
        future=True,
    )
    monkeypatch.setattr(dbmod, "engine", engine)
    monkeypatch.setattr(dbmod, "SessionLocal", sessionmaker(
        bind=engine, autoflush=False, autocommit=False, future=True,
    ))
    monkeypatch.setattr(dbmod, "init_db", lambda: dbmod.Base.metadata.create_all(bind=engine))
    dbmod.init_db()
    db = dbmod.SessionLocal()
    core_service.ensure_bootstrap(db)
    state = db.get(SystemState, 1)
    state.bot_run_state = "starting"
    db.add(state); db.commit(); db.close()
    captured = {}

    def fake_run(*, interval_seconds, symbols, once, stop_event, market="spot"):
        captured["symbols"] = symbols
        session = dbmod.SessionLocal()
        try:
            row = session.get(SystemState, 1)
            row.bot_run_state = "running"
            session.add(row); session.commit()
        finally:
            session.close()
        stop_event.wait(2.0)
        return 0

    monkeypatch.setattr(run_demo_loop, "run", fake_run)
    supervisor = DemoWorkerSupervisor()
    try:
        started = supervisor.start(interval_seconds=30)
        assert started["ok"] is True
        assert captured["symbols"] is None
        assert supervisor.status()["symbol_mode"] == "auto_smart_scan"
        assert supervisor.stop(timeout=2.0)["ok"] is True
    finally:
        supervisor.stop(timeout=2.0)
        engine.dispose()
