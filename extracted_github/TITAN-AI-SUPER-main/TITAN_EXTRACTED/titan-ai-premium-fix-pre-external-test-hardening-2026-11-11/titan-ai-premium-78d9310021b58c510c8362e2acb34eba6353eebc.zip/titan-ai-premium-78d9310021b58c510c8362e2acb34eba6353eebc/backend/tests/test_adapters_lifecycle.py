from app.core.enums import MarketType
from app.integrations.binance_adapter import BinanceAdapter, BinanceConfig
from app.integrations.telegram_adapter import TelegramAdapter


def test_binance_shadow_order_does_not_send():
    b = BinanceAdapter(BinanceConfig(enabled=False, environment="demo"))
    r = b.place_order_shadow(symbol="BTC/USDT", market=MarketType.SPOT, side="buy", order_type="limit", quantity=0.01, price=50000, reference_price=50000)
    assert r["mode"] == "shadow"
    assert r["sent_to_exchange"] is False
    assert "precheck" in r


def test_binance_live_blocked_in_foundation():
    b = BinanceAdapter()
    r = b.place_order_live(symbol="BTC/USDT")
    assert r["ok"] is False and r["sent_to_exchange"] is False


def test_telegram_sensitive_command_not_executed():
    t = TelegramAdapter()
    r = t.parse_command("123", "/startbot")
    assert r["sensitive"] is True
    assert r["executed"] is False
    assert r["authorized"] is False


def test_binance_testnet_adapter_rejects_futures_execution():
    from app.integrations.binance_adapter import BinanceTestnetAdapter, BinanceConfig
    adapter = BinanceTestnetAdapter(BinanceConfig(enabled=True, environment="testnet", market="futures"))
    result = adapter.place_order("BTCUSDT", "BUY", "MARKET", 0.001)
    assert result["ok"] is False
    assert result["sent_to_exchange"] is False
    assert result["error"] == "testnet_credentials_missing"

def test_binance_testnet_futures_order_uses_guarded_endpoint_and_leverage(monkeypatch):
    adapter = BinanceAdapter(BinanceConfig(enabled=True, environment="testnet", market="futures"))
    monkeypatch.setattr(adapter, "_api_key", lambda: "testnet-key")
    monkeypatch.setattr(adapter, "_api_secret", lambda: "testnet-secret")
    calls = []

    def fake_request(method, path, signed=False, params=None):
        calls.append((method, path, dict(params or {})))
        if path == "/fapi/v2/account":
            return {"canTrade": True, "availableBalance": "1000"}
        if path == "/fapi/v1/ticker/price":
            return {"symbol": "BTCUSDT", "price": "50000"}
        if path == "/fapi/v1/exchangeInfo":
            return {"symbols": [{"symbol": "BTCUSDT", "status": "TRADING", "filters": [
                {"filterType": "LOT_SIZE", "stepSize": "0.001"},
                {"filterType": "PRICE_FILTER", "tickSize": "0.1"},
                {"filterType": "MIN_NOTIONAL", "notional": "5"}]}]}
        if path == "/fapi/v1/leverage":
            return {"symbol": "BTCUSDT", "leverage": 5}
        if path == "/fapi/v1/order":
            return {"orderId": 123, "status": "NEW"}
        raise AssertionError("unexpected endpoint: " + path)

    monkeypatch.setattr(adapter, "_request", fake_request)
    result = adapter.place_order("BTC/USDT", "BUY", "MARKET", 0.001, leverage=5)
    assert result["ok"] is True
    assert result["sent_to_exchange"] is True
    assert result["testnet"] is True
    assert result["market"] == "futures"
    assert any(path == "/fapi/v1/leverage" for _, path, _ in calls)
    order_call = next(call for call in calls if call[1] == "/fapi/v1/order")
    assert order_call[2]["quantity"] == "0.001"


def test_binance_testnet_futures_enforces_800_usdt_notional_cap(monkeypatch):
    adapter = BinanceAdapter(BinanceConfig(enabled=True, environment="testnet", market="futures"))
    monkeypatch.setattr(adapter, "_api_key", lambda: "testnet-key")
    monkeypatch.setattr(adapter, "_api_secret", lambda: "testnet-secret")
    calls = []

    def fake_request(method, path, signed=False, params=None):
        calls.append(path)
        if path == "/fapi/v2/account":
            return {"canTrade": True}
        if path == "/fapi/v1/ticker/price":
            return {"symbol": "BTCUSDT", "price": "50000"}
        if path == "/fapi/v1/exchangeInfo":
            return {"symbols": [{"symbol": "BTCUSDT", "status": "TRADING", "filters": [
                {"filterType": "LOT_SIZE", "stepSize": "0.001"}]}]}
        raise AssertionError("order or leverage must not be sent: " + path)

    monkeypatch.setattr(adapter, "_request", fake_request)
    result = adapter.place_order("BTC/USDT", "BUY", "MARKET", 0.02, leverage=5)
    assert result["ok"] is False
    assert result["sent_to_exchange"] is False
    assert result["error"] == "pretrade_blocked"
    assert "notional_exceeds_limit" in result["details"]["reason"]
    assert "/fapi/v1/order" not in calls
    assert "/fapi/v1/leverage" not in calls


def test_binance_testnet_futures_rejects_leverage_above_ten(monkeypatch):
    adapter = BinanceAdapter(BinanceConfig(enabled=True, environment="testnet", market="futures"))
    monkeypatch.setattr(adapter, "_api_key", lambda: "testnet-key")
    monkeypatch.setattr(adapter, "_api_secret", lambda: "testnet-secret")
    result = adapter.place_order("BTC/USDT", "BUY", "MARKET", 0.001, leverage=11)
    assert result["ok"] is False
    assert result["sent_to_exchange"] is False
    assert result["error"] == "leverage_outside_titan_cap"


def _spot_testnet_adapter_with_mocked_account(monkeypatch, balances):
    adapter = BinanceAdapter(BinanceConfig(enabled=True, environment="testnet", market="spot"))
    monkeypatch.setattr(adapter, "_api_key", lambda: "testnet-key")
    monkeypatch.setattr(adapter, "_api_secret", lambda: "testnet-secret")

    def fake_request(method, path, signed=False, params=None):
        if path == "/api/v3/account":
            return {"canTrade": True, "balances": balances}
        if path == "/api/v3/ticker/price":
            return {"symbol": "BTCUSDT", "price": "50000"}
        if path == "/api/v3/exchangeInfo":
            return {"symbols": [{"symbol": "BTCUSDT", "status": "TRADING", "filters": [
                {"filterType": "LOT_SIZE", "stepSize": "0.001"},
                {"filterType": "PRICE_FILTER", "tickSize": "0.1"},
                {"filterType": "MIN_NOTIONAL", "minNotional": "5"}]}]}
        raise AssertionError("unexpected endpoint: " + path)

    monkeypatch.setattr(adapter, "_request", fake_request)
    return adapter


def test_binance_testnet_spot_buy_requires_free_quote_balance(monkeypatch):
    adapter = _spot_testnet_adapter_with_mocked_account(monkeypatch, [
        {"asset": "BTC", "free": "1"},
        {"asset": "USDT", "free": "40"},
    ])
    result = adapter.place_order("BTC/USDT", "BUY", "MARKET", 0.001)
    assert result["ok"] is False
    assert result["sent_to_exchange"] is False
    assert result["error"] == "insufficient_testnet_spot_balance"
    assert result["asset"] == "USDT"
    assert result["required"] > result["available"]


def test_binance_testnet_spot_sell_requires_free_base_balance(monkeypatch):
    adapter = _spot_testnet_adapter_with_mocked_account(monkeypatch, [
        {"asset": "BTC", "free": "0.0005"},
        {"asset": "USDT", "free": "1000"},
    ])
    result = adapter.place_order("BTC/USDT", "SELL", "MARKET", 0.001)
    assert result["ok"] is False
    assert result["sent_to_exchange"] is False
    assert result["error"] == "insufficient_testnet_spot_balance"
    assert result["asset"] == "BTC"
