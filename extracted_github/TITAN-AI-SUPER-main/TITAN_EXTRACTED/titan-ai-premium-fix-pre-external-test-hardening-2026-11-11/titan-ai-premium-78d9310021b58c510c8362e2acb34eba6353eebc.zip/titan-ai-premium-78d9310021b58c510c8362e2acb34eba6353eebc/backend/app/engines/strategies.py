from __future__ import annotations

from datetime import datetime, timezone
import math

from app.core.enums import MarketType


# Extensible strategy registry (examples + metadata). Not a claim of completeness or profitability.
STRATEGIES = [
    {"key": "trend_following_ema", "name": "Trend Following (EMA)", "category": "trend", "markets": ["spot", "futures"], "status": "implemented_partial"},
    {"key": "momentum_macd_rsi", "name": "Momentum (MACD/RSI)", "category": "momentum", "markets": ["spot", "futures"], "status": "implemented_partial"},
    {"key": "mean_reversion_bbands", "name": "Mean Reversion (Bollinger Bands)", "category": "mean_reversion", "markets": ["spot", "futures"], "status": "implemented_partial"},
    {"key": "breakout_structure", "name": "Breakout / Market Structure", "category": "breakout", "markets": ["spot", "futures"], "status": "implemented_partial"},
    {"key": "scalping_m5", "name": "Scalping (M5 timing)", "category": "scalping", "markets": ["spot", "futures"], "status": "implemented"},
    {"key": "swing_h1_h4", "name": "Swing (H1/H4)", "category": "swing", "markets": ["spot", "futures"], "status": "implemented"},
    {"key": "liquidity_orderflow", "name": "Liquidity/Order Flow", "category": "order_flow", "markets": ["spot", "futures"], "status": "implemented_partial"},
    {"key": "arbitrage", "name": "Triangular Arbitrage (Spot)", "category": "arbitrage", "markets": ["spot"], "status": "implemented_partial"},
]


def list_strategies() -> list[dict]:
    return list(STRATEGIES)


def select_strategy(
    market: MarketType,
    bias: str,
    signals: list[str],
    timeframe_analyses: dict | None = None,
    microstructure_analysis: dict | None = None,
    expected_symbol: str | None = None,
) -> dict:
    """Select only a strategy with matching implemented evidence; never guess a fallback."""
    active = [
        strategy for strategy in STRATEGIES
        if market.value in strategy["markets"]
        and strategy["status"] in {"implemented", "implemented_partial"}
    ]
    signal_set = set(signals or [])
    by_key = {strategy["key"]: strategy for strategy in active}
    tf = {
        (key.value if hasattr(key, "value") else str(key)): value
        for key, value in (timeframe_analyses or {}).items()
    }
    d1, h4, h1, m15, m5 = (tf.get(name) for name in ("1d", "4h", "1h", "15m", "5m"))


    # M5 entries require a matching 15M setup and higher-timeframe bias.
    if "scalping_m5" in by_key and bias in {"bullish", "bearish"} and m5 and m15 and m5.trend == bias and m15.trend == bias:
        m5_signals = set(m5.signals or [])
        direction_signal = "macd_hist_positive" if bias == "bullish" else "macd_hist_negative"
        opposite_rsi = "rsi_overbought" if bias == "bullish" else "rsi_oversold"
        candle_confirm = (
            {"bullish_engulfing", "morning_star", "pin_bar_bullish", "hammer"}
            if bias == "bullish"
            else {"bearish_engulfing", "evening_star", "pin_bar_bearish", "shooting_star"}
        )
        if direction_signal in m5_signals and opposite_rsi not in m5_signals and (
            "volume_spike" in m5_signals or bool(candle_confirm.intersection(m5_signals))
        ):
            return by_key["scalping_m5"]

    # Public order-book depth and taker flow must agree with each other and
    # the higher-timeframe bias before the microstructure strategy is selectable.
    if "liquidity_orderflow" in by_key and isinstance(microstructure_analysis, dict):
        liquidity = microstructure_analysis.get("liquidity") or {}
        order_flow = microstructure_analysis.get("order_flow") or {}
        if not isinstance(liquidity, dict):
            liquidity = {}
        if not isinstance(order_flow, dict):
            order_flow = {}
        expected_source = (
            "binance_futures_public_read_only" if market == MarketType.FUTURES
            else "binance_public_read_only"
        )
        normalize_symbol = lambda value: "".join(
            character for character in str(value or "").upper() if character.isalnum()
        )
        liquidity_symbol = normalize_symbol(liquidity.get("symbol"))
        flow_symbol = normalize_symbol(order_flow.get("symbol"))
        requested_symbol = normalize_symbol(expected_symbol) if expected_symbol else None
        symbols_match = bool(liquidity_symbol) and liquidity_symbol == flow_symbol
        if requested_symbol is not None:
            symbols_match = symbols_match and liquidity_symbol == requested_symbol
        if (liquidity.get("ok") is True and order_flow.get("ok") is True
                and liquidity.get("source") == expected_source
                and order_flow.get("source") == expected_source
                and symbols_match):
            try:
                # Never let an old REST snapshot authorize a current strategy.
                # The order-book and aggregate-trade windows must both be fresh
                # and temporally coherent; missing timestamps fail closed.
                now = datetime.now(timezone.utc)
                book_time = datetime.fromisoformat(
                    str(liquidity["fetched_at"]).replace("Z", "+00:00")
                )
                first_trade_time = datetime.fromisoformat(
                    str(order_flow["first_trade_time"]).replace("Z", "+00:00")
                )
                last_trade_time = datetime.fromisoformat(
                    str(order_flow["last_trade_time"]).replace("Z", "+00:00")
                )
                if any(stamp.tzinfo is None for stamp in (book_time, first_trade_time, last_trade_time)):
                    raise ValueError("microstructure_timestamps_must_be_timezone_aware")
                ages = [(now - stamp).total_seconds() for stamp in (book_time, last_trade_time)]
                if (any(age < -5 or age > 120 for age in ages)
                        or first_trade_time > last_trade_time
                        or (last_trade_time - first_trade_time).total_seconds() > 120
                        or abs((book_time - last_trade_time).total_seconds()) > 120):
                    raise ValueError("stale_or_incoherent_microstructure_evidence")
                raw_metrics = (
                    liquidity["spread_percent"], liquidity["depth_imbalance"],
                    order_flow["taker_flow_imbalance"],
                )
                if any(isinstance(value, bool) for value in raw_metrics):
                    raise ValueError("boolean_microstructure_metric")
                spread, depth_imbalance, flow_imbalance = (
                    float(value) for value in raw_metrics
                )
                metrics_valid = all(
                    math.isfinite(value) for value in (spread, depth_imbalance, flow_imbalance)
                )
            except (KeyError, TypeError, ValueError, OverflowError):
                metrics_valid = False
            if (metrics_valid and 0 <= spread <= 0.20
                    and -1.0 <= depth_imbalance <= 1.0
                    and -1.0 <= flow_imbalance <= 1.0):
                if (bias == "bullish" and depth_imbalance >= 0.15 and flow_imbalance >= 0.15):
                    return by_key["liquidity_orderflow"]
                if (bias == "bearish" and depth_imbalance <= -0.15 and flow_imbalance <= -0.15):
                    return by_key["liquidity_orderflow"]

    # Swing entries need H1/H4 agreement and no opposing daily trend.
    if ("swing_h1_h4" in by_key and bias in {"bullish", "bearish"} and h4 and h1
            and h4.trend == bias and h1.trend == bias
            and (m15 is None or m15.trend == bias)):
        daily_ok = d1 is None or d1.trend in {bias, "sideways"}
        direction_signal = "macd_hist_positive" if bias == "bullish" else "macd_hist_negative"
        if daily_ok and direction_signal in set(h4.signals or []) and direction_signal in set(h1.signals or []):
            return by_key["swing_h1_h4"]

    structural_source = (m15, m5) if timeframe_analyses is not None else ()
    structural_pool = (
        [signal for analysis in structural_source if analysis is not None for signal in (analysis.signals or [])]
        if timeframe_analyses is not None else list(signal_set)
    )
    structural_signals = [
        str(signal).lower() for signal in structural_pool
        if "breakout" in str(signal).lower()
        or str(signal).lower().startswith(("bos_", "choch_"))
    ]
    if structural_signals:
        direction_matches = bias in {"bullish", "bearish"} and all(
            signal.endswith(bias) or signal == "breakout"
            for signal in structural_signals
        )
        if direction_matches:
            return by_key.get("breakout_structure", {
                "key": "none", "name": "No active strategy", "category": "none",
                "markets": [market.value], "status": "no_matching_implementation",
            })
        return {
            "key": "none", "name": "No strategy selected", "category": "none",
            "markets": [market.value], "status": "structural_signal_conflicts_with_higher_timeframe_bias",
        }
    if (
        ("rsi_oversold" in signal_set and "bollinger_lower_band_touch" in signal_set)
        or ("rsi_overbought" in signal_set and "bollinger_upper_band_touch" in signal_set)
    ):
        return by_key.get("mean_reversion_bbands", {
            "key": "none", "name": "No active strategy", "category": "none",
            "markets": [market.value], "status": "no_matching_implementation",
        })
    if bias in {"bullish", "bearish"} and (
        "price_above_ema20_ema50" in signal_set
        or "price_below_ema20_ema50" in signal_set
    ):
        return by_key.get("trend_following_ema", {
            "key": "none", "name": "No active strategy", "category": "none",
            "markets": [market.value], "status": "no_matching_implementation",
        })
    if "macd_hist_positive" in signal_set or "macd_hist_negative" in signal_set:
        return by_key.get("momentum_macd_rsi", {
            "key": "none", "name": "No active strategy", "category": "none",
            "markets": [market.value], "status": "no_matching_implementation",
        })
    return {
        "key": "none",
        "name": "No strategy selected",
        "category": "none",
        "markets": [market.value],
        "status": "no_confirmed_strategy_signal",
    }
