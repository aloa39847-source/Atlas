from enum import Enum


class EnvironmentMode(str, Enum):
    DEMO = "demo"
    LIVE = "live"


class MarketType(str, Enum):
    SPOT = "spot"
    FUTURES = "futures"
    EARN = "earn"


class DecisionAction(str, Enum):
    BUY = "buy"
    SELL = "sell"
    LONG = "long"
    SHORT = "short"
    WAIT = "wait"


class EngineStatus(str, Enum):
    NOT_IMPLEMENTED = "not_implemented"
    IMPLEMENTED_PARTIAL = "implemented_partial"
    READY = "ready"
    NEEDS_EXTERNAL_SERVICE = "needs_external_service"
    ERROR = "error"
    DISABLED = "disabled"


class OrderStatus(str, Enum):
    PENDING = "pending"
    SUBMITTED = "submitted"
    PARTIALLY_FILLED = "partially_filled"
    FILLED = "filled"
    CANCELLED = "cancelled"
    REJECTED = "rejected"
    FAILED = "failed"


class DataSourceKind(str, Enum):
    SYNTHETIC_LABELED = "synthetic_labeled"  # Never present as live market data
    HISTORICAL = "historical"
    LIVE_PUBLIC = "live_public"
    LIVE_PRIVATE = "live_private"
    NEWS = "news"
    MANUAL = "manual"
    TEST = "test"


class Timeframe(str, Enum):
    D1 = "1d"
    H4 = "4h"
    H1 = "1h"
    M15 = "15m"
    M5 = "5m"
