from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request
from pydantic import BaseModel, Field
from sqlalchemy import desc, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.enums import EnvironmentMode, MarketType
from app.models.db import get_db
from app.models.entities import AIProviderConfig, AuditLog, ConfigChange, DecisionRecord, KnowledgeSource, LearningRecord
from app.services import auth_service
from app.integrations.ai_providers import SUPPORTED_PROVIDERS, invoke_provider, list_configs, record_usage
from app.services.core_service import core_service
from app.engines.arbitrage import ArbitrageAnalysisEngine

router = APIRouter()


class StateUpdate(BaseModel):
    environment_mode: str | None = Field(None, description="demo|live (live blocked unless explicitly enabled in config)")
    market_type: str | None = Field(None, description="spot|futures|earn")
    autonomous_enabled: bool | None = None
    emergency_stop: bool | None = None


class AnalyzeRequest(BaseModel):
    symbol: str = Field(..., example="BTC/USDT")
    market_type: str = Field("spot")
    environment_mode: str = Field("demo")
    balance: float = Field(1000.0, gt=0)
    max_leverage: float = Field(3.0, ge=1)
    risk_per_trade: float = Field(0.01, gt=0, le=0.1)
    data_source: str = Field("synthetic", description="synthetic or binance_public (read-only)")


class ArbitrageRequest(BaseModel):
    route: list[str] = Field(..., min_length=4, max_length=4, example=["USDT", "BTC", "ETH", "USDT"])
    starting_amount: float = Field(1000.0, gt=0)
    fee_rate: float = Field(0.001, ge=0, lt=1)
    slippage_rate: float = Field(0.0005, ge=0, lt=1)
    min_profit_pct: float = Field(0.05, ge=0)


class KnowledgeCreate(BaseModel):
    title: str
    source_type: str = "manual"
    url: str | None = None
    reliability_score: float | None = Field(None, ge=0, le=1)
    verified: bool = False
    notes: str = ""


class LearningCreate(BaseModel):
    category: str
    subject: str
    lesson: str = ""
    outcome: str | None = None
    environment_mode: str | None = None
    market_type: str | None = None
    verified: bool = False


@router.get("/health")
def health() -> dict[str, Any]:
    return {"ok": True, "service": "titan-ai-premium", "version": "0.1.0-foundation"}


@router.get("/system/status")
def system_status(db: Session = Depends(get_db)) -> dict[str, Any]:
    return {
        "state": core_service.get_state(db),
        "engines": core_service.engines(db),
        "integrations": {
            "binance": {"status": "needs_external_service", "configured": False, "note": "Configure Demo/Testnet first. No withdrawal/transfer permissions."},
            "telegram": {"status": "needs_external_service", "configured": False, "note": "Bot token required; protect secrets."},
            "ai_providers": {"status": "needs_external_service", "configured": False, "note": "Optional; trading decisions must remain grounded in data/risk engines."},
        },
        "data_policy": {"live_market_data": False, "synthetic_labeled_available": True, "note": "UI/API must never present synthetic data as real market data."},
    }


@router.post("/system/state")
def update_state(payload: StateUpdate, db: Session = Depends(get_db), _user=Depends(get_current_user)) -> dict[str, Any]:
    try:
        return core_service.set_state(
            db,
            environment_mode=payload.environment_mode,
            market_type=payload.market_type,
            autonomous_enabled=payload.autonomous_enabled,
            emergency_stop=payload.emergency_stop,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.get("/strategies")
def strategies() -> dict[str, Any]:
    return {"strategies": core_service.strategies(), "note": "Registry is extensible; statuses reflect current implementation/integration state."}


@router.post("/analysis/arbitrage")
def analyze_arbitrage(payload: ArbitrageRequest, _user=Depends(get_current_user)) -> dict[str, Any]:
    return ArbitrageAnalysisEngine().fetch_and_analyze(
        payload.route,
        starting_amount=payload.starting_amount,
        fee_rate=payload.fee_rate,
        slippage_rate=payload.slippage_rate,
        min_profit_pct=payload.min_profit_pct,
    )


@router.post("/analysis/decision")
def analyze(payload: AnalyzeRequest, db: Session = Depends(get_db), _user=Depends(get_current_user)) -> dict[str, Any]:
    try:
        return core_service.analyze(
            db,
            symbol=payload.symbol,
            market_type=payload.market_type,
            environment_mode=payload.environment_mode,
            balance=payload.balance,
            max_leverage=payload.max_leverage,
            risk_per_trade=payload.risk_per_trade,
            data_source=payload.data_source,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.get("/decisions")
def list_decisions(limit: int = Query(50, ge=1, le=200), db: Session = Depends(get_db)) -> dict[str, Any]:
    rows = db.execute(select(DecisionRecord).order_by(desc(DecisionRecord.id)).limit(limit)).scalars().all()
    return {"items": [
        {"id": r.id, "created_at": r.created_at.isoformat(), "symbol": r.symbol, "action": r.action, "strategy": r.strategy,
         "confidence": r.confidence, "environment_mode": r.environment_mode, "market_type": r.market_type,
         "data_source": r.data_source, "reason": r.rationale}
        for r in rows
    ]}


@router.get("/audit")
def list_audit(limit: int = Query(100, ge=1, le=500), db: Session = Depends(get_db)) -> dict[str, Any]:
    rows = db.execute(select(AuditLog).order_by(desc(AuditLog.id)).limit(limit)).scalars().all()
    return {"items": [
        {"id": r.id, "created_at": r.created_at.isoformat(), "action": r.action, "severity": r.severity,
         "message": r.message, "environment_mode": r.environment_mode, "market_type": r.market_type, "details": r.details}
        for r in rows
    ]}


@router.get("/knowledge")
def list_knowledge(db: Session = Depends(get_db)) -> dict[str, Any]:
    rows = db.execute(select(KnowledgeSource).order_by(desc(KnowledgeSource.id)).limit(200)).scalars().all()
    return {"items": [{"id": r.id, "title": r.title, "source_type": r.source_type, "url": r.url, "reliability_score": r.reliability_score, "verified": r.verified, "notes": r.notes} for r in rows]}


@router.post("/knowledge")
def add_knowledge(payload: KnowledgeCreate, db: Session = Depends(get_db), _user=Depends(get_current_user)) -> dict[str, Any]:
    r = KnowledgeSource(title=payload.title, source_type=payload.source_type, url=payload.url, reliability_score=payload.reliability_score, verified=payload.verified, notes=payload.notes)
    db.add(r); db.commit(); db.refresh(r)
    return {"id": r.id, "title": r.title}


@router.get("/learning")
def list_learning(db: Session = Depends(get_db)) -> dict[str, Any]:
    rows = db.execute(select(LearningRecord).order_by(desc(LearningRecord.id)).limit(200)).scalars().all()
    return {"items": [{"id": r.id, "category": r.category, "subject": r.subject, "outcome": r.outcome, "lesson": r.lesson, "verified": r.verified, "environment_mode": r.environment_mode, "market_type": r.market_type} for r in rows]}


@router.post("/learning")
def add_learning(payload: LearningCreate, db: Session = Depends(get_db), _user=Depends(get_current_user)) -> dict[str, Any]:
    r = LearningRecord(category=payload.category, subject=payload.subject, lesson=payload.lesson, outcome=payload.outcome, environment_mode=payload.environment_mode, market_type=payload.market_type, verified=payload.verified)
    db.add(r); db.commit(); db.refresh(r)
    return {"id": r.id, "subject": r.subject}


# --- Auth (private access) ---

class LoginRequest(BaseModel):
    email: str
    password: str


def _bearer(authorization: str | None) -> str | None:
    if not authorization:
        return None
    if authorization.lower().startswith("bearer "):
        return authorization[7:].strip()
    return authorization.strip()


def get_current_user(request: Request, db: Session = Depends(get_db), authorization: str | None = Header(default=None)):
    token = _bearer(authorization) or request.cookies.get("titan_session")
    user = auth_service.get_session_user(db, token)
    if settings.auth_required and not user:
        raise HTTPException(status_code=401, detail="Authentication required")
    return user


@router.get("/auth/status")
def auth_status(db: Session = Depends(get_db)):
    from app.models.entities import AppUser
    has_user = db.execute(select(AppUser.id).limit(1)).first() is not None
    return {
        "auth_required": settings.auth_required,
        "allowlist_configured": bool(auth_service.get_allowed_emails()) or bool(settings.allowed_emails),
        "has_user": has_user,
        "note": "Set initial password locally with backend script. Never send passwords in chat.",
    }


@router.post("/auth/login")
def login(payload: LoginRequest, request: Request, db: Session = Depends(get_db)):
    user = auth_service.authenticate(db, payload.email, payload.password)
    if not user:
        db.commit()
        raise HTTPException(status_code=401, detail="Invalid credentials, email not allowed, or account locked")
    token = auth_service.create_session(db, user, ttl_hours=settings.session_ttl_hours, ip_address=request.client.host if request.client else None, user_agent=request.headers.get("user-agent"))
    db.commit()
    return {"ok": True, "token": token, "email": user.email, "token_type": "bearer"}


@router.post("/auth/logout")
def logout(db: Session = Depends(get_db), authorization: str | None = Header(default=None)):
    token = _bearer(authorization)
    ok = auth_service.revoke_session(db, token) if token else False
    db.commit()
    return {"ok": ok}


@router.get("/auth/me")
def me(user=Depends(get_current_user)):
    if not user:
        return {"authenticated": False, "auth_required": settings.auth_required}
    return {"authenticated": True, "email": user.email, "is_admin": user.is_admin, "two_factor_enabled": user.two_factor_enabled}


@router.get("/config/changes")
def config_changes(limit: int = Query(100, ge=1, le=500), db: Session = Depends(get_db), _user=Depends(get_current_user)):
    rows = db.execute(select(ConfigChange).order_by(desc(ConfigChange.id)).limit(limit)).scalars().all()
    return {"items": [{"id": r.id, "created_at": r.created_at.isoformat(), "actor": r.actor, "scope": r.scope, "key": r.key, "approved": r.approved, "reason": r.reason, "old_value": r.old_value, "new_value": r.new_value} for r in rows]}


@router.get("/knowledge/concepts")
def knowledge_concepts(category: str | None = Query(None), q: str | None = Query(None)):
    from app.knowledge.base import categories, list_concepts
    return {"categories": categories(), "items": list_concepts(category=category, query=q)}


@router.get("/chat/context")
def chat_context(db: Session = Depends(get_db), _user=Depends(get_current_user)):
    # Grounded context for a system-aware assistant (no external LLM required).
    state = core_service.get_state(db)
    decisions = db.execute(select(DecisionRecord).order_by(desc(DecisionRecord.id)).limit(10)).scalars().all()
    audits = db.execute(select(AuditLog).order_by(desc(AuditLog.id)).limit(15)).scalars().all()
    return {
        "state": state,
        "recent_decisions": [{"id": d.id, "symbol": d.symbol, "action": d.action, "strategy": d.strategy, "confidence": d.confidence, "reason": d.rationale, "data_source": d.data_source, "created_at": d.created_at.isoformat()} for d in decisions],
        "recent_audit": [{"action": a.action, "severity": a.severity, "message": a.message, "created_at": a.created_at.isoformat()} for a in audits],
        "note": "This context is derived from real system records in this environment. No external LLM response is fabricated here.",
    }


class ChatRequest(BaseModel):
    message: str
    language: str | None = None


@router.post("/chat")
def chat(payload: ChatRequest, db: Session = Depends(get_db), _user=Depends(get_current_user)):
    # Grounded, rule-based assistant over TITAN system data (adapter-ready for external AI providers later).
    msg = (payload.message or "").strip()
    low = msg.lower()
    state = core_service.get_state(db)
    decisions = db.execute(select(DecisionRecord).order_by(desc(DecisionRecord.id)).limit(5)).scalars().all()
    from app.knowledge.base import list_concepts
    if not msg:
        return {"reply": "اكتب سؤالك عن حالة النظام، القرارات، الاستراتيجيات، المخاطر، أو التحليل.", "grounded": True}
    if any(k in low for k in ["حالة", "status", "يعمل", "متوقف", "demo", "live", "spot", "futures", "earn"]):
        reply = f"حالة النظام الحالية: البيئة={state['environment_mode']}، السوق={state['market_type']}، مستقل={state['autonomous_enabled']}، إيقاف طوارئ={state['emergency_stop']}. التحويل التلقائي Demo→Live معطل وصلاحيات السحب غير مدعومة."
    elif any(k in low for k in ["قرار", "decision", "لماذا", "why", "صفقة", "trade", "دخل", "enter"]):
        if decisions:
            d = decisions[0]
            reply = f"آخر قرار مسجل: {d.symbol} → {d.action} (استراتيجية: {d.strategy}, ثقة: {d.confidence}, مصدر بيانات: {d.data_source}). السبب: {d.rationale}"
        else:
            reply = "لا توجد قرارات مسجلة بعد. يمكنك تشغيل تحليل من Market Scanner."
    elif any(k in low for k in ["استرات", "strategy", "strategies"]):
        sts = core_service.strategies()
        reply = "الاستراتيجيات المسجلة: " + ", ".join([f"{s['name']}[{s['status']}]" for s in sts[:8]]) + ". الحالات تعكس التنفيذ/التكامل الحالي بصدق."
    elif any(k in low for k in ["مخاطر", "risk", "رافعة", "leverage", "رسوم", "fees"]):
        rl = state.get("risk_limits", {})
        reply = f"حدود الأمان الحالية (قبعات إعدادات): {rl}. Spot بلا رافعة؛ Futures تخضع لحدود الرافعة/المخاطر؛ الرسوم والانزلاق تقديرات قابلة للتحقق قبل التنفيذ الحقيقي."
    elif any(k in low for k in ["bos", "choch", "سيولة", "liquidity", "اختراق", "breakout", "شمعة", "candle", "rsi", "macd"]):
        concepts = list_concepts(query=msg)[:3]
        if concepts:
            reply = "مفاهيم ذات صلة من قاعدة المعرفة: " + " | ".join([f"{c['title']}: {c['summary']}" for c in concepts])
        else:
            reply = "يمكنني شرح مفاهيم التداول من قاعدة المعرفة، لكن لم أجد تطابقًا مباشرًا. جرّب: BOS, CHOCH, liquidity, breakout, RSI, MACD."
    elif any(k in low for k in ["افحص", "scan", "حلل", "analyze", "btc", "eth", "usdt"]):
        reply = "لتشغيل تحليل متعدد الأطر (1D/4H/1H/15M/5M) استخدم Market Scanner أو endpoint `api/analysis/decision`. في البناء الحالي البيانات Synthetic/Labeled ما لم يُربط مزود بيانات حقيقي."
    else:
        reply = "أنا مساعد TITAN مرتبط ببيانات النظام. اسألني عن: حالة النظام، آخر القرارات، الاستراتيجيات، المخاطر، أو مفاهيم مثل BOS/CHOCH/السيولة/الاختراق. (التكامل مع مزود LLM خارجي اختياري ويحتاج إعدادًا وآلية أمان.)"
    return {"reply": reply, "grounded": True, "used_external_llm": False, "state_snapshot": {"environment_mode": state["environment_mode"], "market_type": state["market_type"]}}


# --- AI Providers (multi-model, secure refs; no direct trade execution by LLM) ---

class AIProviderCreate(BaseModel):
    name: str
    provider: str
    model: str
    base_url: str | None = None
    api_key_ref: str | None = None  # e.g. env:OPENAI_API_KEY
    enabled: bool = False
    priority: int = 100
    tasks: list[str] | None = None
    daily_budget_usd: float | None = None
    monthly_budget_usd: float | None = None


@router.get("/ai/providers")
def ai_providers(db: Session = Depends(get_db), _user=Depends(get_current_user)):
    rows = list_configs(db)
    return {"supported_providers": sorted(SUPPORTED_PROVIDERS), "items": [
        {"id": r.id, "name": r.name, "provider": r.provider, "model": r.model, "base_url": r.base_url,
         "api_key_ref_set": bool(r.api_key_ref), "enabled": r.enabled, "priority": r.priority, "tasks": r.tasks or [],
         "daily_budget_usd": r.daily_budget_usd, "monthly_budget_usd": r.monthly_budget_usd}
        for r in rows
    ], "safety": "LLM outputs cannot execute trades directly; they must pass market/risk/execution engines. API keys are never logged."}


@router.post("/ai/providers")
def ai_provider_create(payload: AIProviderCreate, db: Session = Depends(get_db), _user=Depends(get_current_user)):
    if payload.provider not in SUPPORTED_PROVIDERS:
        raise HTTPException(status_code=400, detail=f"Unsupported provider. Supported: {sorted(SUPPORTED_PROVIDERS)}")
    row = AIProviderConfig(name=payload.name, provider=payload.provider, model=payload.model, base_url=payload.base_url,
                           api_key_ref=payload.api_key_ref, enabled=payload.enabled, priority=payload.priority,
                           tasks=payload.tasks or [], daily_budget_usd=payload.daily_budget_usd, monthly_budget_usd=payload.monthly_budget_usd)
    db.add(row); db.commit(); db.refresh(row)
    return {"id": row.id, "name": row.name, "enabled": row.enabled}


@router.post("/ai/providers/{provider_id}/test")
def ai_provider_test(provider_id: int, db: Session = Depends(get_db), _user=Depends(get_current_user)):
    cfg = db.get(AIProviderConfig, provider_id)
    if not cfg:
        raise HTTPException(status_code=404, detail="provider not found")
    result = invoke_provider(cfg, [{"role": "user", "content": "Reply with: TITAN_OK"}], task="test")
    record_usage(db, cfg, "test", result)
    db.commit()
    return result.to_dict()


@router.get("/ai/research")
def ai_research():
    # Retrieved during this session via web tools; verify current terms/pricing/access before relying on them.
    return {
        "checked_at_note": "Web lookups performed in-session; provider terms/pricing/availability change. Not live-tested without API keys.",
        "sources": [
            {"provider": "Anthropic", "urls": ["https://www.anthropic.com/legal/supported-regions", "https://platform.claude.com/docs/en/about-claude/pricing"], "algeria_note": "Retrieved supported-regions page listed Algeria; verify directly before use."},
            {"provider": "OpenAI", "urls": ["https://developers.openai.com/api/docs/supported-countries.md", "https://openai.com/api/pricing/"], "algeria_note": "Retrieved supported-countries markdown included Algeria; verify pricing/models/terms directly."},
            {"provider": "Google Gemini API", "urls": ["https://ai.google.dev/gemini-api/docs/available-regions", "https://ai.google.dev/gemini-api/docs/pricing"], "algeria_note": "Could not conclusively confirm Algeria from retrieved content; verify official available-regions page directly."},
            {"provider": "Mistral", "urls": ["https://mistral.ai/pricing", "https://docs.mistral.ai/getting-started/models/"], "algeria_note": "Verify API availability/terms for Algeria directly."},
            {"provider": "DeepSeek", "urls": ["https://api-docs.deepseek.com/quick_start/pricing"], "algeria_note": "Verify availability/terms for Algeria directly."},
            {"provider": "xAI", "urls": ["https://docs.x.ai/developers/models"], "algeria_note": "Verify availability/terms for Algeria directly."},
        ],
        "caveat": "Do not treat any model as connected or feature as working without valid credentials and successful tests. Trading decisions must remain grounded in market data, analysis, and risk engines.",
    }


# --- Compliance (Binance/policy safety gate) ---

@router.post("/compliance/check-order")
def compliance_check_order(payload: AnalyzeRequest, db: Session = Depends(get_db), _user=Depends(get_current_user)):
    # Reuses request shape for quick checks; real execution requires exchange adapter + reconciliation.
    from app.core.enums import MarketType
    g = PreTradeOrderGateway()
    r = g.validate(symbol=payload.symbol, market=MarketType(payload.market_type), side="buy", order_type="limit",
                   quantity=0.001, price=1.0, reference_price=1.0, environment_mode=payload.environment_mode,
                   live_enabled=False)
    from app.services.audit import log_event
    if not r.ok:
        log_event(db, action="compliance.block", severity="warning", message=r.reason, details=r.normalized,
                  environment_mode=payload.environment_mode, market_type=payload.market_type)
        db.commit()
    return {"gateway": r.to_dict(), "sources": ["https://www.binance.com/en/terms", "https://www.binance.com/en/terms-api", "https://developers.binance.com/"],
            "note": "Software precheck only. Verify current official Binance terms/policies, account eligibility, KYC, geo restrictions, symbol filters, and API limits before any live operation."}
