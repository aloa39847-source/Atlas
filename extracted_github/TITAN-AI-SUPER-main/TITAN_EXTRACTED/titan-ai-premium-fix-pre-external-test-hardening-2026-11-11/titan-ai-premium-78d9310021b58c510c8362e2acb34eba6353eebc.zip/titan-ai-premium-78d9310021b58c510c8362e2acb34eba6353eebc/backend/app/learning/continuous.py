"""Continuous learning proposals with auditable, reversible strategy versions.

This module is an in-memory research/paper-learning component. It never applies
parameters to a live trading engine and never authorizes exchange execution.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import math
from typing import Any


class StrategyVersion:
    def __init__(self, strategy_key: str, version: int, params: dict, metrics: dict):
        self.strategy_key = strategy_key
        self.version = version
        self.params = deepcopy(params)
        self.metrics = deepcopy(metrics)
        self.created_at = datetime.now(timezone.utc).isoformat()
        self.approved_for_live = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "strategy_key": self.strategy_key,
            "version": self.version,
            "params": deepcopy(self.params),
            "metrics": deepcopy(self.metrics),
            "created_at": self.created_at,
            "approved_for_live": self.approved_for_live,
        }


class ContinuousLearningSystem:
    def __init__(self):
        self.versions: dict[str, list[StrategyVersion]] = {}
        self.active_versions: dict[str, int] = {}
        self.proposals: list[dict[str, Any]] = []
        self.audit_log: list[dict[str, Any]] = []

    def register_version(
        self,
        strategy_key: str,
        params: dict[str, Any],
        metrics: dict[str, Any],
        *,
        make_active: bool = False,
        explicit_approval: bool = False,
    ) -> dict[str, Any]:
        key = str(strategy_key or "").strip()
        if not key or not isinstance(params, dict) or not isinstance(metrics, dict):
            return {"ok": False, "error": "strategy_key_params_and_metrics_required"}
        if make_active and explicit_approval is not True:
            return {"ok": False, "error": "explicit_approval_required_to_activate_paper_version"}
        history = self.versions.setdefault(key, [])
        version = StrategyVersion(key, len(history) + 1, params, metrics)
        history.append(version)
        if make_active:
            self.active_versions[key] = version.version
        self.audit_log.append({
            "action": "strategy_version_registered",
            "strategy_key": key,
            "version": version.version,
            "active_version": self.active_versions.get(key),
            "ts": version.created_at,
        })
        return {
            "ok": True, "version": version.to_dict(),
            "active_version": self.active_versions.get(key),
            "active": self.active_versions.get(key) == version.version,
        }

    def get_active_version(self, strategy_key: str) -> dict[str, Any]:
        key = str(strategy_key or "").strip()
        active = self.active_versions.get(key)
        version = next((v for v in self.versions.get(key, []) if v.version == active), None)
        if version is None:
            return {"ok": False, "error": "active_strategy_version_not_found"}
        return {"ok": True, "version": version.to_dict()}

    def list_versions(self, strategy_key: str) -> list[dict[str, Any]]:
        return [version.to_dict() for version in self.versions.get(strategy_key, [])]

    def propose_improvement(
        self,
        strategy_key: str,
        current_params: dict,
        proposed_params: dict,
        rationale: str,
        metrics_before: dict,
    ) -> dict[str, Any]:
        if not strategy_key or not isinstance(current_params, dict) or not isinstance(proposed_params, dict) or not isinstance(metrics_before, dict) or not str(rationale).strip():
            return {"ok": False, "error": "valid_strategy_params_rationale_and_metrics_required"}
        proposal = {
            "id": len(self.proposals) + 1,
            "strategy_key": strategy_key,
            "current_params": deepcopy(current_params),
            "proposed_params": deepcopy(proposed_params),
            "rationale": str(rationale).strip(),
            "metrics_before": deepcopy(metrics_before),
            "status": "proposed",
            "tested": False,
            "test_passed": False,
            "approved_for_live": False,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        self.proposals.append(proposal)
        self.audit_log.append({"action": "proposal_created", "proposal_id": proposal["id"], "ts": proposal["created_at"]})
        return deepcopy(proposal)

    def test_proposal(self, proposal_id: int, metrics_after_paper: dict) -> dict[str, Any]:
        for proposal in self.proposals:
            if proposal["id"] == proposal_id:
                # A new test attempt invalidates any earlier pass/approval until it
                # has been revalidated. Invalid input must never leave stale success.
                proposal["tested"] = False
                proposal["test_passed"] = False
                proposal["approved_for_live"] = False
                proposal.pop("metrics_after_paper", None)
                proposal["status"] = "paper_test_invalid"
                metrics_before = proposal.get("metrics_before")
                if (not isinstance(metrics_before, dict) or not isinstance(metrics_after_paper, dict)
                        or "expectancy" not in metrics_after_paper):
                    return {"ok": False, "error": "paper_metrics_with_expectancy_required"}
                if any(isinstance(metrics.get(key), bool) for metrics in (
                    metrics_before, metrics_after_paper,
                ) for key in ("expectancy", "max_drawdown")):
                    return {"ok": False, "error": "boolean_paper_metric_not_allowed"}
                try:
                    before = float(metrics_before.get("expectancy", 0.0))
                    after = float(metrics_after_paper.get("expectancy", 0.0))
                    before_dd = float(metrics_before.get("max_drawdown", 0.0))
                    after_dd = float(metrics_after_paper.get("max_drawdown", before_dd))
                except (TypeError, ValueError, OverflowError):
                    return {"ok": False, "error": "invalid_paper_metrics"}
                numeric_metrics = (before, after, before_dd, after_dd)
                if not all(math.isfinite(value) for value in numeric_metrics):
                    return {"ok": False, "error": "non_finite_paper_metrics"}
                if before_dd < 0 or after_dd < 0:
                    return {"ok": False, "error": "negative_drawdown_not_allowed"}
                proposal["tested"] = True
                proposal["metrics_after_paper"] = deepcopy(metrics_after_paper)
                proposal["test_passed"] = after > before and after_dd <= before_dd
                proposal["status"] = "paper_test_passed" if proposal["test_passed"] else "paper_test_failed"
                self.audit_log.append({
                    "action": "proposal_tested",
                    "proposal_id": proposal_id,
                    "passed": proposal["test_passed"],
                    "ts": datetime.now(timezone.utc).isoformat(),
                })
                return deepcopy(proposal)
        return {"ok": False, "error": "not_found"}

    def approve_for_live(self, proposal_id: int, explicit_approval: bool = False) -> dict[str, Any]:
        if explicit_approval is not True:
            return {"ok": False, "error": "explicit_approval_required", "note": "Changes cannot be applied to live without explicit approval"}
        for proposal in self.proposals:
            if proposal["id"] == proposal_id:
                if not proposal.get("tested") or not proposal.get("test_passed"):
                    return {"ok": False, "error": "successful_paper_test_required"}
                proposal["approved_for_live"] = True
                proposal["status"] = "approved_pending_separate_live_integration"
                self.audit_log.append({
                    "action": "approved_for_live",
                    "proposal_id": proposal_id,
                    "explicit": True,
                    "ts": datetime.now(timezone.utc).isoformat(),
                })
                return {"ok": True, "proposal_id": proposal_id, "applied": False}
        return {"ok": False, "error": "not_found"}

    def apply_proposal_to_paper(
        self, proposal_id: int, *, explicit_approval: bool = False,
    ) -> dict[str, Any]:
        if explicit_approval is not True:
            return {"ok": False, "error": "explicit_approval_required"}
        for proposal in self.proposals:
            if proposal["id"] != proposal_id:
                continue
            if proposal.get("applied_to_paper") is True:
                return {"ok": False, "error": "proposal_already_applied_to_paper"}
            if not proposal.get("tested") or not proposal.get("test_passed"):
                return {"ok": False, "error": "successful_paper_test_required"}
            metrics = proposal.get("metrics_after_paper") or {}
            created = self.register_version(
                proposal["strategy_key"], proposal["proposed_params"], metrics,
                make_active=True, explicit_approval=True,
            )
            if not created.get("ok"):
                return created
            proposal["applied_to_paper"] = True
            proposal["status"] = "applied_to_paper_version_store"
            proposal["applied_version"] = created["version"]["version"]
            self.audit_log.append({
                "action": "proposal_applied_to_paper",
                "proposal_id": proposal_id,
                "version": proposal["applied_version"],
                "ts": datetime.now(timezone.utc).isoformat(),
            })
            return {"ok": True, "proposal_id": proposal_id, "version": created["version"], "live_applied": False}
        return {"ok": False, "error": "not_found"}

    def rollback(
        self, strategy_key: str, to_version: int, *, explicit_approval: bool = False,
    ) -> dict[str, Any]:
        if explicit_approval is not True:
            return {"ok": False, "error": "explicit_approval_required"}
        key = str(strategy_key or "").strip()
        version = next((v for v in self.versions.get(key, []) if v.version == to_version), None)
        if version is None:
            return {"ok": False, "error": "strategy_version_not_found", "strategy_key": key, "requested_version": to_version}
        previous = self.active_versions.get(key)
        self.active_versions[key] = version.version
        self.audit_log.append({
            "action": "strategy_version_rollback",
            "strategy_key": key,
            "from_version": previous,
            "to_version": version.version,
            "ts": datetime.now(timezone.utc).isoformat(),
        })
        return {
            "ok": True,
            "strategy_key": key,
            "active_version": version.version,
            "params": deepcopy(version.params),
            "metrics": deepcopy(version.metrics),
            "in_memory_only": True,
            "note": "Version pointer restored in this process only; no live strategy or exchange configuration was changed.",
        }

    def export_state(self) -> dict[str, Any]:
        """Return a JSON-serializable snapshot for a future durable store."""
        return {
            "versions": {key: [version.to_dict() for version in rows] for key, rows in self.versions.items()},
            "active_versions": deepcopy(self.active_versions),
            "proposals": deepcopy(self.proposals),
            "audit_log": deepcopy(self.audit_log),
        }
