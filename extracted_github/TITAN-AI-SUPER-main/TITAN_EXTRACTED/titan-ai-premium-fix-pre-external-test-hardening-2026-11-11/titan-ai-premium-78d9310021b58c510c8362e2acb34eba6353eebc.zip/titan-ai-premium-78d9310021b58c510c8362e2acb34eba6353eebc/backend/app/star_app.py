from __future__ import annotations

import json
import math
import os
from pathlib import Path
from typing import Any

from starlette.applications import Starlette
from starlette.middleware.cors import CORSMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, HTMLResponse, FileResponse
from starlette.routing import Route

from app.core.config import settings
from app.core.enums import MarketType, Timeframe
from app.engines.compliance import compliance_engine
from app.engines.order_gateway import PreTradeOrderGateway
from app.integrations.ai_providers import SUPPORTED_PROVIDERS, invoke_provider, list_configs, record_usage
from app.integrations.binance_adapter import BinanceTestnetAdapter, BinanceConfig
from app.services.credentials import save_testnet_credentials, load_testnet_credentials, delete_testnet_credentials, public_status as creds_public_status
from app.models import db as dbmod
from app.models.entities import AIProviderConfig, AuditLog, ConfigChange, DecisionRecord, KnowledgeSource, LearningRecord, OrderRecord, PositionRecord
from app.services import auth_service
from app.services.audit import log_event
from app.services.core_service import core_service
from app.services.shadow_trading import ShadowTradingService
from app.services.self_diagnosis import get_engine
from sqlalchemy import desc, select
from fastapi.encoders import jsonable_encoder


def J(data: Any, status: int = 200) -> JSONResponse:
    return JSONResponse(jsonable_encoder(data), status_code=status)


async def body(request: Request) -> dict:
    try:
        raw = await request.body()
        return json.loads(raw.decode("utf-8")) if raw else {}
    except Exception:
        return {}


def db_sess():
    return dbmod.SessionLocal()


def _bearer(request: Request) -> str | None:
    a = request.headers.get("authorization")
    if a and a.lower().startswith("bearer "):
        return a[7:].strip()
    return request.cookies.get("titan_session")


def require_user(request: Request, db):
    token = _bearer(request)
    user = auth_service.get_session_user(db, token)
    if (settings.auth_required or auth_service.auth_required()) and not user:
        return None, J({"detail": "Authentication required"}, 401)
    return user, None


def _binance_auth_error(request: Request):
    """Always require a valid user session for private Binance Testnet endpoints."""
    db = db_sess()
    try:
        user = auth_service.get_session_user(db, _bearer(request))
        if not user:
            return J({"detail": "Authentication required"}, 401)
        return None
    finally:
        db.close()


async def health(request: Request):
    return J({"ok": True, "service": "titan-ai-premium", "version": "0.1.0-foundation", "http_stack": "starlette"})


async def system_status(request: Request):
    db = db_sess()
    try:
        # This endpoint may query the authenticated Testnet account status.
        # Do not let anonymous callers trigger private credential use or infer account connectivity.
        user, err = require_user(request, db)
        if err:
            return err
        binance_status = {"status": "needs_external_service", "configured": False}
        try:
            binance_status = _get_binance_adapter('spot').status()
        except Exception:
            pass
        return J({
            "state": core_service.get_state(db),
            "engines": core_service.engines(db),
            "integrations": {
                "binance_public": {"status": "ready", "configured": True, "note": "Read-only public data"},
                "binance_testnet": binance_status,
                "binance_live": {"status": "disabled", "configured": False, "note": "Live trading disabled. No real keys."},
                "telegram": _telegram_adapter().status(),
                "coingecko_public": {"status": "ready", "configured": True, "note": "Public tokenomics/market metadata; rate limits apply."},
                "crypto_news_rss": {"status": "partial", "configured": True, "note": "Allowlisted public RSS feeds; source coverage may vary."},
                "ai_providers": {"status": "needs_external_service", "configured": False},
            },
            "demo_worker": __import__("app.services.demo_worker_supervisor", fromlist=["demo_worker_supervisor"]).demo_worker_supervisor.status(),
            "data_policy": {"live_market_data": False, "synthetic_labeled_available": True, "binance_public_available": True, "note": "Distinguish clearly: public read-only vs testnet demo vs live (disabled)."},
        })
    finally:
        db.close()


async def update_state(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        return J(core_service.set_state(db, environment_mode=p.get("environment_mode"), market_type=p.get("market_type"),
                                        autonomous_enabled=p.get("autonomous_enabled"), emergency_stop=p.get("emergency_stop")))
    except ValueError as e:
        return J({"detail": str(e)}, 400)
    finally:
        db.close()


async def scanner_spot(request: Request):
    """Read-only liquid USDT Spot market discovery endpoint."""
    try:
        max_symbols = int(request.query_params.get("limit", "50"))
        min_volume = float(request.query_params.get("min_quote_volume_usdt", "1000000"))
        if not 1 <= max_symbols <= 100 or min_volume < 0:
            return J({"ok": False, "error": "invalid_scanner_parameters",
                      "limits": {"limit": "1..100", "min_quote_volume_usdt": ">=0"}}, 400)
        return J(core_service.market_data.scan_spot_universe(
            max_symbols=max_symbols, min_quote_volume_usdt=min_volume,
        ))
    except (TypeError, ValueError):
        return J({"ok": False, "error": "invalid_scanner_parameters"}, 400)
    except Exception as e:
        return J({"ok": False, "error": "scanner_data_unavailable", "detail": str(e)}, 503)


async def scanner_futures(request: Request):
    """Read-only liquid active USDT perpetual discovery endpoint."""
    try:
        max_symbols = int(request.query_params.get("limit", "50"))
        min_volume = float(request.query_params.get("min_quote_volume_usdt", "10000000"))
        if not 1 <= max_symbols <= 100 or not math.isfinite(min_volume) or min_volume < 0:
            return J({"ok": False, "error": "invalid_futures_scanner_parameters",
                      "limits": {"limit": "1..100", "min_quote_volume_usdt": ">=0"}}, 400)
        return J(core_service.market_data.scan_futures_universe(
            max_symbols=max_symbols, min_quote_volume_usdt=min_volume,
        ))
    except (TypeError, ValueError):
        return J({"ok": False, "error": "invalid_futures_scanner_parameters"}, 400)
    except Exception as exc:
        return J({"ok": False, "error": "futures_scanner_data_unavailable", "detail": str(exc)[:240]}, 503)


async def smart_scanner_futures(request: Request):
    """Analyze a bounded USD-M perpetual shortlist; analysis only, no orders."""
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err:
            return err
        selected_state = core_service.get_state(db)
        if selected_state.get("environment_mode") != "demo" or selected_state.get("market_type") != "futures":
            return J({"ok": False, "error": "demo_futures_market_must_be_selected"}, 409)
        from app.services.smart_futures_scanner import SmartFuturesScannerService
        max_candidates = int(request.query_params.get("limit", "10"))
        min_volume = float(request.query_params.get("min_quote_volume_usdt", "10000000"))
        balance = float(request.query_params.get("balance", "150"))
        risk_per_trade = float(request.query_params.get("risk_per_trade", "0.005"))
        max_leverage = float(request.query_params.get("max_leverage", "10"))
        result = SmartFuturesScannerService().scan(
            db, max_candidates=max_candidates, min_quote_volume_usdt=min_volume,
            balance=balance, risk_per_trade=risk_per_trade, max_leverage=max_leverage,
        )
        return J(result)
    except (TypeError, ValueError) as exc:
        return J({"ok": False, "error": "invalid_futures_smart_scanner_parameters", "detail": str(exc)}, 400)
    except Exception as exc:
        return J({"ok": False, "error": "futures_smart_scanner_failed", "detail": str(exc)[:240]}, 503)
    finally:
        db.close()


async def smart_scanner(request: Request):
    """Analyze a bounded Spot USDT shortlist with public candles and existing decision logic."""
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err:
            return err
        from app.services.smart_scanner import SmartScannerService
        max_candidates = int(request.query_params.get("limit", "10"))
        min_volume = float(request.query_params.get("min_quote_volume_usdt", "1000000"))
        balance = float(request.query_params.get("balance", "150"))
        risk_per_trade = float(request.query_params.get("risk_per_trade", "0.005"))
        result = SmartScannerService().scan(
            db,
            max_candidates=max_candidates,
            min_quote_volume_usdt=min_volume,
            balance=balance,
            risk_per_trade=risk_per_trade,
        )
        return J(result)
    except (TypeError, ValueError) as e:
        return J({"ok": False, "error": "invalid_smart_scanner_parameters", "detail": str(e)}, 400)
    except Exception as e:
        db.rollback()
        return J({"ok": False, "error": "smart_scanner_unavailable", "detail": str(e)}, 503)
    finally:
        db.close()


def _ml_timeframe_batch(symbol: str, timeframe_value: str):
    timeframe = Timeframe(timeframe_value)
    batches = core_service.market_data.get_public_multi_timeframe(symbol)
    batch = batches.get(timeframe)
    if batch is None or getattr(batch.source, "value", None) != "live_public" or len(batch.df) < 50:
        raise ValueError("verified_public_candles_required")
    last = batch.df.rows[-1]
    stamp = last.get("close_time") or last.get("timestamp")
    if not isinstance(stamp, (int, float)):
        raise ValueError("public_candle_timestamp_required")
    age = __import__("time").time() - float(stamp) / 1000.0
    duration = {
        Timeframe.D1: 86400, Timeframe.H4: 14400, Timeframe.H1: 3600,
        Timeframe.M15: 900, Timeframe.M5: 300,
    }[timeframe]
    if age < -60 or age > max(300, duration * 2):
        raise ValueError("stale_public_candles")
    return timeframe, batch


def _ml_drift_timeframe_batch(symbol: str, timeframe_value: str):
    timeframe = Timeframe(timeframe_value)
    batch = core_service.market_data.get_public_candles(
        symbol, timeframe, limit=600, market_type="spot",
    )
    if batch is None or getattr(batch.source, "value", None) != "live_public" or len(batch.df) < 50:
        raise ValueError("verified_public_candles_required")
    last = batch.df.rows[-1]
    stamp = last.get("close_time") or last.get("timestamp")
    if not isinstance(stamp, (int, float)) or isinstance(stamp, bool):
        raise ValueError("public_candle_timestamp_required")
    age = __import__("time").time() - float(stamp) / 1000.0
    duration = {
        Timeframe.D1: 86400, Timeframe.H4: 14400, Timeframe.H1: 3600,
        Timeframe.M15: 900, Timeframe.M5: 300,
    }[timeframe]
    if age < -60 or age > max(300, duration * 2):
        raise ValueError("stale_public_candles")
    return timeframe, batch


def _telegram_adapter():
    from app.integrations.telegram_adapter import TelegramAdapter, TelegramConfig
    enabled = os.getenv("TITAN_TELEGRAM_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}
    return TelegramAdapter(TelegramConfig(
        enabled=enabled,
        bot_token_ref=os.getenv("TITAN_TELEGRAM_BOT_TOKEN_REF", "env:TELEGRAM_BOT_TOKEN"),
        allowed_chat_ids_ref=os.getenv("TITAN_TELEGRAM_ALLOWED_CHAT_IDS_REF", "env:TELEGRAM_ALLOWED_CHAT_IDS"),
    ))


async def telegram_status(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        return J(_telegram_adapter().status())
    finally:
        db.close()


async def telegram_poll(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        adapter = _telegram_adapter()
        result = adapter.get_updates(
            offset=int(request.query_params["offset"]) if "offset" in request.query_params else None,
            timeout=int(request.query_params.get("timeout", "0")),
            limit=int(request.query_params.get("limit", "100")),
        )
        return J(result, 200 if result.get("ok") else 503)
    except (TypeError, ValueError) as exc:
        return J({"ok": False, "error": "invalid_telegram_poll_parameters", "detail": str(exc)}, 400)
    finally:
        db.close()


async def telegram_send(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        result = _telegram_adapter().send_message(str(p.get("chat_id", "")), str(p.get("text", "")))
        return J(result, 200 if result.get("ok") else 400)
    finally:
        db.close()


async def prediction_evaluations(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        from app.services.prediction_tracker import PredictionTrackerService
        items = PredictionTrackerService().list_evaluations(
            db, limit=int(request.query_params.get("limit", "100")),
        )
        return J({"items": items, "count": len(items), "note": "Mark-to-market decision observations, not realized trade PnL."})
    except (TypeError, ValueError) as exc:
        return J({"ok": False, "error": "invalid_prediction_limit", "detail": str(exc)}, 400)
    finally:
        db.close()


async def evaluate_predictions(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        from app.services.prediction_tracker import PredictionTrackerService
        result = PredictionTrackerService().evaluate_matured(
            db,
            environment_mode=str(p.get("environment_mode", "demo")).lower(),
            horizon_seconds=int(p.get("horizon_seconds", 3600)),
            max_records=int(p.get("max_records", 200)),
        )
        return J(result, 200 if result.get("ok") else 503)
    except (TypeError, ValueError) as exc:
        db.rollback()
        return J({"ok": False, "error": "invalid_prediction_evaluation_parameters", "detail": str(exc)}, 400)
    finally:
        db.close()


async def performance_analytics(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        environment_mode = str(request.query_params.get("environment_mode", "demo")).lower()
        market_type = str(request.query_params.get("market_type", "spot")).lower()
        from app.services.performance_analytics import PerformanceAnalyticsService
        result = PerformanceAnalyticsService().evaluate(
            db, environment_mode=environment_mode, market_type=market_type,
        )
        return J(result, 200 if result.get("ok") else 400)
    finally:
        db.close()


async def backtest_strategy(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        symbol = str(p.get("symbol", "BTC/USDT")).strip().upper().replace("-", "/")
        if not symbol.endswith("/USDT") or len(symbol) > 32:
            return J({"ok": False, "error": "usdt_spot_symbol_required"}, 400)
        timeframe_value = str(p.get("timeframe", "1h")).lower()
        try:
            timeframe = Timeframe(timeframe_value)
        except ValueError:
            return J({"ok": False, "error": "unsupported_timeframe"}, 400)
        limit = int(p.get("limit", 240))
        if not 60 <= limit <= 500:
            return J({"ok": False, "error": "candle_limit_must_be_60_to_500"}, 400)
        batch = core_service.market_data.get_public_candles(symbol, timeframe, limit=limit)
        if getattr(batch.source, "value", None) != "live_public" or len(batch.df) < 60:
            return J({"ok": False, "error": "verified_public_historical_candles_required"}, 409)
        rows = batch.df.rows
        stamp = rows[-1].get("close_time") or rows[-1].get("timestamp")
        if not isinstance(stamp, (int, float)):
            return J({"ok": False, "error": "historical_candle_timestamp_required"}, 409)
        duration = {
            Timeframe.D1: 86400, Timeframe.H4: 14400, Timeframe.H1: 3600,
            Timeframe.M15: 900, Timeframe.M5: 300,
        }[timeframe]
        age = __import__("time").time() - float(stamp) / 1000.0
        if age < -60 or age > max(300, duration * 2):
            return J({"ok": False, "error": "stale_historical_candles"}, 409)

        from app.engines.backtest import BacktestEngine
        engine = BacktestEngine(
            fee_rate=float(p.get("fee_rate", 0.001)),
            slippage_rate=float(p.get("slippage_rate", 0.0005)),
            initial_cash=float(p.get("initial_cash", 150.0)),
        )
        strategy_key = str(p.get("strategy_key", "trend_following_ema"))
        mode = str(p.get("mode", "historical")).lower()
        if mode == "walk_forward":
            result = engine.run_strategy_walk_forward(
                rows, strategy_key=strategy_key, timeframe=timeframe,
                train_window=int(p.get("train_window", 60)),
                test_window=int(p.get("test_window", 30)),
                step=int(p.get("step", p.get("test_window", 30))),
            )
        elif mode == "historical":
            result = engine.run_strategy(rows, strategy_key=strategy_key, timeframe=timeframe)
        else:
            return J({"ok": False, "error": "invalid_backtest_mode"}, 400)
        return J({
            **result,
            "symbol": symbol,
            "timeframe": timeframe.value,
            "candles": len(rows),
            "data_source": "binance_public_read_only",
            "initial_cash": engine.initial_cash,
            "fee_rate": engine.fee_rate,
            "slippage_rate": engine.slippage_rate,
            "execution": "simulated_only",
            "note": "Historical simulation only. It does not use account balances, send orders, or prove future profitability.",
        }, 200 if result.get("ok", True) else 422)
    except (TypeError, ValueError) as exc:
        db.rollback()
        return J({"ok": False, "error": "invalid_backtest_parameters", "detail": str(exc)}, 400)
    except Exception as exc:
        db.rollback()
        return J({"ok": False, "error": "backtest_failed", "detail": str(exc)[:240]}, 503)
    finally:
        db.close()


async def futures_backtest(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        symbol = str(p.get("symbol", "BTC/USDT")).strip().upper().replace("-", "/")
        if not symbol.endswith("/USDT") or len(symbol) > 32:
            return J({"ok": False, "error": "usdt_futures_symbol_required"}, 400)
        timeframe_value = str(p.get("timeframe", "1h")).lower()
        try:
            timeframe = Timeframe(timeframe_value)
        except ValueError:
            return J({"ok": False, "error": "unsupported_timeframe"}, 400)
        limit = p.get("limit", 240)
        if isinstance(limit, bool) or not isinstance(limit, int) or not 60 <= limit <= 500:
            return J({"ok": False, "error": "candle_limit_must_be_60_to_500"}, 400)
        batch = core_service.market_data.get_public_candles(
            symbol, timeframe, limit=limit, market_type="futures",
        )
        if (getattr(batch.source, "value", None) != "live_public"
                or getattr(batch, "market_type", None) != "futures" or len(batch.df) < 60):
            return J({"ok": False, "error": "verified_public_futures_candles_required"}, 409)
        rows = batch.df.rows
        start_stamp = rows[0].get("timestamp") or rows[0].get("close_time")
        end_stamp = rows[-1].get("close_time") or rows[-1].get("timestamp")
        if (isinstance(start_stamp, bool) or isinstance(end_stamp, bool)
                or not isinstance(start_stamp, (int, float)) or not isinstance(end_stamp, (int, float))):
            return J({"ok": False, "error": "futures_candle_timestamps_required"}, 409)
        duration = {
            Timeframe.D1: 86400, Timeframe.H4: 14400, Timeframe.H1: 3600,
            Timeframe.M15: 900, Timeframe.M5: 300,
        }[timeframe]
        age = __import__("time").time() - float(end_stamp) / 1000.0
        if age < -60 or age > max(300, duration * 2):
            return J({"ok": False, "error": "stale_futures_historical_candles"}, 409)
        funding_rows = core_service.market_data.get_public_funding_rates(
            symbol, start_time=int(start_stamp), end_time=int(end_stamp),
        )
        from app.engines.futures_backtest import FuturesBacktestEngine
        requested_cap = p.get("max_notional", settings.max_futures_trade_notional)
        if isinstance(requested_cap, bool):
            return J({"ok": False, "error": "invalid_max_notional"}, 400)
        max_notional = min(float(requested_cap), float(settings.max_futures_trade_notional))
        requested_leverage = p.get("max_leverage", settings.max_leverage_cap)
        if isinstance(requested_leverage, bool):
            return J({"ok": False, "error": "invalid_max_leverage"}, 400)
        max_leverage = min(float(requested_leverage), float(settings.max_leverage_cap))
        engine = FuturesBacktestEngine(
            initial_cash=p.get("initial_cash", 150.0),
            fee_rate=p.get("fee_rate", 0.0004),
            slippage_rate=p.get("slippage_rate", 0.0005),
            max_notional=max_notional,
            max_leverage=max_leverage,
            maintenance_margin_rate=p.get("maintenance_margin_rate", 0.005),
            liquidation_fee_rate=p.get("liquidation_fee_rate", 0.005),
        )
        strategy_key = str(p.get("strategy_key", "trend_following_ema"))
        result = engine.run_strategy(
            rows,
            strategy_key=strategy_key,
            timeframe=timeframe,
            funding_events=funding_rows,
            leverage=p.get("leverage", 3.0),
            notional=p.get("notional"),
            entry_fill_ratio=p.get("entry_fill_ratio", 1.0),
            exit_fill_ratio=p.get("exit_fill_ratio", 1.0),
        )
        return J({
            **result, "symbol": symbol, "timeframe": timeframe.value,
            "candles": len(rows), "funding_events": len(funding_rows),
            "data_source": "binance_usdm_futures_public_read_only",
            "initial_cash": engine.initial_cash, "max_notional": engine.max_notional,
            "max_leverage": engine.max_leverage,
            "execution": "simulated_only",
            "note": "Futures research simulation only. Funding is fetched from public history; liquidation and margin are estimates, not Binance exchange-calculated outcomes.",
        }, 200 if result.get("ok") else 422)
    except (TypeError, ValueError) as exc:
        db.rollback()
        return J({"ok": False, "error": "invalid_futures_backtest_parameters", "detail": str(exc)}, 400)
    except Exception as exc:
        db.rollback()
        return J({"ok": False, "error": "futures_backtest_failed", "detail": str(exc)[:240]}, 503)
    finally:
        db.close()


async def news_analysis(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        keyword = request.query_params.get("keyword")
        limit = int(request.query_params.get("limit", "50"))
        from app.engines.news import NewsAnalysisEngine
        result = NewsAnalysisEngine().fetch_and_analyze(keyword=keyword, limit=limit)
        return J(result, 200 if result.get("ok") else 503)
    except (TypeError, ValueError) as exc:
        return J({"ok": False, "error": "invalid_news_query", "detail": str(exc)}, 400)
    finally:
        db.close()


async def fundamental_analysis(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        coin_id = str(request.query_params.get("coin_id", "")).strip().lower()
        if not coin_id:
            return J({"ok": False, "error": "coin_id_required"}, 400)
        from app.engines.fundamental import FundamentalAnalysisEngine
        result = FundamentalAnalysisEngine().fetch_and_analyze(coin_id)
        return J(result, 200 if result.get("ok") else 503)
    finally:
        db.close()


async def token_unlocks(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        from datetime import date, timedelta
        from app.data.tokenomist_public import TokenomistPublicData
        token_id = request.query_params.get("token_id", "").strip().lower()
        if not token_id:
            return J({"ok": False, "error": "token_id_required"}, 400)
        try:
            start_date = date.fromisoformat(request.query_params.get("from", date.today().isoformat()))
            end_date = date.fromisoformat(request.query_params.get("to", (date.today() + timedelta(days=90)).isoformat()))
            result = TokenomistPublicData().get_unlock_events(
                token_id, start=start_date, end=end_date,
            )
        except (TypeError, ValueError) as exc:
            return J({"ok": False, "error": str(exc)}, 400)
        return J(result, 200 if result.get("ok") else 503)
    except Exception as exc:
        return J({"ok": False, "error": "token_unlock_data_unavailable", "detail": str(exc)[:200]}, 503)
    finally:
        db.close()


async def economic_calendar(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        from datetime import date, timedelta
        from app.data.economic_calendar_public import EconomicCalendarPublicData
        try:
            start_date = date.fromisoformat(request.query_params.get("from", date.today().isoformat()))
            end_date = date.fromisoformat(request.query_params.get("to", (date.today() + timedelta(days=30)).isoformat()))
            importance = request.query_params.get("importance", "high")
        except (TypeError, ValueError):
            return J({"ok": False, "error": "invalid_economic_calendar_date_parameters"}, 400)
        result = EconomicCalendarPublicData().fetch(
            start_date=start_date, end_date=end_date, importance=importance,
        )
        return J(result)
    except ValueError as exc:
        return J({"ok": False, "error": str(exc)}, 400)
    except Exception as exc:
        return J({"ok": False, "error": "economic_calendar_unavailable", "detail": str(exc)[:200]}, 503)
    finally:
        db.close()


async def protocol_fundamental_analysis(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        slug = str(request.query_params.get("slug", "")).strip().lower()
        if not slug:
            return J({"ok": False, "error": "protocol_slug_required"}, 400)
        from app.engines.fundamental import FundamentalAnalysisEngine
        result = FundamentalAnalysisEngine().fetch_protocol_and_analyze(slug)
        return J(result, 200 if result.get("ok") else 503)
    finally:
        db.close()


async def market_microstructure(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        symbol = str(request.query_params.get("symbol", "BTC/USDT")).strip().upper().replace("-", "/")
        market_type = str(request.query_params.get("market_type", "spot")).strip().lower()
        if market_type not in {"spot", "futures"}:
            return J({"ok": False, "error": "unsupported_public_market_type"}, 400)
        if not symbol.endswith("/USDT") or len(symbol) > 32:
            return J({"ok": False, "error": "usdt_symbol_required"}, 400)
        from app.engines.liquidity import LiquidityAnalysisEngine
        from app.engines.order_flow import OrderFlowEngine
        liquidity = LiquidityAnalysisEngine().fetch_and_analyze(symbol, limit=100, market_type=market_type)
        order_flow = OrderFlowEngine().fetch_and_analyze(symbol, limit=500, market_type=market_type)
        ok = bool(liquidity.get("ok") or order_flow.get("ok"))
        source = "binance_futures_public_read_only" if market_type == "futures" else "binance_public_read_only"
        return J({
            "ok": ok,
            "symbol": symbol,
            "market_type": market_type,
            "source": source,
            "liquidity": liquidity,
            "order_flow": order_flow,
            "execution": "none",
            "note": "Public depth and recent aggregate trades only; no authenticated account access and no exchange orders.",
        }, 200 if ok else 503)
    finally:
        db.close()


async def arbitrage_analysis(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        route_assets = p.get("route")
        if not isinstance(route_assets, list) or len(route_assets) != 4:
            return J({"ok": False, "error": "triangle_route_must_contain_four_assets"}, 400)
        numeric = ("starting_amount", "fee_rate", "slippage_rate", "min_profit_pct")
        if any(isinstance(p.get(key), bool) for key in numeric if key in p):
            return J({"ok": False, "error": "boolean_arbitrage_configuration_not_allowed"}, 400)
        from app.engines.arbitrage import ArbitrageAnalysisEngine
        result = ArbitrageAnalysisEngine(core_service.market_data).fetch_and_analyze(
            route_assets,
            starting_amount=p.get("starting_amount", 1000.0),
            fee_rate=p.get("fee_rate", 0.001),
            slippage_rate=p.get("slippage_rate", 0.0005),
            min_profit_pct=p.get("min_profit_pct", 0.05),
        )
        return J({
            **result,
            "execution": "none",
            "data_access": "binance_public_read_only",
            "note": "Triangular Spot arbitrage is a theoretical top-of-book estimate. No orders are placed; liquidity reservation, exchange filters, latency and partial fills are not guaranteed.",
        }, 200 if result.get("ok") else 422)
    except (TypeError, ValueError) as exc:
        return J({"ok": False, "error": "invalid_arbitrage_parameters", "detail": str(exc)[:200]}, 400)
    finally:
        db.close()


async def ml_train(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        symbol = str(p.get("symbol", "BTC/USDT")).strip().upper().replace("-", "/")
        if not symbol.endswith("/USDT") or len(symbol) > 32:
            return J({"ok": False, "error": "usdt_spot_symbol_required"}, 400)
        timeframe_value = str(p.get("timeframe", "1h")).lower()
        try:
            timeframe, batch = _ml_timeframe_batch(symbol, timeframe_value)
        except (ValueError, KeyError) as exc:
            return J({"ok": False, "error": str(exc)}, 409)
        from app.engines.hybrid.ml_engine import ml_engine
        model_key = f"{symbol}|{timeframe.value}"
        result = ml_engine.train(
            batch.df.rows,
            lookahead=int(p.get("lookahead", 1)),
            train_ratio=float(p.get("train_ratio", 0.8)),
            epochs=int(p.get("epochs", 400)),
            model_key=model_key,
        )
        if not result.get("ok"):
            return J(result, 422)
        record = LearningRecord(
            category="ml_model",
            subject=model_key,
            outcome="trained",
            lesson="Chronological train/test split using Binance Public read-only historical candles.",
            evidence={"model": result["model"], "metrics": result["metrics"], "data_source": "binance_public_read_only"},
            verified=False,
        )
        db.add(record)
        db.commit()
        db.refresh(record)
        return J({
            "ok": True, "record_id": record.id, "symbol": symbol,
            "timeframe": timeframe.value, "model_key": model_key,
            "metrics": result["metrics"], "model_version": result["model"]["model_version"],
            "training_samples": result["model"]["training_samples"],
            "test_samples": result["model"]["test_samples"],
            "data_source": "binance_public_read_only",
            "execution": "none",
            "note": result["note"] + " Model snapshot is stored in the local learning database.",
        })
    except (TypeError, ValueError) as exc:
        db.rollback()
        return J({"ok": False, "error": "invalid_ml_training_parameters", "detail": str(exc)}, 400)
    except Exception as exc:
        db.rollback()
        return J({"ok": False, "error": "ml_training_failed", "detail": str(exc)[:240]}, 503)
    finally:
        db.close()


async def ml_predict(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        symbol = str(p.get("symbol", "BTC/USDT")).strip().upper().replace("-", "/")
        if not symbol.endswith("/USDT") or len(symbol) > 32:
            return J({"ok": False, "error": "usdt_spot_symbol_required"}, 400)
        timeframe_value = str(p.get("timeframe", "1h")).lower()
        try:
            timeframe, batch = _ml_timeframe_batch(symbol, timeframe_value)
        except (ValueError, KeyError) as exc:
            return J({"ok": False, "error": str(exc)}, 409)
        from app.engines.hybrid.ml_engine import ml_engine
        model_key = f"{symbol}|{timeframe.value}"
        if ml_engine.export_model(model_key) is None:
            record = db.execute(
                select(LearningRecord).where(
                    LearningRecord.category == "ml_model",
                    LearningRecord.subject == model_key,
                ).order_by(desc(LearningRecord.id)).limit(1)
            ).scalars().first()
            model = (record.evidence or {}).get("model") if record else None
            if not model:
                return J({"ok": False, "error": "trained_model_not_found", "model_key": model_key}, 404)
            loaded = ml_engine.load_model(model)
            if not loaded.get("ok"):
                return J(loaded, 409)
        prediction = ml_engine.predict(batch.df.rows, model_key=model_key)
        return J({
            **prediction, "symbol": symbol, "timeframe": timeframe.value,
            "data_source": "binance_public_read_only",
        })
    except Exception as exc:
        db.rollback()
        return J({"ok": False, "error": "ml_prediction_failed", "detail": str(exc)[:240]}, 503)
    finally:
        db.close()


async def ml_drift(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        symbol = str(p.get("symbol", "BTC/USDT")).strip().upper().replace("-", "/")
        if not symbol.endswith("/USDT") or len(symbol) > 32:
            return J({"ok": False, "error": "usdt_spot_symbol_required"}, 400)
        timeframe_value = str(p.get("timeframe", "1h")).lower()
        try:
            timeframe, batch = _ml_drift_timeframe_batch(symbol, timeframe_value)
        except (ValueError, KeyError) as exc:
            return J({"ok": False, "error": str(exc)}, 409)
        from app.engines.hybrid.ml_engine import ml_engine
        model_key = f"{symbol}|{timeframe.value}"
        if ml_engine.export_model(model_key) is None:
            record = db.execute(
                select(LearningRecord).where(
                    LearningRecord.category == "ml_model",
                    LearningRecord.subject == model_key,
                ).order_by(desc(LearningRecord.id)).limit(1)
            ).scalars().first()
            model = (record.evidence or {}).get("model") if record else None
            if not model:
                return J({"ok": False, "error": "trained_model_not_found", "model_key": model_key}, 404)
            loaded = ml_engine.load_model(model)
            if not loaded.get("ok"):
                return J(loaded, 409)
        result = ml_engine.evaluate_drift(
            batch.df.rows,
            model_key=model_key,
            brier_increase_threshold=p.get("brier_increase_threshold", 0.05),
            accuracy_drop_threshold=p.get("accuracy_drop_threshold", 0.10),
        )
        if not result.get("ok"):
            return J(result, 409)
        record = LearningRecord(
            category="ml_drift_evaluation",
            subject=model_key,
            outcome=result["status"],
            lesson="Post-training out-of-sample model drift and calibration evaluation; no model changes.",
            evidence={**result, "data_source": "binance_public_read_only", "timeframe": timeframe.value},
            verified=False,
        )
        db.add(record)
        db.commit()
        db.refresh(record)
        return J({
            **result, "record_id": record.id, "symbol": symbol,
            "timeframe": timeframe.value, "data_source": "binance_public_read_only",
        })
    except Exception as exc:
        db.rollback()
        return J({"ok": False, "error": "ml_drift_evaluation_failed", "detail": str(exc)[:240]}, 503)
    finally:
        db.close()


async def ml_models(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        rows = db.execute(
            select(LearningRecord).where(LearningRecord.category == "ml_model")
            .order_by(desc(LearningRecord.id)).limit(100)
        ).scalars().all()
        latest = {}
        for row in rows:
            latest.setdefault(row.subject, {
                "record_id": row.id,
                "model_key": row.subject,
                "outcome": row.outcome,
                "created_at": row.created_at,
                "metrics": (row.evidence or {}).get("metrics", {}),
            })
        return J({"items": list(latest.values()), "count": len(latest), "persistence": "local_learning_records"})
    finally:
        db.close()


async def strategies(request: Request):
    return J({"strategies": core_service.strategies(), "note": "Registry is extensible; statuses reflect current implementation/integration state."})


async def analyze(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        return J(core_service.analyze(db, symbol=p["symbol"], market_type=p.get("market_type", "spot"), environment_mode=p.get("environment_mode", "demo"),
                                      balance=float(p.get("balance", 1000)), max_leverage=float(p.get("max_leverage", 3)), risk_per_trade=float(p.get("risk_per_trade", 0.01)),
                                      data_source=p.get("data_source", "synthetic")))
    except Exception as e:
        return J({"detail": str(e)}, 400)
    finally:
        db.close()


async def list_decisions(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err:
            return err
        limit = min(max(int(request.query_params.get("limit", 50)), 1), 200)
        rows = db.execute(select(DecisionRecord).order_by(desc(DecisionRecord.id)).limit(limit)).scalars().all()
        return J({"items": [{"id": r.id, "created_at": r.created_at.isoformat(), "symbol": r.symbol, "action": r.action, "strategy": r.strategy,
                             "confidence": r.confidence, "environment_mode": r.environment_mode, "market_type": r.market_type,
                             "data_source": r.data_source, "reason": r.rationale} for r in rows]})
    finally:
        db.close()


async def list_audit(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err:
            return err
        limit = min(max(int(request.query_params.get("limit", 100)), 1), 500)
        rows = db.execute(select(AuditLog).order_by(desc(AuditLog.id)).limit(limit)).scalars().all()
        return J({"items": [{"id": r.id, "created_at": r.created_at.isoformat(), "action": r.action, "severity": r.severity,
                             "message": r.message, "environment_mode": r.environment_mode, "market_type": r.market_type, "details": r.details} for r in rows]})
    finally:
        db.close()


async def knowledge_list(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err:
            return err
        rows = db.execute(select(KnowledgeSource).order_by(desc(KnowledgeSource.id)).limit(200)).scalars().all()
        return J({"items": [{
            "id": r.id, "title": r.title, "source_type": r.source_type, "url": r.url,
            "reliability_score": r.reliability_score, "verified": r.verified,
            "notes": r.notes, "source_verification": (r.metadata_json or {}).get("source_verification"),
        } for r in rows]})
    finally:
        db.close()


async def knowledge_add(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        from app.knowledge.validation import validate_knowledge_source
        validated = validate_knowledge_source(p)
        if not validated.get("ok"):
            return J(validated, 400)
        r = KnowledgeSource(
            title=validated["title"], source_type=validated["source_type"],
            url=validated["url"], reliability_score=validated["reliability_score"],
            verified=False, notes=validated["notes"], metadata_json=validated["metadata"],
        )
        db.add(r); db.commit(); db.refresh(r)
        return J({"id": r.id, "title": r.title, "verified": False, "verification_status": "unverified"})
    finally:
        db.close()


async def knowledge_verify(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        raw_id = p.get("source_id")
        if (isinstance(raw_id, bool)
                or not (
                    isinstance(raw_id, int)
                    or (isinstance(raw_id, str) and raw_id.strip().isdigit())
                )):
            return J({"ok": False, "error": "valid_knowledge_source_id_required"}, 400)
        source_id = int(raw_id)
        source = db.get(KnowledgeSource, source_id)
        if source is None:
            return J({"ok": False, "error": "knowledge_source_not_found"}, 404)
        if not source.url:
            return J({"ok": False, "error": "knowledge_source_url_required"}, 400)
        claim = p.get("claim")
        if claim is None:
            claim = source.notes
        if not isinstance(claim, str) or len(claim) > 2000:
            return J({"ok": False, "error": "claim_must_be_text_under_2000_chars"}, 400)
        from app.knowledge.verification import KnowledgeSourceVerifier
        result = KnowledgeSourceVerifier().verify(source.url, claim=claim or None)
        metadata = dict(source.metadata_json or {})
        metadata["source_verification"] = result
        source.metadata_json = metadata
        # A reachable source and text overlap do not certify the factual claim.
        source.verified = False
        db.add(source)
        db.commit()
        return J({
            **result,
            "source_id": source.id,
            "knowledge_record_verified": False,
        })
    except Exception as exc:
        db.rollback()
        return J({"ok": False, "error": "knowledge_source_verification_failed", "detail": str(exc)[:200]}, 503)
    finally:
        db.close()


async def knowledge_concepts(request: Request):
    from app.knowledge.base import categories, list_concepts
    return J({"categories": categories(), "items": list_concepts(category=request.query_params.get("category"), query=request.query_params.get("q"))})


async def learning_list(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err:
            return err
        rows = db.execute(select(LearningRecord).order_by(desc(LearningRecord.id)).limit(200)).scalars().all()
        return J({"items": [{"id": r.id, "category": r.category, "subject": r.subject, "outcome": r.outcome, "lesson": r.lesson, "verified": r.verified, "environment_mode": r.environment_mode, "market_type": r.market_type} for r in rows]})
    finally:
        db.close()


async def learning_add(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        r = LearningRecord(category=p.get("category",""), subject=p.get("subject",""), lesson=p.get("lesson",""), outcome=p.get("outcome"), environment_mode=p.get("environment_mode"), market_type=p.get("market_type"), verified=False)
        db.add(r); db.commit(); db.refresh(r)
        return J({"id": r.id, "subject": r.subject})
    finally:
        db.close()


async def strategy_versions(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        key = str(request.query_params.get("strategy_key", "")).strip()
        if not key: return J({"ok": False, "error": "strategy_key_required"}, 400)
        from app.learning.persistent import PersistentStrategyLearning
        service = PersistentStrategyLearning()
        return J({"items": service.list_versions(db, key), "active": service.get_active_version(db, key)})
    finally:
        db.close()


async def strategy_version_create(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        from app.learning.persistent import PersistentStrategyLearning
        result = PersistentStrategyLearning().create_version(
            db, p.get("strategy_key", ""), p.get("params", {}), p.get("metrics", {}),
            make_active=p.get("make_active") is True,
            explicit_approval=p.get("explicit_approval") is True,
        )
        return J(result, 200 if result.get("ok") else 400)
    finally:
        db.close()


async def strategy_version_rollback(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        from app.learning.persistent import PersistentStrategyLearning
        result = PersistentStrategyLearning().rollback(
            db, str(p.get("strategy_key", "")), int(p.get("version", 0)),
            explicit_approval=p.get("explicit_approval") is True,
        )
        return J(result, 200 if result.get("ok") else 400)
    except (TypeError, ValueError) as exc:
        db.rollback()
        return J({"ok": False, "error": "invalid_version_rollback", "detail": str(exc)}, 400)
    finally:
        db.close()


async def strategy_proposal_create(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        from app.learning.persistent import PersistentStrategyLearning
        result = PersistentStrategyLearning().create_proposal(
            db, str(p.get("strategy_key", "")), p.get("current_params", {}),
            p.get("proposed_params", {}), str(p.get("rationale", "")), p.get("metrics_before", {}),
        )
        return J(result, 200 if result.get("ok") else 400)
    finally:
        db.close()


async def strategy_proposal_test(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        from app.learning.persistent import PersistentStrategyLearning
        result = PersistentStrategyLearning().test_proposal(
            db, int(p.get("proposal_id", 0)), p.get("metrics_after_paper", {}),
        )
        return J(result, 200 if result.get("ok") else 400)
    except (TypeError, ValueError) as exc:
        db.rollback()
        return J({"ok": False, "error": "invalid_proposal_test", "detail": str(exc)}, 400)
    finally:
        db.close()


async def strategy_proposal_apply_paper(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        from app.learning.persistent import PersistentStrategyLearning
        result = PersistentStrategyLearning().apply_proposal_to_paper(
            db, int(p.get("proposal_id", 0)),
            explicit_approval=p.get("explicit_approval") is True,
        )
        return J(result, 200 if result.get("ok") else 400)
    except (TypeError, ValueError) as exc:
        db.rollback()
        return J({"ok": False, "error": "invalid_proposal_apply", "detail": str(exc)}, 400)
    finally:
        db.close()


async def auth_status(request: Request):
    db = db_sess()
    try:
        from app.models.entities import AppUser
        has_user = db.execute(select(AppUser.id).limit(1)).first() is not None
        return J({"auth_required": settings.auth_required, "allowlist_configured": bool(auth_service.get_allowed_emails()) or bool(settings.allowed_emails), "has_user": has_user,
                  "note": "Set initial password locally with backend script. Never send passwords in chat."})
    finally:
        db.close()


async def auth_login(request: Request):
    db = db_sess()
    try:
        p = await body(request)
        user = auth_service.authenticate(db, p.get("email",""), p.get("password",""))
        if not user:
            db.commit()
            return J({"detail": "Invalid credentials, email not allowed, or account locked"}, 401)
        token = auth_service.create_session(db, user, ttl_hours=settings.session_ttl_hours, ip_address=request.client.host if request.client else None, user_agent=request.headers.get("user-agent"))
        db.commit()
        return J({"ok": True, "token": token, "email": user.email, "token_type": "bearer"})
    finally:
        db.close()


async def auth_logout(request: Request):
    db = db_sess()
    try:
        token = _bearer(request)
        ok = auth_service.revoke_session(db, token) if token else False
        db.commit()
        return J({"ok": ok})
    finally:
        db.close()


async def auth_me(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err and settings.auth_required: return err
        if not user:
            return J({"authenticated": False, "auth_required": settings.auth_required})
        return J({"authenticated": True, "email": user.email, "is_admin": user.is_admin, "two_factor_enabled": user.two_factor_enabled})
    finally:
        db.close()


async def config_changes(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        rows = db.execute(select(ConfigChange).order_by(desc(ConfigChange.id)).limit(100)).scalars().all()
        return J({"items": [{"id": r.id, "created_at": r.created_at.isoformat(), "actor": r.actor, "scope": r.scope, "key": r.key, "approved": r.approved, "reason": r.reason} for r in rows]})
    finally:
        db.close()


async def chat(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        msg = (p.get("message") or "").strip()
        low = msg.lower()
        state = core_service.get_state(db)
        decisions = db.execute(select(DecisionRecord).order_by(desc(DecisionRecord.id)).limit(5)).scalars().all()
        from app.knowledge.base import list_concepts
        if not msg:
            reply = "اكتب سؤالك عن حالة النظام، القرارات، الاستراتيجيات، المخاطر، أو التحليل."
        elif any(k in low for k in ["حالة", "status", "يعمل", "متوقف", "demo", "live", "spot", "futures", "earn"]):
            reply = f"حالة النظام: البيئة={state['environment_mode']}، السوق={state['market_type']}، مستقل={state['autonomous_enabled']}، إيقاف طوارئ={state['emergency_stop']}. Demo→Live تلقائي معطل؛ لا صلاحيات سحب."
        elif any(k in low for k in ["قرار", "decision", "لماذا", "why", "صفقة", "trade"]):
            if decisions:
                d = decisions[0]
                reply = f"آخر قرار: {d.symbol} → {d.action} (استراتيجية {d.strategy}, ثقة {d.confidence}, مصدر {d.data_source}). السبب: {d.rationale}"
            else:
                reply = "لا توجد قرارات مسجلة بعد. شغّل تحليلًا من Market Scanner."
        elif any(k in low for k in ["استرات", "strategy"]):
            reply = "الاستراتيجيات: " + ", ".join([f"{s['name']}[{s['status']}]" for s in core_service.strategies()[:8]])
        elif any(k in low for k in ["مخاطر", "risk", "رافعة", "رسوم", "امتثال", "compliance"]):
            reply = f"حدود الأمان: {state.get('risk_limits',{})}. محرك الامتثال يسبق أي تنفيذ؛ Live يتطلب تمكينًا صريحًا وتحقق شروط؛ السحب/التحويل ممنوعان."
        elif any(k in low for k in ["تشخيص", "diagnosis", "خطأ", "error", "مشكلة", "issue", "إصلاح", "heal", "صحة", "health"]):
            from app.services.self_diagnosis import get_engine
            engine = get_engine()
            report = engine.run_full_check()
            if any(k in low for k in ["أصلح", "fix", "heal", "repair"]):
                healed = []
                for issue in report.get("issues", []):
                    h = engine.attempt_auto_heal(issue)
                    if h.get("healed"):
                        healed.append(h)
                reply = "تشخيص: " + report["overall"] + ". مشكلات: " + str(len(report["issues"])) + ". مُصلحة تلقائياً: " + str(len(healed)) + "."
            else:
                reply = f"تشخيص النظام: حالة={report['overall']}. مكونات: {len(report['components'])}. مشكلات: {len(report['issues'])}. " + engine.get_summary_text()
        elif any(k in low for k in ["bos", "choch", "سيولة", "liquidity", "اختراق", "breakout", "شمعة", "candle", "rsi", "macd"]):
            concepts = list_concepts(query=msg)[:3]
            reply = " | ".join([f"{c['title']}: {c['summary']}" for c in concepts]) if concepts else "جرّب: BOS, CHOCH, liquidity, breakout, RSI, MACD."
        else:
            reply = "مساعد TITAN مرتبط ببيانات النظام. اسأل عن الحالة، القرارات، الاستراتيجيات، المخاطر/الامتثال، أو مفاهيم التحليل. التكامل مع LLM خارجي اختياري ويخضع للأمان."
        return J({"reply": reply, "grounded": True, "used_external_llm": False})
    finally:
        db.close()


async def ai_providers(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        rows = list_configs(db)
        return J({"supported_providers": sorted(SUPPORTED_PROVIDERS), "items": [{"id": r.id, "name": r.name, "provider": r.provider, "model": r.model, "api_key_ref_set": bool(r.api_key_ref), "enabled": r.enabled, "priority": r.priority, "tasks": r.tasks or []} for r in rows]})
    finally:
        db.close()


async def ai_provider_create(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        import ipaddress
        import re
        from urllib.parse import urlsplit

        provider = p.get("provider")
        if provider not in SUPPORTED_PROVIDERS:
            return J({"detail": "unsupported provider"}, 400)
        name = str(p.get("name") or "").strip()
        model = str(p.get("model") or "").strip()
        key_ref = p.get("api_key_ref")
        if not name or len(name) > 128 or not model or len(model) > 128:
            return J({"detail": "provider_name_and_model_required_max_128"}, 400)
        # API keys must remain in server environment variables, never in DB rows.
        if not isinstance(key_ref, str) or not re.fullmatch(r"env:[A-Z][A-Z0-9_]{1,127}", key_ref.strip()):
            return J({"detail": "api_key_ref_must_be_env_reference"}, 400)
        base_url = str(p.get("base_url") or "").strip() or None
        if provider == "openai_compatible" and not base_url:
            return J({"detail": "base_url_required_for_openai_compatible"}, 400)
        if base_url:
            try:
                parsed = urlsplit(base_url)
                host = (parsed.hostname or "").lower().rstrip(".")
                port = parsed.port
                is_private_ip = False
                try:
                    address = ipaddress.ip_address(host)
                    is_private_ip = not address.is_global
                except ValueError:
                    pass
                if (parsed.scheme != "https" or not host or parsed.username or parsed.password
                        or parsed.query or parsed.fragment or (port is not None and not 1 <= port <= 65535)
                        or host in {"localhost", "metadata.google.internal"}
                        or host.endswith((".localhost", ".local", ".internal"))
                        or is_private_ip or len(base_url) > 512):
                    return J({"detail": "base_url_must_be_public_https_endpoint"}, 400)
            except ValueError:
                return J({"detail": "invalid_provider_base_url"}, 400)
        row = AIProviderConfig(
            name=name, provider=provider, model=model, base_url=base_url,
            api_key_ref=key_ref.strip(), enabled=p.get("enabled") is True,
            priority=int(p.get("priority", 100)), tasks=p.get("tasks") or [],
        )
        db.add(row); db.commit(); db.refresh(row)
        return J({"id": row.id})
    except (TypeError, ValueError) as exc:
        db.rollback()
        return J({"detail": "invalid_provider_configuration", "reason": str(exc)[:160]}, 400)
    finally:
        db.close()


async def ai_provider_test(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        cfg = db.get(AIProviderConfig, int(request.path_params["provider_id"]))
        if not cfg: return J({"detail": "not found"}, 404)
        result = invoke_provider(cfg, [{"role": "user", "content": "Reply with: TITAN_OK"}], task="test")
        record_usage(db, cfg, "test", result); db.commit()
        return J(result.to_dict())
    finally:
        db.close()


async def ai_research(request: Request):
    return J({"checked_at_note": "Web lookups performed in-session; verify current terms/pricing/access before relying on them. Not live-tested without API keys.",
              "sources": [
                  {"provider": "Anthropic", "urls": ["https://www.anthropic.com/legal/supported-regions", "https://platform.claude.com/docs/en/about-claude/pricing"], "algeria_note": "Retrieved supported-regions page listed Algeria; verify directly."},
                  {"provider": "OpenAI", "urls": ["https://developers.openai.com/api/docs/supported-countries.md", "https://openai.com/api/pricing/"], "algeria_note": "Retrieved supported-countries markdown included Algeria; verify pricing/models/terms directly."},
                  {"provider": "Google Gemini API", "urls": ["https://ai.google.dev/gemini-api/docs/available-regions", "https://ai.google.dev/gemini-api/docs/pricing"], "algeria_note": "Could not conclusively confirm Algeria from retrieved content; verify directly."},
                  {"provider": "Mistral", "urls": ["https://mistral.ai/pricing", "https://docs.mistral.ai/getting-started/models/"], "algeria_note": "Verify directly."},
                  {"provider": "DeepSeek", "urls": ["https://api-docs.deepseek.com/quick_start/pricing"], "algeria_note": "Verify directly."},
                  {"provider": "xAI", "urls": ["https://docs.x.ai/developers/models"], "algeria_note": "Verify directly."},
              ],
              "caveat": "No model is connected and no feature works until configured with valid credentials and tested successfully."})


async def compliance_check(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        g = PreTradeOrderGateway()
        r = g.validate(symbol=p.get("symbol","BTC/USDT"), market=MarketType(p.get("market_type","spot")), side="buy", order_type="limit",
                       quantity=0.001, price=1.0, reference_price=1.0, environment_mode=p.get("environment_mode","demo"), live_enabled=False)
        if not r.ok:
            log_event(db, action="compliance.block", severity="warning", message=r.reason, details=r.normalized,
                      environment_mode=p.get("environment_mode"), market_type=p.get("market_type")); db.commit()
        return J({"gateway": r.to_dict(), "sources": ["https://www.binance.com/en/terms", "https://www.binance.com/en/terms-api", "https://developers.binance.com/"],
                  "note": "Software precheck only. Verify official Binance terms/policies, eligibility, KYC, geo restrictions, symbol filters, and API limits before live operations."})
    finally:
        db.close()



async def demo_cycle(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        market = p.get("market_type", "spot")
        environment = p.get("environment_mode", "demo")
        execute_shadow = p.get("execute_shadow", True)
        if type(execute_shadow) is not bool:
            return J({"ok": False, "error": "execute_shadow_must_be_boolean", "executed": False}, 400)
        if market not in {"spot", "futures"} or environment != "demo":
            return J({"ok": False, "error": "demo_spot_or_futures_only_policy", "executed": False}, 400)
        selected_state = core_service.get_state(db)
        if market != selected_state.get("market_type"):
            return J({"ok": False, "error": "requested_market_does_not_match_selected_market", "executed": False}, 409)
        from app.services.orchestrator import TradingOrchestrator
        result = TradingOrchestrator().run_cycle(
            db, symbol=p.get("symbol", "BTC/USDT"), market=market, environment="demo",
            execute_shadow=execute_shadow,
        )
        db.commit()
        return J(result)
    except Exception as e:
        db.rollback()
        return J({"ok": False, "error": str(e), "executed": False}, 500)
    finally:
        db.close()


async def master_start(request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        prepared = core_service.start_bot(
            db, account_target=p.get("account_target"),
            live_confirm=bool(p.get("live_confirm")),
        )
        from app.services.demo_worker_supervisor import demo_worker_supervisor
        selected_market = prepared.get("state", {}).get("market_type", "spot")
        started = demo_worker_supervisor.start(market=selected_market)
        if not started.get("ok"):
            from app.models.entities import SystemState
            from datetime import datetime, timezone
            state = db.get(SystemState, 1)
            if state is not None and state.bot_run_state != "stopped":
                state.bot_run_state = "stopped"
                state.autonomous_enabled = False
                state.bot_stop_reason = started.get("error", "worker_start_failed")
                state.bot_stopped_at = datetime.now(timezone.utc)
                db.add(state)
                db.commit()
            return J({"ok": False, "error": "demo_worker_start_failed", "worker": started,
                      "state": core_service.get_state(db)}, 503)
        db.expire_all()
        return J({"ok": True, "state": core_service.get_state(db),
                  "checks": prepared.get("checks", {}), "worker": started,
                  "note": f"Supervised Demo/{selected_market.title()} Shadow worker is running. Public market data only; no Binance orders."})
    except Exception as e:
        db.rollback()
        return J({"ok": False, "detail": str(e)}, 400)
    finally:
        db.close()


async def master_stop(request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        result = core_service.stop_bot(
            db, reason=p.get("reason", "user_stop"),
            close_positions=bool(p.get("close_positions")),
        )
        from app.services.demo_worker_supervisor import demo_worker_supervisor
        stopped = demo_worker_supervisor.stop()
        if not stopped.get("ok"):
            return J({"ok": False, "error": "demo_worker_stop_failed",
                      "worker": stopped, "state": core_service.get_state(db)}, 503)
        return J({**result, "worker": stopped})
    except Exception as e:
        db.rollback()
        return J({"ok": False, "detail": str(e)}, 400)
    finally:
        db.close()


async def master_emergency_reset(request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        try:
            return J(core_service.reset_emergency_stop(db))
        except ValueError as e:
            db.rollback()
            return J({"ok": False, "error": str(e), "emergency_stop": True}, 409)
    except Exception as e:
        db.rollback()
        return J({"ok": False, "error": str(e)}, 500)
    finally:
        db.close()


async def master_emergency(request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        state = core_service.set_state(db, emergency_stop=True)
        from app.services.demo_worker_supervisor import demo_worker_supervisor
        stopped = demo_worker_supervisor.stop()
        return J({"ok": bool(stopped.get("ok")), "state": state, "worker": stopped},
                 200 if stopped.get("ok") else 503)
    finally:
        db.close()




shadow_service = ShadowTradingService()

async def shadow_order(request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        selected_state = core_service.get_state(db)
        requested_market = p.get("market_type", "spot")
        requested_environment = p.get("environment_mode", "demo")
        if (requested_market != selected_state.get("market_type")
                or requested_environment != selected_state.get("environment_mode")
                or requested_environment != "demo"):
            return J({"detail": "shadow_order_market_must_match_selected_demo_state"}, 409)
        idempotency_key = p.get("idempotency_key")
        if (not isinstance(idempotency_key, str) or not idempotency_key.strip()
                or len(idempotency_key.strip()) > 128):
            return J({"detail": "valid_idempotency_key_required"}, 400)
        res = shadow_service.create_shadow_order(db, env=p.get("environment_mode","demo"), market=p.get("market_type","spot"),
            symbol=p.get("symbol","BTC/USDT"), side=p.get("side","buy"), order_type=p.get("order_type","limit"),
            quantity=float(p.get("quantity",0)), price=p.get("price"), reference_price=p.get("reference_price"),
            idempotency_key=idempotency_key.strip(), simulate=p.get("simulate","fill"), fill_ratio=p.get("fill_ratio",1.0),
            fee_rate=p.get("fee_rate",0.001), mark_price=p.get("mark_price"),
            leverage=p.get("leverage",1.0), reduce_only=p.get("reduce_only",False))
        db.commit()
        return J({"ok": res.ok, "message": res.message, "details": res.details,
                  "order": {"id": res.order.id, "status": res.order.status, "side": res.order.side,
                            "filled_quantity": res.order.filled_quantity, "fees_paid": res.order.fees_paid,
                            "leverage": (res.order.metadata_json or {}).get("leverage", 1.0),
                            "reduce_only": (res.order.metadata_json or {}).get("reduce_only", False),
                            "idempotency_key": res.order.idempotency_key} if res.order else None,
                  "position": {"id": res.position.id, "side": res.position.side,
                               "quantity": res.position.quantity, "entry_avg_price": res.position.entry_avg_price,
                               "leverage": (res.position.metadata_json or {}).get("leverage", 1.0),
                               "unrealized_pnl": res.position.unrealized_pnl} if res.position else None})
    except Exception as e:
        db.rollback(); return J({"detail": str(e)}, 400)
    finally:
        db.close()

async def portfolio(request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err:
            return err
        env = request.query_params.get("environment_mode", "demo")
        market = request.query_params.get("market_type", "spot")
        if market not in {"spot", "futures"}:
            return J({"ok": False, "error": "unsupported_shadow_portfolio_market"}, 400)
        result = shadow_service.get_portfolio(db, env=env, market=market)
        symbols = {str(position.get("symbol")) for position in result.get("positions", []) if position.get("symbol")}
        refresh = {"ok": True, "updated": 0, "source": "none"}
        if symbols:
            try:
                from app.engines.market_data import MarketDataEngine
                prices = MarketDataEngine().get_public_last_prices(symbols, market_type=market)
                updated = shadow_service.update_mark_prices(db, env=env, market=market, prices=prices)
                if updated:
                    shadow_service.record_snapshot(db, env=env, market=market)
                    db.commit()
                    result = shadow_service.get_portfolio(db, env=env, market=market)
                refresh = {
                    "ok": bool(prices), "updated": updated,
                    "source": "binance_futures_mark_price" if market == "futures" else "binance_spot_public_ticker",
                }
            except Exception as exc:
                db.rollback()
                refresh = {"ok": False, "updated": 0, "error": type(exc).__name__}
        result["mark_price_refresh"] = refresh
        return J(result)
    finally:
        db.close()


async def shadow_close(request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        res = shadow_service.close_shadow_position(
            db, position_id=p.get("position_id"),
            close_price=p.get("close_price"), fee_rate=p.get("fee_rate", 0.001),
        )
        db.commit(); return J(res)
    except Exception as e:
        db.rollback(); return J({"detail": str(e)}, 400)
    finally:
        db.close()


async def shadow_position_protection(request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        result = shadow_service.set_position_protection(
            db, position_id=p.get("position_id"),
            stop_loss=p.get("stop_loss") if p.get("stop_loss") not in (None, "") else None,
            take_profit=p.get("take_profit") if p.get("take_profit") not in (None, "") else None,
            trailing_stop_pct=p.get("trailing_stop_pct") if p.get("trailing_stop_pct") not in (None, "") else None,
        )
        db.commit()
        return J(result, 200 if result.get("ok") else 400)
    except Exception as e:
        db.rollback()
        return J({"ok": False, "detail": str(e)}, 400)
    finally:
        db.close()





async def self_diagnosis(request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err and settings.auth_required: return err
        engine = get_engine()
        report = engine.run_full_check()
        # Attempt auto-heal for recoverable issues
        for issue in report.get("issues", []):
            heal = engine.attempt_auto_heal(issue)
            if heal.get("healed"):
                report.setdefault("healed", []).append(heal)
        # Log to audit
        log_event(db, action="self_diagnosis.run", entity_type="system", details={"overall": report["overall"], "issue_count": len(report["issues"])})
        db.commit()
        return J(report)
    except Exception as e:
        db.rollback()
        return J({"detail": str(e)}, 500)
    finally:
        db.close()


async def download_zip(request):
    # Packaged application files may contain private configuration and user data.
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err:
            return err
        zip_path = Path('/storage/emulated/0/Android/data/com.androidharness.app/files/workspace/TITAN_SUPER_AI_PREMIUM_COMPLETE.zip')
        if not zip_path.exists():
            return JSONResponse({"error":"not found"}, status_code=404)
        resp = FileResponse(str(zip_path), filename='TITAN_SUPER_AI_PREMIUM_COMPLETE.zip', media_type='application/octet-stream')
        resp.headers['Content-Disposition'] = 'attachment; filename="TITAN_SUPER_AI_PREMIUM_COMPLETE.zip"'
        return resp
    finally:
        db.close()


async def backup_info(request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err:
            return err
        db_path = settings.database_url.replace('sqlite:///', '')
        data_dir = Path(os.getenv("TITAN_DATA_DIR", "")).expanduser() if os.getenv("TITAN_DATA_DIR", "").strip() else Path(__file__).resolve().parents[1] / "data"
        credentials_path = data_dir / "binance_testnet_creds.json"
        return J({
            "db_path": db_path,
            "credentials_path": str(credentials_path),
            "data_directory": str(data_dir),
            "backup_instructions": "انسخ ملف قاعدة البيانات وملف بيانات الاعتماد المشفرة من مسارات db_path وcredentials_path إلى تخزين احتياطي آمن ومشفر.",
            "note": "يجب أن يكون مسار TITAN_DATA_DIR على تخزين دائم في بيئة الإنتاج. Render Free يستخدم تخزيناً مؤقتاً وقد يفقد البيانات عند إعادة التشغيل أو إعادة النشر."
        })
    finally:
        db.close()


async def export_formats(request):
    libs = {}
    for m in ['openpyxl','reportlab','xlsxwriter']:
        try: __import__(m); libs[m]=True
        except Exception: libs[m]=False
    return J({"formats": {"csv": True, "xlsx": libs['openpyxl'] or libs['xlsxwriter'], "pdf": libs['reportlab']},
              "available_libraries": libs,
              "note": "CSV export is implemented. XLSX/PDF require optional libraries in the target environment; install and extend export service if needed."})


# Binance Testnet (Demo external) - NO real keys, NO live
def _get_binance_adapter(market: str = None):
    stored = load_testnet_credentials()
    mkt = (market or stored.get('market') or os.getenv('BINANCE_TESTNET_MARKET', 'spot')).lower()
    # This integration path is intentionally restricted to Spot Testnet.
    # Futures remains unavailable until its execution and protection engines
    # pass their own readiness verification.
    if mkt != 'spot':
        raise ValueError("spot_testnet_only_until_futures_verified")
    # Prefer stored, fallback to env
    if stored.get('configured'):
        return BinanceTestnetAdapter(BinanceConfig(
            enabled=True, environment='testnet', market=mkt,
            api_key_ref='stored:api_key', api_secret_ref='stored:api_secret'
        ))
    return BinanceTestnetAdapter(BinanceConfig(
        enabled=bool(os.getenv('BINANCE_TESTNET_API_KEY')), environment='testnet', market=mkt,
        api_key_ref='env:BINANCE_TESTNET_API_KEY' if os.getenv('BINANCE_TESTNET_API_KEY') else None,
        api_secret_ref='env:BINANCE_TESTNET_API_SECRET' if os.getenv('BINANCE_TESTNET_API_SECRET') else None,
    ))



async def connect_page(request):
    # The static page cannot attach a bearer token to its initial navigation.
    # Serve the UI shell; every private Binance endpoint independently enforces
    # a valid bearer session before reading credentials or account data.
    try:
        p = Path(__file__).resolve().parent / 'static_connect.html'
        return HTMLResponse(p.read_text(encoding='utf-8'))
    except Exception as e:
        return HTMLResponse(f"<h1>Error</h1><pre>{e}</pre>", status_code=500)


async def binance_testnet_status(request):
    auth_error = _binance_auth_error(request)
    if auth_error:
        return auth_error
    try:
        market = request.query_params.get('market')
        return J(_get_binance_adapter(market).status())
    except Exception as e:
        return J({"ok": False, "error": str(e)}, 400)

async def binance_testnet_order(request):
    auth_error = _binance_auth_error(request)
    if auth_error:
        return auth_error
    try:
        p = await body(request)
        adapter = _get_binance_adapter(p.get('market'))
        res = adapter.place_order(
            symbol=p.get('symbol','BTCUSDT'),
            side=p.get('side','BUY'),
            order_type=p.get('order_type', p.get('type', 'MARKET')),
            quantity=float(p.get('quantity',0)),
            price=p.get('price'),
            leverage=float(p.get('leverage', 1.0)),
            reduce_only=bool(p.get('reduce_only', False))
        )
        return J(res)
    except Exception as e:
        return J({"ok": False, "error": str(e)}, 400)



async def binance_testnet_account(request):
    auth_error = _binance_auth_error(request)
    if auth_error:
        return auth_error
    try:
        market = request.query_params.get('market')
        return J(_get_binance_adapter(market).get_account())
    except Exception as e:
        return J({"ok": False, "error": str(e)}, 400)



async def binance_testnet_reconcile(request):
    auth_error = _binance_auth_error(request)
    if auth_error:
        return auth_error
    # Read-only reconciliation check
    try:
        market = request.query_params.get('market')
        adapter = _get_binance_adapter(market)
        return J(adapter.reconcile(local_open_orders=[]))
    except Exception as e:
        return J({"ok": False, "error": str(e)}, 400)


async def binance_testnet_orders(request):
    auth_error = _binance_auth_error(request)
    if auth_error:
        return auth_error
    try:
        market = request.query_params.get('market')
        symbol = request.query_params.get('symbol')
        return J(_get_binance_adapter(market).get_open_orders(symbol))
    except Exception as e:
        return J({"ok": False, "error": str(e)}, 400)


async def binance_testnet_close(request):
    auth_error = _binance_auth_error(request)
    if auth_error:
        return auth_error
    try:
        p = await body(request)
        adapter = _get_binance_adapter(p.get('market'))
        res = adapter.close_position(
            symbol=p.get('symbol','BTCUSDT'),
            side=p.get('side','BUY'),
            quantity=float(p.get('quantity',0)),
            leverage=float(p.get('leverage', 1.0))
        )
        return J(res)
    except Exception as e:
        return J({"ok": False, "error": str(e)}, 400)

async def binance_testnet_save(request):
    auth_error = _binance_auth_error(request)
    if auth_error:
        return auth_error
    try:
        p = await body(request)
        api_key = (p.get('api_key') or '').strip()
        api_secret = (p.get('api_secret') or '').strip()
        market = (p.get('market') or 'spot').strip().lower()
        if market != 'spot':
            return J({"ok": False, "error": "spot_testnet_only"}, 400)
        if not api_key or not api_secret:
            return J({"ok": False, "error": "api_key_and_secret_required"}, 400)

        # Verify the supplied credentials against Spot Testnet BEFORE persisting.
        # Literal refs are used only by this in-memory adapter instance.
        candidate = BinanceTestnetAdapter(BinanceConfig(
            enabled=True, environment='testnet', market='spot',
            api_key_ref=api_key, api_secret_ref=api_secret,
        ))
        status = candidate.status()
        if not status.get('connected'):
            return J({"ok": False, "saved": False, "error": "spot_testnet_connection_failed",
                      "test_status": status, "note": "Credentials were not stored."}, 400)

        save_testnet_credentials(api_key, api_secret, 'spot')
        return J({"ok": True, "saved": True, "test_status": status,
                  "note": "Spot Testnet credentials verified and stored encrypted server-side. Secret not returned."})
    except Exception as e:
        return J({"ok": False, "saved": False, "error": str(e)}, 400)

async def binance_testnet_delete(request):
    auth_error = _binance_auth_error(request)
    if auth_error:
        return auth_error
    try:
        res = delete_testnet_credentials()
        return J(res)
    except Exception as e:
        return J({"ok": False, "error": str(e)}, 400)

async def binance_testnet_creds_status(request):
    auth_error = _binance_auth_error(request)
    if auth_error:
        return auth_error
    return J(creds_public_status())

async def engines_list_detailed(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        return J({"engines": core_service.get_engines_detailed(db)})
    finally:
        db.close()


async def engine_control(request: Request):
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err: return err
        p = await body(request)
        key = request.path_params.get("engine_key") or p.get("key")
        action = p.get("action") or request.query_params.get("action")
        res = core_service.control_engine(db, key, action, user=user.email if user else "system")
        return J(res)
    except Exception as e:
        return J({"detail": str(e)}, 400)
    finally:
        db.close()


async def export_csv(request):
    import csv, io
    from starlette.responses import Response
    db = db_sess()
    try:
        user, err = require_user(request, db)
        if err and settings.auth_required: return err
        kind = request.query_params.get("kind","orders")
        env = request.query_params.get("environment_mode","demo"); market = request.query_params.get("market_type","spot")
        buf = io.StringIO(); w = csv.writer(buf)
        if kind == "positions":
            rows = db.execute(select(PositionRecord).where(PositionRecord.environment_mode==env, PositionRecord.market_type==market)).scalars().all()
            w.writerow(["id","symbol","side","quantity","entry_avg_price","mark_price","unrealized_pnl","realized_pnl","fees_total","status","shadow"])
            for r in rows: w.writerow([r.id,r.symbol,r.side,r.quantity,r.entry_avg_price,r.mark_price,r.unrealized_pnl,r.realized_pnl,r.fees_total,r.status,r.shadow])
        else:
            rows = db.execute(select(OrderRecord).where(OrderRecord.environment_mode==env, OrderRecord.market_type==market)).scalars().all()
            w.writerow(["id","symbol","side","order_type","quantity","filled_quantity","price","avg_fill_price","status","fees_paid","shadow","idempotency_key"])
            for r in rows: w.writerow([r.id,r.symbol,r.side,r.order_type,r.quantity,r.filled_quantity,r.price,r.avg_fill_price,r.status,r.fees_paid,r.shadow,r.idempotency_key])
        return Response(buf.getvalue(), media_type="text/csv; charset=utf-8", headers={"Content-Disposition": f'attachment; filename="{kind}_{env}_{market}.csv"'})
    finally:
        db.close()

routes = [
    Route("/", connect_page),
    Route("/connect", connect_page),
    Route("/api/health", health),
    Route("/api/system/status", system_status),
    Route("/api/system/state", update_state, methods=["POST"]),
    Route("/api/scanner/spot", scanner_spot),
    Route("/api/scanner/futures", scanner_futures),
    Route("/api/scanner/smart", smart_scanner),
    Route("/api/scanner/smart-futures", smart_scanner_futures),
    Route("/api/fundamentals", fundamental_analysis),
    Route("/api/fundamentals/protocol", protocol_fundamental_analysis),
    Route("/api/economic-calendar", economic_calendar),
    Route("/api/token-unlocks", token_unlocks),
    Route("/api/news", news_analysis),
    Route("/api/backtest/strategy", backtest_strategy, methods=["POST"]),
    Route("/api/backtest/futures", futures_backtest, methods=["POST"]),
    Route("/api/market/microstructure", market_microstructure),
    Route("/api/arbitrage/triangle", arbitrage_analysis, methods=["POST"]),
    Route("/api/performance", performance_analytics),
    Route("/api/telegram/status", telegram_status),
    Route("/api/telegram/poll", telegram_poll),
    Route("/api/telegram/send", telegram_send, methods=["POST"]),
    Route("/api/predictions", prediction_evaluations),
    Route("/api/predictions/evaluate", evaluate_predictions, methods=["POST"]),
    Route("/api/ml/train", ml_train, methods=["POST"]),
    Route("/api/ml/predict", ml_predict, methods=["POST"]),
    Route("/api/ml/drift", ml_drift, methods=["POST"]),
    Route("/api/ml/models", ml_models),
    Route("/api/strategies", strategies),
    Route("/api/analysis/decision", analyze, methods=["POST"]),
    Route("/api/decisions", list_decisions),
    Route("/api/audit", list_audit),
    Route("/api/knowledge", knowledge_list),
    Route("/api/knowledge", knowledge_add, methods=["POST"]),
    Route("/api/knowledge/verify", knowledge_verify, methods=["POST"]),
    Route("/api/knowledge/concepts", knowledge_concepts),
    Route("/api/learning", learning_list),
    Route("/api/learning/strategy-versions", strategy_versions),
    Route("/api/learning/strategy-versions", strategy_version_create, methods=["POST"]),
    Route("/api/learning/strategy-versions/rollback", strategy_version_rollback, methods=["POST"]),
    Route("/api/learning/strategy-proposals", strategy_proposal_create, methods=["POST"]),
    Route("/api/learning/strategy-proposals/test", strategy_proposal_test, methods=["POST"]),
    Route("/api/learning/strategy-proposals/apply-paper", strategy_proposal_apply_paper, methods=["POST"]),
    Route("/api/learning", learning_add, methods=["POST"]),
    Route("/api/auth/status", auth_status),
    Route("/api/auth/login", auth_login, methods=["POST"]),
    Route("/api/auth/logout", auth_logout, methods=["POST"]),
    Route("/api/auth/me", auth_me),
    Route("/api/config/changes", config_changes),
    Route("/api/chat", chat, methods=["POST"]),
    Route("/api/ai/providers", ai_providers),
    Route("/api/ai/providers", ai_provider_create, methods=["POST"]),
    Route("/api/ai/providers/{provider_id:int}/test", ai_provider_test, methods=["POST"]),
    Route("/api/ai/research", ai_research),
    Route("/api/compliance/check-order", compliance_check, methods=["POST"]),
    Route("/api/demo/cycle", demo_cycle, methods=["POST"]),
    Route("/api/master/start", master_start, methods=["POST"]),
    Route("/api/master/stop", master_stop, methods=["POST"]),
    Route("/api/master/emergency-stop", master_emergency, methods=["POST"]),
    Route("/api/master/emergency-reset", master_emergency_reset, methods=["POST"]),
    Route("/api/shadow/order", shadow_order, methods=["POST"]),
    Route("/api/portfolio", portfolio),
    Route("/api/export/csv", export_csv),
    Route("/api/export/formats", export_formats),
    Route("/api/self-diagnosis", self_diagnosis),
    Route("/api/backup/info", backup_info),
    Route("/download", download_zip),
    Route("/api/shadow/close", shadow_close, methods=["POST"]),
    Route("/api/shadow/protection", shadow_position_protection, methods=["POST"]),
    Route("/api/engines", engines_list_detailed),
    Route("/api/engines/detailed", engines_list_detailed),
    Route("/api/engines/{engine_key}/control", engine_control, methods=["POST"]),
    Route("/api/engine/control", engine_control, methods=["POST"]),
    Route("/api/binance/testnet/status", binance_testnet_status),
    Route("/api/binance/testnet/creds", binance_testnet_creds_status),
    Route("/api/binance/testnet/save", binance_testnet_save, methods=["POST"]),
    Route("/api/binance/testnet/delete", binance_testnet_delete, methods=["POST"]),
    Route("/api/binance/testnet/order", binance_testnet_order, methods=["POST"]),
    Route("/api/binance/testnet/close", binance_testnet_close, methods=["POST"]),
    Route("/api/binance/testnet/account", binance_testnet_account),
    Route("/api/binance/testnet/orders", binance_testnet_orders),
    Route("/api/binance/testnet/reconcile", binance_testnet_reconcile),
]


from contextlib import asynccontextmanager

@asynccontextmanager
async def lifespan(app):
    dbmod.init_db()
    db = dbmod.SessionLocal()
    try:
        core_service.ensure_bootstrap(db)
        # Restore the latest persisted model for each symbol/timeframe key.
        from app.engines.hybrid.ml_engine import ml_engine
        model_rows = db.execute(
            select(LearningRecord).where(LearningRecord.category == "ml_model")
            .order_by(desc(LearningRecord.id)).limit(200)
        ).scalars().all()
        loaded_keys = set()
        for row in model_rows:
            model_payload = (row.evidence or {}).get("model")
            if not isinstance(model_payload, dict):
                continue
            model_key = str(model_payload.get("model_key") or row.subject)
            if model_key in loaded_keys:
                continue
            if ml_engine.load_model(model_payload).get("ok"):
                loaded_keys.add(model_key)
    finally:
        db.close()
    try:
        yield
    finally:
        from app.services.demo_worker_supervisor import demo_worker_supervisor
        demo_worker_supervisor.stop(timeout=10.0)

def create_star_app() -> Starlette:
    app = Starlette(routes=routes, lifespan=lifespan)
    configured_origins = (settings.allowed_origins or "").strip()
    if settings.app_env.strip().lower() in {"production", "prod"} and configured_origins == "*":
        # Fail closed in production: same-origin works without CORS; deployers
        # must explicitly allowlist any separately hosted frontend origin.
        origins = []
    else:
        origins = [origin.strip() for origin in configured_origins.split(",") if origin.strip()]
    app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False, allow_methods=["*"], allow_headers=["*"])
    return app

def _startup():
    # kept for compatibility
    pass


app = create_star_app()