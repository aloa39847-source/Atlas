"""Binance Adapter - Testnet/Demo only. NO Live trading, NO withdrawal permissions.
- Spot Testnet: https://testnet.binance.vision
- Futures Testnet: https://testnet.binancefuture.com
All requests routed ONLY to testnet endpoints. Live URLs are blocked.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import time
import urllib.parse
import urllib.request
import urllib.error
from dataclasses import dataclass
from typing import Any

from app.core.enums import MarketType
from app.engines.compliance import compliance_engine
from app.engines.order_gateway import PreTradeOrderGateway


SPOT_TESTNET_BASE = "https://testnet.binance.vision"
FUTURES_TESTNET_BASE = "https://testnet.binancefuture.com"
ALLOWED_BASES = {SPOT_TESTNET_BASE, FUTURES_TESTNET_BASE}


def _resolve_secret(ref: str | None) -> str | None:
    if not ref:
        return None
    if ref.startswith("env:"):
        return os.getenv(ref[4:], "") or None
    if ref.startswith("stored:"):
        try:
            from app.services.credentials import load_testnet_credentials
            c = load_testnet_credentials()
            if ref == "stored:api_key":
                return c.get("api_key") or None
            if ref == "stored:api_secret":
                return c.get("api_secret") or None
        except Exception:
            return None
    return ref


def _sign(params: dict, secret: str) -> str:
    query = urllib.parse.urlencode(params)
    return hmac.new(secret.encode(), query.encode(), hashlib.sha256).hexdigest()


@dataclass
class BinanceConfig:
    enabled: bool = False
    environment: str = "testnet"  # testnet only for external; demo for internal shadow
    market: str = "spot"  # spot or futures
    api_key_ref: str | None = None  # env:BINANCE_TESTNET_API_KEY
    api_secret_ref: str | None = None  # env:BINANCE_TESTNET_API_SECRET
    # base_url is determined by market + testnet; never use live


class BinanceTestnetAdapter:
    name = "binance_testnet"

    def __init__(self, config: BinanceConfig | None = None):
        self.config = config or BinanceConfig()
        self.gateway = PreTradeOrderGateway()

    def _base_url(self) -> str:
        if self.config.market == "futures":
            return FUTURES_TESTNET_BASE
        return SPOT_TESTNET_BASE

    def _api_key(self) -> str | None:
        return _resolve_secret(self.config.api_key_ref)

    def _api_secret(self) -> str | None:
        return _resolve_secret(self.config.api_secret_ref)

    def _request(self, method: str, path: str, signed: bool = False, params: dict | None = None) -> dict:
        base = self._base_url()
        if base not in ALLOWED_BASES:
            raise RuntimeError("live_or_unapproved_endpoint_blocked")
        url = base + path
        params = dict(params or {})
        headers = {"User-Agent": "TITAN-AI-PREMIUM/1.0"}
        key = self._api_key()
        secret = self._api_secret()
        if key:
            headers["X-MBX-APIKEY"] = key
        if signed:
            if not secret:
                raise RuntimeError("missing_api_secret_for_signed_request")
            params["timestamp"] = int(time.time() * 1000)
            params.setdefault("recvWindow", 5000)
            params["signature"] = _sign(params, secret)
        if method.upper() == "GET":
            if params:
                url += "?" + urllib.parse.urlencode(params)
            req = urllib.request.Request(url, headers=headers, method="GET")
        else:
            data = urllib.parse.urlencode(params).encode()
            headers["Content-Type"] = "application/x-www-form-urlencoded"
            req = urllib.request.Request(url, data=data, headers=headers, method=method.upper())
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                body = resp.read().decode()
                try:
                    return json.loads(body)
                except Exception:
                    return {"raw": body}
        except urllib.error.HTTPError as e:
            try:
                err_body = e.read().decode()
                return {"error": "http_error", "status": e.code, "body": err_body}
            except Exception:
                return {"error": "http_error", "status": getattr(e, 'code', None)}
        except Exception as e:
            return {"error": str(e)}

    def status(self) -> dict[str, Any]:
        configured = bool(self._api_key() and self._api_secret())
        result = {
            "provider": self.name,
            "environment": "testnet",
            "market": self.config.market,
            "configured": configured,
            "base_url": self._base_url(),
            "withdrawal_permissions": False,
            "live_blocked": True,
        }
        if configured:
            try:
                if self.config.market == "futures":
                    acct = self._request("GET", "/fapi/v2/account", signed=True)
                else:
                    acct = self._request("GET", "/api/v3/account", signed=True)
                result["connected"] = "error" not in acct
                result["account_check"] = "ok" if "error" not in acct else "error"
            except Exception as e:
                result["connected"] = False
                result["account_check"] = str(e)
        else:
            result["connected"] = False
            result["note"] = "Configure testnet API keys (env refs recommended). No real keys."
        return result

    def _execution_ready(self) -> dict[str, Any] | None:
        if not self.config.enabled:
            return {"ok": False, "sent_to_exchange": False, "error": "testnet_execution_disabled"}
        if self.config.environment != "testnet":
            return {"ok": False, "sent_to_exchange": False, "error": "testnet_environment_required"}
        if self.config.market not in {"spot", "futures"}:
            return {"ok": False, "sent_to_exchange": False, "error": "unsupported_market"}
        if not self._api_key() or not self._api_secret():
            return {"ok": False, "sent_to_exchange": False, "error": "testnet_credentials_missing"}
        return None

    def _symbol_filters(self, symbol: str) -> dict[str, float]:
        info = self.get_exchange_info(symbol)
        if isinstance(info, dict) and info.get("error"):
            raise RuntimeError("exchange_info_unavailable")
        symbols = info.get("symbols", []) if isinstance(info, dict) else []
        target = symbol.replace("/", "").upper()
        row = next((x for x in symbols if str(x.get("symbol", "")).upper() == target), None)
        if not row or row.get("status") not in (None, "TRADING"):
            raise RuntimeError("symbol_not_trading_or_not_found")
        result: dict[str, float] = {}
        for item in row.get("filters", []):
            kind = item.get("filterType")
            if kind in {"LOT_SIZE", "MARKET_LOT_SIZE"} and not result.get("stepSize"):
                result["stepSize"] = float(item.get("stepSize", 0) or 0)
            elif kind == "PRICE_FILTER":
                result["tickSize"] = float(item.get("tickSize", 0) or 0)
            elif kind in {"MIN_NOTIONAL", "NOTIONAL"}:
                result["minNotional"] = float(item.get("minNotional", item.get("notional", 0)) or 0)
        return result

    def _market_price(self, symbol: str) -> float:
        path = "/fapi/v1/ticker/price" if self.config.market == "futures" else "/api/v3/ticker/price"
        result = self._request("GET", path, params={"symbol": symbol.replace("/", "")})
        if isinstance(result, dict) and result.get("error"):
            raise RuntimeError("market_price_unavailable")
        value = float(result.get("price", 0) or 0) if isinstance(result, dict) else 0.0
        if value <= 0:
            raise RuntimeError("invalid_market_price")
        return value


    @staticmethod
    def _base_quote_assets(symbol: str) -> tuple[str, str]:
        normalized = symbol.replace("/", "").upper()
        if "/" in symbol:
            base, quote = symbol.upper().split("/", 1)
            return base, quote
        known_quotes = ("FDUSD", "USDT", "USDC", "BUSD", "TUSD", "BTC", "ETH", "BNB", "TRY", "EUR", "GBP", "BRL", "AUD", "JPY")
        for quote in known_quotes:
            if normalized.endswith(quote) and len(normalized) > len(quote):
                return normalized[:-len(quote)], quote
        raise RuntimeError("unable_to_resolve_spot_base_quote_assets")

    @staticmethod
    def _free_asset_balance(account: dict[str, Any], asset: str) -> float:
        balances = account.get("balances")
        if not isinstance(balances, list):
            raise RuntimeError("spot_account_balances_unavailable")
        row = next((item for item in balances if str(item.get("asset", "")).upper() == asset.upper()), None)
        if row is None:
            return 0.0
        return max(0.0, float(row.get("free", 0) or 0))

    def set_leverage(self, symbol: str, leverage: float) -> dict[str, Any]:
        """Set USD-M Futures Testnet leverage; TITAN hard cap is 10x."""
        blocked = self._execution_ready()
        if blocked:
            return blocked
        if self.config.market != "futures":
            return {"ok": False, "sent_to_exchange": False, "error": "futures_market_required"}
        try:
            lev = float(leverage)
        except (TypeError, ValueError):
            return {"ok": False, "sent_to_exchange": False, "error": "invalid_leverage"}
        if lev < 1 or lev > 10 or not lev.is_integer():
            return {"ok": False, "sent_to_exchange": False, "error": "leverage_outside_titan_cap", "max_leverage": 10}
        result = self._request("POST", "/fapi/v1/leverage", signed=True,
                               params={"symbol": symbol.replace("/", "").upper(), "leverage": int(lev)})
        return {"ok": isinstance(result, dict) and "error" not in result,
                "testnet": True, "response": result, "leverage_requested": int(lev)}

    def place_order(self, symbol: str, side: str, order_type: str, quantity: float,
                    price: float | None = None, *, leverage: float = 1.0,
                    reduce_only: bool = False) -> dict[str, Any]:
        blocked = self._execution_ready()
        if blocked:
            return blocked
        market = MarketType.FUTURES if self.config.market == "futures" else MarketType.SPOT
        try:
            lev = float(leverage)
        except (TypeError, ValueError):
            return {"ok": False, "sent_to_exchange": False, "error": "invalid_leverage"}
        if market == MarketType.SPOT and (lev != 1.0 or reduce_only):
            return {"ok": False, "sent_to_exchange": False, "error": "spot_leverage_or_reduce_only_not_supported"}
        if order_type.upper() not in {"MARKET", "LIMIT"}:
            return {"ok": False, "sent_to_exchange": False, "error": "unsupported_order_type"}
        if market == MarketType.FUTURES and (lev < 1 or lev > 10 or not lev.is_integer()):
            return {"ok": False, "sent_to_exchange": False, "error": "leverage_outside_titan_cap", "max_leverage": 10, "integer_leverage_required": True}
        account = self.get_account()
        if not isinstance(account, dict) or account.get("error") or account.get("canTrade") is not True:
            return {"ok": False, "sent_to_exchange": False, "error": "testnet_account_not_tradeable", "details": account}
        try:
            reference = float(price) if price is not None else self._market_price(symbol)
            filters = self._symbol_filters(symbol)
        except Exception as exc:
            return {"ok": False, "sent_to_exchange": False, "error": "market_metadata_unavailable", "detail": str(exc)}
        pre = self.gateway.validate(
            symbol=symbol, market=market, side=side.lower(), order_type=order_type.lower(),
            quantity=quantity, price=price, reference_price=reference,
            environment_mode="demo", live_enabled=False, bypass_attempt=False,
            reduce_only=reduce_only, exchange_filters=filters,
        )
        if not pre.ok:
            return {"ok": False, "sent_to_exchange": False, "error": "pretrade_blocked", "details": pre.to_dict()}
        if market == MarketType.SPOT:
            try:
                base_asset, quote_asset = self._base_quote_assets(symbol)
                if side.lower() == "buy":
                    asset = quote_asset
                    required_balance = float(pre.normalized.get("notional_estimate") or 0.0) * 1.001
                elif side.lower() == "sell":
                    asset = base_asset
                    required_balance = float(quantity)
                else:
                    return {"ok": False, "sent_to_exchange": False, "error": "invalid_spot_side"}
                available_balance = self._free_asset_balance(account, asset)
            except Exception as exc:
                return {"ok": False, "sent_to_exchange": False, "error": "spot_balance_check_unavailable", "detail": str(exc)}
            if available_balance + 1e-12 < required_balance:
                return {"ok": False, "sent_to_exchange": False, "error": "insufficient_testnet_spot_balance",
                        "asset": asset, "available": available_balance, "required": round(required_balance, 12)}
        if market == MarketType.FUTURES:
            available = float(account.get("availableBalance", 0) or 0)
            required_margin = float(pre.normalized.get("notional_estimate") or 0) / lev
            if available < required_margin * 1.10:
                return {"ok": False, "sent_to_exchange": False, "error": "insufficient_testnet_margin",
                        "available_balance": available, "estimated_initial_margin_with_buffer": round(required_margin * 1.10, 8)}
            lev_result = self.set_leverage(symbol, lev)
            if not lev_result.get("ok"):
                return {"ok": False, "sent_to_exchange": False, "error": "leverage_setup_failed", "details": lev_result}
        params: dict[str, Any] = {
            "symbol": symbol.replace("/", "").upper(),
            "side": side.upper(),
            "type": order_type.upper(),
            "quantity": format(float(quantity), ".12f").rstrip("0").rstrip("."),
        }
        if order_type.upper() == "LIMIT":
            if price is None:
                return {"ok": False, "sent_to_exchange": False, "error": "limit_price_required"}
            params["price"] = format(float(price), ".12f").rstrip("0").rstrip(".")
            params["timeInForce"] = "GTC"
        if market == MarketType.FUTURES and reduce_only:
            params["reduceOnly"] = "true"
        endpoint = "/fapi/v1/order" if market == MarketType.FUTURES else "/api/v3/order"
        res = self._request("POST", endpoint, signed=True, params=params)
        ok = isinstance(res, dict) and "error" not in res
        return {"ok": ok, "sent_to_exchange": ok, "testnet": True, "market": market.value,
                "response": res, "precheck": pre.to_dict(), "leverage": int(lev) if market == MarketType.FUTURES else 1}

    def close_position(self, symbol: str, side: str, quantity: float, *, leverage: float = 1.0) -> dict[str, Any]:
        close_side = "SELL" if side.upper() in ("BUY", "LONG") else "BUY"
        return self.place_order(symbol, close_side, "MARKET", quantity, leverage=leverage,
                                reduce_only=self.config.market == "futures")

    def get_account(self) -> dict[str, Any]:
        if self.config.market == "futures":
            return self._request("GET", "/fapi/v2/account", signed=True)
        return self._request("GET", "/api/v3/account", signed=True)

    def get_open_orders(self, symbol: str | None = None) -> dict[str, Any]:
        params = {}
        if symbol:
            params["symbol"] = symbol.replace("/", "")
        if self.config.market == "futures":
            return self._request("GET", "/fapi/v1/openOrders", signed=True, params=params)
        return self._request("GET", "/api/v3/openOrders", signed=True, params=params)

    def get_exchange_info(self, symbol: str | None = None) -> dict[str, Any]:
        params = {}
        if symbol:
            params["symbol"] = symbol.replace("/", "")
        if self.config.market == "futures":
            return self._request("GET", "/fapi/v1/exchangeInfo", signed=False, params=params)
        return self._request("GET", "/api/v3/exchangeInfo", signed=False, params=params)

    def reconcile(self, local_open_orders: list[dict] | None = None) -> dict[str, Any]:
        """Read-only reconciliation: fetch remote open orders and compare with local state."""
        remote = self.get_open_orders()
        if isinstance(remote, dict) and remote.get("error"):
            return {"ok": False, "error": "remote_fetch_failed", "details": remote, "action": "halt_new_orders_until_resolved"}
        remote_list = remote if isinstance(remote, list) else []
        local = local_open_orders or []
        local_ids = {str(o.get("id") or o.get("orderId") or o.get("clientOrderId")) for o in local}
        remote_ids = {str(o.get("orderId") or o.get("clientOrderId")) for o in remote_list}
        missing_local = [o for o in remote_list if str(o.get("orderId") or o.get("clientOrderId")) not in local_ids]
        missing_remote = [o for o in local if str(o.get("id") or o.get("orderId") or o.get("clientOrderId")) not in remote_ids]
        ok = len(missing_local) == 0 and len(missing_remote) == 0
        return {
            "ok": ok,
            "remote_open_orders_count": len(remote_list),
            "local_open_orders_count": len(local),
            "missing_in_local": len(missing_local),
            "missing_in_remote": len(missing_remote),
            "action": "ok" if ok else "review_required_halt_new_orders",
            "details": {"missing_in_local_sample": missing_local[:3], "missing_in_remote_sample": missing_remote[:3]},
        }

    # Compatibility methods for existing tests/workflows
    def precheck_order(self, **kwargs) -> dict[str, Any]:
        decision = self.gateway.validate(**kwargs)
        return decision.to_dict() if hasattr(decision, 'to_dict') else decision

    def place_order_shadow(self, **kwargs) -> dict[str, Any]:
        pre = self.precheck_order(**kwargs)
        return {"mode": "shadow", "sent_to_exchange": False, "precheck": pre}

    def place_order_live(self, **kwargs) -> dict[str, Any]:
        return {
            "ok": False,
            "sent_to_exchange": False,
            "reason": "live_exchange_execution_not_enabled_in_foundation",
            "required": ["verified_credentials", "symbol_filters", "balance_sync", "order_reconciliation", "rate_limit_control", "compliance_allow", "explicit_user_approval_for_live"],
        }


# Keep old name for compatibility
BinanceAdapter = BinanceTestnetAdapter
BinanceConfig = BinanceConfig
