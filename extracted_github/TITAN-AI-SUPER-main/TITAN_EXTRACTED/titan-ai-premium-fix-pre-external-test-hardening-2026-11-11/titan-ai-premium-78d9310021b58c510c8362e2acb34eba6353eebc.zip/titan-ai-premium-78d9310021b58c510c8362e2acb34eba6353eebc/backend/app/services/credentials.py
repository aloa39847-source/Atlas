"""Secure credential storage for Binance Testnet keys.
Keys are obfuscated with server secret and stored server-side only.
Never log or expose secrets to frontend after save.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path
from typing import Any

from cryptography.fernet import Fernet, InvalidToken

from app.core.config import settings


def _key_bytes() -> bytes:
    return hashlib.sha256((settings.secret_key or "titan-dev").encode()).digest()


def _xor(data: bytes, key: bytes) -> bytes:
    return bytes(b ^ key[i % len(key)] for i, b in enumerate(data))


def _fernet() -> Fernet:
    secret = settings.secret_key or ""
    if secret == "dev-only-change-locally" or len(secret) < 32:
        raise RuntimeError("strong_titan_secret_key_required_for_credential_storage")
    key = base64.urlsafe_b64encode(hashlib.sha256(secret.encode("utf-8")).digest())
    return Fernet(key)


def encrypt_secret(text: str) -> str:
    if not text:
        return ""
    return "v2:" + _fernet().encrypt(text.encode("utf-8")).decode("ascii")


def decrypt_secret(token: str) -> str:
    if not token:
        return ""
    if token.startswith("v2:"):
        try:
            return _fernet().decrypt(token[3:].encode("ascii")).decode("utf-8")
        except (InvalidToken, ValueError, RuntimeError, UnicodeDecodeError):
            return ""
    # Backward compatibility for credentials saved by the original
    # unauthenticated XOR format. New writes always use Fernet v2.
    try:
        enc = base64.urlsafe_b64decode(token.encode())
        raw = _xor(enc, _key_bytes())
        return raw.decode()
    except Exception:
        return ""


def _storage_path() -> Path:
    # Use a configured persistent data directory when deployed; otherwise keep
    # the local development default. Secrets remain server-side only.
    configured_dir = os.getenv("TITAN_DATA_DIR", "").strip()
    base = Path(configured_dir) if configured_dir else Path(__file__).resolve().parents[2] / "data"
    base.mkdir(parents=True, exist_ok=True)
    return base / "binance_testnet_creds.json"


def save_testnet_credentials(api_key: str, api_secret: str, market: str = "spot") -> dict[str, Any]:
    # Never store in logs; only encrypted
    data = {
        "market": market if market in ("spot", "futures") else "spot",
        "api_key_enc": encrypt_secret(api_key.strip()),
        "api_secret_enc": encrypt_secret(api_secret.strip()),
        "has_key": bool(api_key.strip()),
        "has_secret": bool(api_secret.strip()),
    }
    path = _storage_path()
    path.write_text(json.dumps(data))
    try:
        os.chmod(path, 0o600)
    except Exception:
        pass
    return {"ok": True, "saved": True, "market": data["market"], "note": "Secrets stored encrypted server-side. Not shown in UI."}


def load_testnet_credentials() -> dict[str, Any]:
    path = _storage_path()
    if not path.exists():
        return {"configured": False}
    try:
        data = json.loads(path.read_text())
        api_key = decrypt_secret(data.get("api_key_enc", ""))
        api_secret = decrypt_secret(data.get("api_secret_enc", ""))
        return {
            "configured": bool(data.get("has_key") and data.get("has_secret") and api_key and api_secret),
            "market": data.get("market", "spot"),
            "api_key": api_key,
            "api_secret": api_secret,
        }
    except Exception:
        return {"configured": False}


def delete_testnet_credentials() -> dict[str, Any]:
    path = _storage_path()
    if path.exists():
        path.unlink()
    return {"ok": True, "deleted": True}


def public_status() -> dict[str, Any]:
    creds = load_testnet_credentials()
    return {
        "configured": creds.get("configured", False),
        "market": creds.get("market", "spot"),
        "has_secret": bool(creds.get("configured")),
        # Never expose key/secret
    }
