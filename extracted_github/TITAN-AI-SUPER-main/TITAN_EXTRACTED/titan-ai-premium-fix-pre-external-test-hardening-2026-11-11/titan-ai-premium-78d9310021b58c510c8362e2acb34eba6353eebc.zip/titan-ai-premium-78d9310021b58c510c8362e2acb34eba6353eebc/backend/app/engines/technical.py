from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Sequence

from app.core.enums import EngineStatus, Timeframe
from .base import Engine


def _f(v: Any) -> float | None:
    if v is None:
        return None
    try:
        fv = float(v)
        return None if math.isnan(fv) or math.isinf(fv) else fv
    except Exception:
        return None


def _sma(vals: Sequence[float], n: int) -> list[float | None]:
    out: list[float | None] = [None] * len(vals)
    if n <= 0:
        return out
    s = 0.0
    for i, v in enumerate(vals):
        s += float(v)
        if i >= n:
            s -= float(vals[i - n])
        if i >= n - 1:
            out[i] = s / n
    return out


def _ema(vals: Sequence[float], n: int) -> list[float | None]:
    out: list[float | None] = [None] * len(vals)
    if n <= 0 or len(vals) < n:
        return out
    alpha = 2.0 / (n + 1.0)
    seed = sum(float(x) for x in vals[:n]) / n
    out[n - 1] = seed
    prev = seed
    for i in range(n, len(vals)):
        prev = alpha * float(vals[i]) + (1 - alpha) * prev
        out[i] = prev
    return out


def _ema_wilder(vals: Sequence[float], n: int) -> list[float | None]:
    out: list[float | None] = [None] * len(vals)
    if n <= 0 or len(vals) < n:
        return out
    alpha = 1.0 / n
    seed = sum(float(x) for x in vals[:n]) / n
    out[n - 1] = seed
    prev = seed
    for i in range(n, len(vals)):
        prev = alpha * float(vals[i]) + (1 - alpha) * prev
        out[i] = prev
    return out


def _rsi(close: Sequence[float], n: int = 14) -> list[float | None]:
    out: list[float | None] = [None] * len(close)
    if isinstance(n, bool) or not isinstance(n, int) or n <= 0:
        return out
    try:
        prices = [float(value) for value in close]
    except (TypeError, ValueError, OverflowError):
        return out
    if not all(math.isfinite(value) for value in prices) or len(prices) < n + 1:
        return out
    deltas = [prices[i] - prices[i - 1] for i in range(1, len(prices))]
    gains = [max(d, 0.0) for d in deltas]
    losses = [max(-d, 0.0) for d in deltas]
    avg_g = _ema_wilder(gains, n)
    avg_l = _ema_wilder(losses, n)
    for i in range(len(avg_g)):
        g, l = avg_g[i], avg_l[i]
        if g is None or l is None:
            continue
        if l == 0 and g == 0:
            out[i + 1] = 50.0
        elif l == 0:
            out[i + 1] = 100.0
        elif g == 0:
            out[i + 1] = 0.0
        else:
            rs = g / l
            out[i + 1] = 100.0 - (100.0 / (1.0 + rs))
    return out


def _atr(high: Sequence[float], low: Sequence[float], close: Sequence[float], n: int = 14) -> list[float | None]:
    trs: list[float] = []
    for i in range(len(close)):
        if i == 0:
            trs.append(float(high[i]) - float(low[i]))
        else:
            pc = float(close[i - 1])
            trs.append(max(float(high[i]) - float(low[i]), abs(float(high[i]) - pc), abs(float(low[i]) - pc)))
    return _ema_wilder(trs, n)


def _macd(close: Sequence[float]) -> dict[str, list[float | None]]:
    ema12 = _ema(close, 12)
    ema26 = _ema(close, 26)
    line: list[float | None] = [None] * len(close)
    vals = []
    idxs = []
    for i in range(len(close)):
        if ema12[i] is not None and ema26[i] is not None:
            v = ema12[i] - ema26[i]  # type: ignore
            line[i] = v
            vals.append(v)
            idxs.append(i)
    signal_vals = _ema(vals, 9) if vals else []
    signal: list[float | None] = [None] * len(close)
    hist: list[float | None] = [None] * len(close)
    for j, i in enumerate(idxs):
        sv = signal_vals[j] if j < len(signal_vals) else None
        signal[i] = sv
        if line[i] is not None and sv is not None:
            hist[i] = line[i] - sv  # type: ignore
    return {"macd": line, "macd_signal": signal, "macd_hist": hist}


def _last(seq: Sequence[Any]) -> Any:
    return seq[-1] if seq else None


def _rolling_std(vals: Sequence[float], n: int) -> list[float | None]:
    out: list[float | None] = [None] * len(vals)
    for i in range(n - 1, len(vals)):
        w = [float(x) for x in vals[i - n + 1 : i + 1]]
        m = sum(w) / n
        var = sum((x - m) ** 2 for x in w) / n
        out[i] = math.sqrt(var)
    return out


@dataclass
class TimeframeAnalysis:
    timeframe: Timeframe
    trend: str
    signals: list[str]
    indicators: dict[str, Any]
    structure: dict[str, Any]
    candles: dict[str, Any]


class TechnicalAnalysisEngine(Engine):
    key = "technical_analysis"
    name = "Technical Analysis Engine"

    def status(self) -> EngineStatus:
        return EngineStatus.IMPLEMENTED_PARTIAL

    def analyze(self, df: Any, timeframe: Timeframe) -> TimeframeAnalysis:
        # df: Candles container or compatible (supports ["close"] lists, len, iloc)
        try:
            open_prices = [float(x) for x in df["open"]]
            high = [float(x) for x in df["high"]]
            low = [float(x) for x in df["low"]]
            close = [float(x) for x in df["close"]]
            vol = [float(x) for x in df["volume"]] if "volume" in getattr(df, "columns", []) else [0.0] * len(close)
        except Exception:
            return TimeframeAnalysis(timeframe, "unknown", ["invalid_data"], {}, {}, {})
        if len(close) < 30:
            return TimeframeAnalysis(timeframe, "unknown", ["insufficient_data"], {}, {}, {})
        if not (len(open_prices) == len(high) == len(low) == len(close) == len(vol)):
            return TimeframeAnalysis(timeframe, "unknown", ["invalid_data_lengths"], {}, {}, {})
        if (not all(math.isfinite(value) for series in (open_prices, high, low, close, vol) for value in series)
                or any(value <= 0 for series in (open_prices, high, low, close) for value in series)
                or any(value < 0 for value in vol)
                or any(h < max(o, c, l) or l > min(o, c, h)
                       for o, h, l, c in zip(open_prices, high, low, close))):
            return TimeframeAnalysis(timeframe, "unknown", ["invalid_ohlcv_integrity"], {}, {}, {})

        rsi = _rsi(close)
        macd = _macd(close)
        bb_mid = _sma(close, 20)
        bb_std = _rolling_std(close, 20)
        atr = _atr(high, low, close)
        ema20 = _ema(close, 20)
        # Never relabel a shorter EMA as EMA50; insufficient history stays unavailable.
        ema50 = _ema(close, 50)
        sma20 = _sma(close, 20)
        vol_sma20 = _sma(vol, 20)

        bbm = _last(bb_mid); bbs = _last(bb_std)
        last = {
            "close": _f(close[-1]),
            "rsi14": _f(_last(rsi)),
            "macd": _f(_last(macd["macd"])),
            "macd_signal": _f(_last(macd["macd_signal"])),
            "macd_hist": _f(_last(macd["macd_hist"])),
            "ema20": _f(_last(ema20)),
            "ema50": _f(_last(ema50)),
            "sma20": _f(_last(sma20)),
            "bb_upper": _f(bbm + 2 * bbs) if bbm is not None and bbs is not None else None,
            "bb_mid": _f(bbm),
            "bb_lower": _f(bbm - 2 * bbs) if bbm is not None and bbs is not None else None,
            "atr14": _f(_last(atr)),
            "volume_last": _f(vol[-1]),
            "volume_sma20": _f(_last(vol_sma20)),
            "volume_ratio": _f((vol[-1] / vol_sma20[-1]) if vol_sma20 and vol_sma20[-1] not in (None, 0) else None),
        }

        signals: list[str] = []
        trend = "sideways"
        e20, e50 = last["ema20"], last["ema50"]
        c = last["close"] or 0
        if e20 is not None and e50 is not None:
            if c > e20 > e50:
                trend = "bullish"; signals.append("price_above_ema20_ema50")
            elif c < e20 < e50:
                trend = "bearish"; signals.append("price_below_ema20_ema50")
        rv = last["rsi14"]
        if rv is not None:
            if rv < 30: signals.append("rsi_oversold")
            elif rv > 70: signals.append("rsi_overbought")
        mh = last["macd_hist"]
        if mh is not None:
            signals.append("macd_hist_positive" if mh > 0 else "macd_hist_negative")

        structure = self._market_structure(high, low, close)
        # Expose only close-confirmed structural events as strategy signals.
        # Wick-only excursions remain recorded as false breakouts in evidence.
        for breakout in structure.get("breakouts", []):
            if breakout.get("status") == "confirmed":
                signals.append(f"breakout_{breakout.get('direction')}")
        for event in structure.get("bos_choch", []):
            event_type = str(event.get("type") or "").lower()
            direction = str(event.get("direction") or "").lower()
            if event_type in {"bos", "choch"} and direction in {"bullish", "bearish"}:
                signals.append(f"{event_type}_{direction}")
        candles = self._candle_patterns(df)
        signals.extend(candles.get("patterns", []))
        volume_ratio = last.get("volume_ratio")
        if volume_ratio is not None and volume_ratio >= 1.5:
            signals.append("volume_spike")
        elif volume_ratio is not None and volume_ratio <= 0.5:
            signals.append("volume_below_average")
        if last["bb_upper"] is not None and c >= last["bb_upper"]:
            signals.append("bollinger_upper_band_touch")
        elif last["bb_lower"] is not None and c <= last["bb_lower"]:
            signals.append("bollinger_lower_band_touch")
        return TimeframeAnalysis(timeframe, trend, signals, last, structure, candles)

    def _market_structure(self, highs: list[float], lows: list[float], closes: list[float] | None = None) -> dict[str, Any]:
        n = min(len(highs), len(lows))
        window = 3
        swing_highs = [i for i in range(window, n - window) if highs[i] == max(highs[i - window : i + window + 1])]
        swing_lows = [i for i in range(window, n - window) if lows[i] == min(lows[i - window : i + window + 1])]
        sh = swing_highs[-4:]; sl = swing_lows[-4:]
        high_tag = "HH" if len(sh) >= 2 and highs[sh[-1]] > highs[sh[-2]] else "LH" if len(sh) >= 2 else None
        low_tag = "HL" if len(sl) >= 2 and lows[sl[-1]] > lows[sl[-2]] else "LL" if len(sl) >= 2 else None
        tags = [x for x in (high_tag, low_tag) if x]
        bias = "neutral"
        if high_tag == "HH" and low_tag == "HL": bias = "bullish_structure"
        elif high_tag == "LH" and low_tag == "LL": bias = "bearish_structure"
        bos_choch: list[dict[str, Any]] = []
        breakouts: list[dict[str, Any]] = []
        if closes and len(closes) >= 1:
            last_close, last_high, last_low = float(closes[-1]), float(highs[-1]), float(lows[-1])
            if sh:
                level = float(highs[sh[-1]])
                if last_high > level:
                    confirmed = last_close > level
                    breakouts.append({"direction": "bullish", "level": level, "confirmed_by_close": confirmed,
                                      "status": "confirmed" if confirmed else "false_breakout", "wick_extreme": last_high, "close": last_close})
                    if confirmed:
                        kind = "CHOCH" if bias == "bearish_structure" else "BOS"
                        bos_choch.append({"type": kind, "direction": "bullish", "level": level})
            if sl:
                level = float(lows[sl[-1]])
                if last_low < level:
                    confirmed = last_close < level
                    breakouts.append({"direction": "bearish", "level": level, "confirmed_by_close": confirmed,
                                      "status": "confirmed" if confirmed else "false_breakout", "wick_extreme": last_low, "close": last_close})
                    if confirmed:
                        kind = "CHOCH" if bias == "bullish_structure" else "BOS"
                        bos_choch.append({"type": kind, "direction": "bearish", "level": level})
        def swing_points(indices: list[int], values: list[float]) -> list[dict[str, Any]]:
            return [{"index": i, "price": float(values[i])} for i in indices[-4:]]
        return {
            "swing_tags": tags, "high_structure": high_tag, "low_structure": low_tag, "bias": bias,
            "swing_high_count": len(swing_highs), "swing_low_count": len(swing_lows),
            "minor_swings": {"highs": swing_points(swing_highs, highs), "lows": swing_points(swing_lows, lows)},
            "major_swings": {"highs": swing_points(swing_highs[-2:], highs), "lows": swing_points(swing_lows[-2:], lows)},
            "bos_choch": bos_choch, "breakouts": breakouts,
            "liquidity_zones": {"swing_highs": [highs[i] for i in sh[-3:]], "swing_lows": [lows[i] for i in sl[-3:]]},
            "note": "Swing structure, BOS/CHOCH and close-confirmed/false breakouts are heuristic estimates, not certainty."
        }

    def _candle_patterns(self, df: Any) -> dict[str, Any]:
        try:
            rows = df.rows if hasattr(df, "rows") else list(df)
        except Exception:
            return {"patterns": []}
        if len(rows) < 2:
            return {"patterns": []}
        def candle(row):
            o, h, l, c = map(float, [row["open"], row["high"], row["low"], row["close"]])
            return {"open": o, "high": h, "low": l, "close": c, "body": abs(c-o),
                    "range": max(h-l, 1e-12), "upper_wick": h-max(o,c), "lower_wick": min(o,c)-l}
        prev, cur = candle(rows[-2]), candle(rows[-1])
        patterns: list[str] = []
        bullish = cur["close"] > cur["open"]
        bearish = cur["close"] < cur["open"]
        if bullish: patterns.append("bullish_candle")
        elif bearish: patterns.append("bearish_candle")
        body, rng = cur["body"], cur["range"]
        upper, lower = cur["upper_wick"], cur["lower_wick"]
        if body / rng <= 0.1: patterns.append("doji")
        if prev["close"] < prev["open"] and bullish and cur["close"] >= prev["open"] and cur["open"] <= prev["close"]:
            patterns.append("bullish_engulfing")
        if prev["close"] > prev["open"] and bearish and cur["open"] >= prev["close"] and cur["close"] <= prev["open"]:
            patterns.append("bearish_engulfing")
        prior_closes = [float(r["close"]) for r in rows[-6:-1]]
        prior_trend = "up" if len(prior_closes) >= 2 and prior_closes[-1] > prior_closes[0] else "down" if len(prior_closes) >= 2 and prior_closes[-1] < prior_closes[0] else "sideways"
        lower_pin = lower >= max(body * 2.0, rng * 0.55) and upper <= max(body * 0.6, rng * 0.12)
        upper_pin = upper >= max(body * 2.0, rng * 0.55) and lower <= max(body * 0.6, rng * 0.12)
        if lower_pin:
            patterns.append("pin_bar_bullish")
            patterns.append("hammer" if prior_trend == "down" else "hanging_man" if prior_trend == "up" else "hammer_like")
        if upper_pin:
            patterns.append("pin_bar_bearish")
            patterns.append("shooting_star" if prior_trend == "up" else "shooting_star_like")
        if len(rows) >= 3:
            first = candle(rows[-3])
            middle = candle(rows[-2])
            first_mid = (first["open"] + first["close"]) / 2
            middle_small = middle["body"] / middle["range"] <= 0.35
            if first["close"] < first["open"] and middle_small and bullish and cur["close"] > first_mid:
                patterns.append("morning_star")
            if first["close"] > first["open"] and middle_small and bearish and cur["close"] < first_mid:
                patterns.append("evening_star")
        close_strength = (cur["close"] - cur["low"]) / rng
        return {
            "patterns": patterns, "direction": "bullish" if bullish else "bearish" if bearish else "neutral",
            "body_to_range": round(body / rng, 4), "upper_wick_to_body": round(upper / max(body, 1e-12), 4),
            "lower_wick_to_body": round(lower / max(body, 1e-12), 4),
            "close_strength": round(close_strength, 4), "prior_trend_context": prior_trend,
        }
