"""Binance Public Data Adapter - Read-only, no API keys
Only public endpoints. No order placement.
"""
from __future__ import annotations

import json
import math
import os
import urllib.request
from urllib.parse import urlencode
from typing import Any


class BinancePublicData:
    BASE = os.getenv("BINANCE_PUBLIC_BASE_URL", "https://data-api.binance.vision")

    def _get_json(self, endpoint: str) -> Any:
        url = f"{self.BASE}{endpoint}"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "TITAN-AI-PREMIUM/1.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read().decode())
        except Exception as e:
            raise RuntimeError(f"binance_public_error:{e}")

    def get_spot_exchange_info(self) -> dict[str, Any]:
        """Read-only Spot symbol metadata from Binance public API."""
        data = self._get_json("/api/v3/exchangeInfo")
        if not isinstance(data, dict) or not isinstance(data.get("symbols"), list):
            raise RuntimeError("binance_public_invalid_exchange_info")
        return data

    def get_24h_tickers(self) -> list[dict[str, Any]]:
        """Read-only 24h ticker statistics for all symbols."""
        data = self._get_json("/api/v3/ticker/24hr")
        if not isinstance(data, list):
            raise RuntimeError("binance_public_invalid_24h_tickers")
        return data

    def get_klines(self, symbol: str, interval: str, limit: int = 500) -> list[list[Any]]:
        # Public Spot candle requests are restricted to the project's supported intervals.
        normalized = str(symbol or "").replace("/", "").upper()
        allowed_intervals = {"1d", "4h", "1h", "15m", "5m"}
        if (not normalized.isascii() or not normalized.isalnum() or not 5 <= len(normalized) <= 30
                or not isinstance(interval, str) or interval not in allowed_intervals
                or isinstance(limit, bool) or not isinstance(limit, int) or not 30 <= limit <= 1000):
            raise ValueError("invalid_klines_symbol_interval_or_limit")
        url = f"{self.BASE}/api/v3/klines?" + urlencode({
            "symbol": normalized, "interval": interval, "limit": limit,
        })
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "TITAN-AI-PREMIUM/1.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
            if not isinstance(data, list):
                raise RuntimeError("binance_public_invalid_klines")
            return data
        except Exception as e:
            raise RuntimeError(f"binance_public_error:{e}")

    def get_order_book(self, symbol: str, limit: int = 100) -> dict[str, Any]:
        """Read-only Spot order-book depth snapshot."""
        normalized = str(symbol or "").replace("/", "").upper()
        allowed_limits = {5, 10, 20, 50, 100, 500, 1000}
        if (not normalized.isascii() or not normalized.isalnum() or not 5 <= len(normalized) <= 30
                or isinstance(limit, bool) or not isinstance(limit, int) or limit not in allowed_limits):
            raise ValueError("invalid_order_book_symbol_or_limit")
        data = self._get_json("/api/v3/depth?" + urlencode({"symbol": normalized, "limit": limit}))
        if not isinstance(data, dict) or not isinstance(data.get("bids"), list) or not isinstance(data.get("asks"), list):
            raise RuntimeError("binance_public_invalid_order_book")
        return data

    def get_aggregate_trades(self, symbol: str, limit: int = 500) -> list[dict[str, Any]]:
        """Read-only recent aggregate trades for taker-flow analysis."""
        normalized = str(symbol or "").replace("/", "").upper()
        if (not normalized.isascii() or not normalized.isalnum() or not 5 <= len(normalized) <= 30
                or isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 1000):
            raise ValueError("invalid_aggregate_trade_symbol_or_limit")
        data = self._get_json("/api/v3/aggTrades?" + urlencode({"symbol": normalized, "limit": limit}))
        if not isinstance(data, list) or any(not isinstance(item, dict) for item in data):
            raise RuntimeError("binance_public_invalid_aggregate_trades")
        return data

    def klines_to_candles(self, klines: list[list[Any]]) -> list[dict]:
        if not isinstance(klines, list):
            raise RuntimeError("binance_public_invalid_klines_container")
        candles = []
        previous_timestamp = None
        for index, row in enumerate(klines):
            if not isinstance(row, (list, tuple)) or len(row) < 7:
                raise RuntimeError(f"binance_public_invalid_kline_row:{index}")
            if any(isinstance(value, bool) for value in row[:7]):
                raise RuntimeError(f"binance_public_invalid_kline_boolean:{index}")
            try:
                timestamp = int(row[0])
                close_time = int(row[6])
                open_price, high, low, close, volume = (
                    float(row[1]), float(row[2]), float(row[3]), float(row[4]), float(row[5])
                )
            except (TypeError, ValueError, OverflowError):
                raise RuntimeError(f"binance_public_invalid_kline_values:{index}")
            numeric = (open_price, high, low, close, volume)
            if (timestamp <= 0 or close_time < timestamp
                    or (previous_timestamp is not None and timestamp <= previous_timestamp)
                    or not all(math.isfinite(value) for value in numeric)
                    or min(open_price, high, low, close) <= 0 or volume < 0
                    or high < max(open_price, close, low)
                    or low > min(open_price, close, high)):
                raise RuntimeError(f"binance_public_invalid_kline_integrity:{index}")
            candles.append({
                "timestamp": timestamp, "close_time": close_time,
                "open": open_price, "high": high, "low": low,
                "close": close, "volume": volume, "source": "binance_public",
            })
            previous_timestamp = timestamp
        return candles
