"""In-process lifecycle supervisor for the safe Demo/Shadow worker.

The supervisor owns exactly one joinable worker thread. It never starts an
exchange adapter, reads credentials, or submits external orders.
"""
from __future__ import annotations

import threading
import time
from typing import Any


class DemoWorkerSupervisor:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._thread: threading.Thread | None = None
        self._stop_event: threading.Event | None = None
        self._last_exit_code: int | None = None
        self._last_error: str | None = None
        self._symbols: list[str] | None = None
        self._market: str = "spot"

    def start(self, *, interval_seconds: int = 300, symbols: list[str] | None = None, market: str = "spot") -> dict[str, Any]:
        if market not in {"spot", "futures"}:
            return {"ok": False, "error": "unsupported_demo_worker_market"}
        if symbols is not None and (not symbols or any("/" not in item for item in symbols)):
            return {"ok": False, "error": "invalid_worker_symbols"}
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return {"ok": False, "error": "demo_worker_already_running"}
            self._stop_event = threading.Event()
            self._last_exit_code = None
            self._last_error = None
            self._symbols = list(symbols) if symbols is not None else None
            self._market = market
            stop_event = self._stop_event

            def target() -> None:
                try:
                    from app.scripts.run_demo_loop import run
                    self._last_exit_code = run(
                        interval_seconds=interval_seconds,
                        symbols=symbols,
                        once=False,
                        stop_event=stop_event,
                        market=market,
                    )
                except Exception as exc:
                    self._last_error = f"{type(exc).__name__}:{exc}"
                    try:
                        from app.models import db as dbmod
                        from app.models.entities import SystemState
                        db = dbmod.SessionLocal()
                        try:
                            state = db.get(SystemState, 1)
                            if state is not None:
                                from datetime import datetime, timezone
                                state.bot_run_state = "stopped"
                                state.autonomous_enabled = False
                                state.emergency_stop = True
                                state.bot_stop_reason = "worker_start_or_runtime_failure"
                                state.bot_stopped_at = datetime.now(timezone.utc)
                                db.add(state)
                                db.commit()
                        finally:
                            db.close()
                    except Exception:
                        pass

            self._thread = threading.Thread(
                target=target,
                name="titan-demo-shadow-worker",
                daemon=False,
            )
            self._thread.start()

        # Do not report success until the worker has moved the shared state to
        # running. A fast startup failure is returned as a failure, not a fake OK.
        deadline = time.monotonic() + 3.0
        while time.monotonic() < deadline:
            thread = self._thread
            if thread is None or not thread.is_alive():
                return {
                    "ok": False,
                    "error": "demo_worker_exited_during_startup",
                    "exit_code": self._last_exit_code,
                    "detail": self._last_error,
                }
            try:
                from app.models import db as dbmod
                from app.models.entities import SystemState
                db = dbmod.SessionLocal()
                try:
                    state = db.get(SystemState, 1)
                    if state is not None and state.bot_run_state == "running":
                        return {"ok": True, "running": True, "thread_name": thread.name}
                    if state is not None and state.bot_run_state == "stopped":
                        return {
                            "ok": False,
                            "error": "demo_worker_stopped_during_startup",
                            "stop_reason": state.bot_stop_reason,
                            "detail": self._last_error,
                        }
                finally:
                    db.close()
            except Exception:
                pass
            time.sleep(0.05)
        self.stop(timeout=2.0)
        return {"ok": False, "error": "demo_worker_startup_timeout"}

    def stop(self, *, timeout: float = 10.0) -> dict[str, Any]:
        with self._lock:
            thread = self._thread
            event = self._stop_event
            if thread is None or not thread.is_alive():
                return {"ok": True, "stopped": True, "already_stopped": True}
            if event is not None:
                event.set()
        thread.join(timeout=max(0.0, float(timeout)))
        stopped = not thread.is_alive()
        return {
            "ok": stopped,
            "stopped": stopped,
            "error": None if stopped else "demo_worker_stop_timeout",
            "thread_name": thread.name,
        }

    def status(self) -> dict[str, Any]:
        thread = self._thread
        alive = bool(thread and thread.is_alive())
        return {
            "running": alive,
            "thread_name": thread.name if alive and thread else None,
            "symbol_mode": ("auto_smart_scan" if self._symbols is None else "fixed_symbols") if alive else None,
            "market": self._market if alive else None,
            "last_exit_code": self._last_exit_code,
            "last_error": self._last_error,
        }


demo_worker_supervisor = DemoWorkerSupervisor()
