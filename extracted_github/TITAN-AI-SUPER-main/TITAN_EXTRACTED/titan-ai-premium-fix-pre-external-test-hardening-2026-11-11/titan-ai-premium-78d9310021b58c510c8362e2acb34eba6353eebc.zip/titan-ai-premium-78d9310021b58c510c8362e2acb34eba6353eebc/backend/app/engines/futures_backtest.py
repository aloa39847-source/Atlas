"""Isolated-margin Futures backtest with funding, partial fills and liquidation estimates.

This is a conservative research simulator, not an exchange-matching engine.
It models one position at a time and does not submit orders.
"""
from __future__ import annotations

import math
from typing import Any, Sequence


class FuturesBacktestEngine:
    def __init__(
        self,
        *,
        initial_cash: float = 10_000.0,
        fee_rate: float = 0.0004,
        slippage_rate: float = 0.0005,
        allocation_fraction: float = 0.5,
        max_notional: float = 800.0,
        max_leverage: float = 10.0,
        maintenance_margin_rate: float = 0.005,
        liquidation_fee_rate: float = 0.005,
    ) -> None:
        raw = (initial_cash, fee_rate, slippage_rate, allocation_fraction, max_notional,
               max_leverage, maintenance_margin_rate, liquidation_fee_rate)
        if any(isinstance(value, bool) for value in raw):
            raise ValueError("boolean_futures_backtest_configuration_not_allowed")
        try:
            values = [float(value) for value in raw]
        except (TypeError, ValueError, OverflowError):
            raise ValueError("invalid_futures_backtest_configuration")
        if not all(math.isfinite(value) for value in values):
            raise ValueError("non_finite_futures_backtest_configuration")
        (self.initial_cash, self.fee_rate, self.slippage_rate, self.allocation_fraction,
         self.max_notional, self.max_leverage, self.maintenance_margin_rate,
         self.liquidation_fee_rate) = values
        if (self.initial_cash <= 0 or not 0 <= self.fee_rate < 1
                or not 0 <= self.slippage_rate < 1
                or not 0 < self.allocation_fraction <= 1
                or self.max_notional <= 0 or self.max_leverage < 1
                or not 0 < self.maintenance_margin_rate < 0.5
                or not 0 <= self.liquidation_fee_rate < 1):
            raise ValueError("futures_backtest_configuration_out_of_range")

    @staticmethod
    def _empty(reason: str, initial_cash: float) -> dict[str, Any]:
        return {
            "ok": False, "error": reason, "total_trades": 0, "win_rate": 0.0,
            "total_return": 0.0, "final_equity": round(initial_cash, 8),
            "fees_paid": 0.0, "slippage_cost": 0.0, "funding_net": 0.0,
            "liquidations": 0, "partial_fills": 0, "trades": [],
            "equity_curve": [round(initial_cash, 8)], "no_lookahead": False,
            "signal_causality": "not_verified_for_external_signals",
        }

    def run_strategy(
        self,
        candles: list[dict],
        *,
        strategy_key: str,
        timeframe,
        funding_events: Sequence[dict] = (),
        leverage: float = 1.0,
        notional: float | None = None,
        entry_fill_ratio: float = 1.0,
        exit_fill_ratio: float = 1.0,
    ) -> dict[str, Any]:
        allowed = {
            "trend_following_ema", "momentum_macd_rsi", "mean_reversion_bbands",
            "breakout_structure", "scalping_m5", "swing_h1_h4",
        }
        if strategy_key not in allowed:
            return self._empty("unsupported_or_not_implemented_strategy", self.initial_cash)
        if any(isinstance(value, bool) for value in (leverage, notional, entry_fill_ratio, exit_fill_ratio) if value is not None):
            return self._empty("boolean_strategy_configuration_not_allowed", self.initial_cash)
        try:
            leverage_value = float(leverage)
            entry_ratio = float(entry_fill_ratio)
            exit_ratio = float(exit_fill_ratio)
            notional_value = float(notional) if notional is not None else None
            if (not math.isfinite(leverage_value) or leverage_value < 1 or leverage_value > self.max_leverage
                    or not math.isfinite(entry_ratio) or not 0 <= entry_ratio <= 1
                    or not math.isfinite(exit_ratio) or not 0 < exit_ratio <= 1
                    or (notional_value is not None and (not math.isfinite(notional_value) or notional_value <= 0))):
                raise ValueError("futures_strategy_configuration_out_of_range")
            from app.core.enums import Timeframe
            from app.engines.market_data import Candles
            from app.engines.technical import TechnicalAnalysisEngine
            from app.engines.backtest import BacktestEngine
            tf = timeframe if isinstance(timeframe, Timeframe) else Timeframe(str(timeframe))
            if strategy_key == "scalping_m5" and tf.value != "5m":
                return self._empty("scalping_m5_requires_5m_timeframe", self.initial_cash)
            if strategy_key == "swing_h1_h4" and tf.value not in {"1h", "4h"}:
                return self._empty("swing_h1_h4_requires_1h_or_4h_timeframe", self.initial_cash)
            if len(candles) < 60:
                return self._empty("at_least_60_candles_required", self.initial_cash)
            technical = TechnicalAnalysisEngine()
            signals: list[dict[str, Any]] = []
            active_side = None
            for index in range(49, len(candles) - 1):
                analysis = technical.analyze(Candles(candles[:index + 1]), tf)
                action = BacktestEngine._strategy_action(strategy_key, analysis)
                if action == "buy":
                    if active_side == "short":
                        signals.append({"index": index, "action": "close", "fill_ratio": exit_ratio})
                        if exit_ratio >= 1.0:
                            active_side = None
                    elif active_side is None:
                        signal = {"index": index, "action": "long", "leverage": leverage_value,
                                  "fill_ratio": entry_ratio}
                        if notional_value is not None:
                            signal["notional"] = notional_value
                        signals.append(signal)
                        active_side = "long"
                elif action == "sell":
                    if active_side == "long":
                        signals.append({"index": index, "action": "close", "fill_ratio": exit_ratio})
                        if exit_ratio >= 1.0:
                            active_side = None
                    elif active_side is None:
                        signal = {"index": index, "action": "short", "leverage": leverage_value,
                                  "fill_ratio": entry_ratio}
                        if notional_value is not None:
                            signal["notional"] = notional_value
                        signals.append(signal)
                        active_side = "short"
            result = self.run(candles, signals, funding_events=funding_events)
            result.update({
                "strategy_key": strategy_key,
                "timeframe": tf.value,
                "generated_signals": len(signals),
                "signal_generation": "technical_analysis_on_causal_history_prefix",
                "no_lookahead": True,
                "signal_causality": "verified_causal_history_prefix",
            })
            return result
        except (TypeError, ValueError, KeyError) as exc:
            return self._empty("futures_strategy_backtest_failed:" + str(exc)[:160], self.initial_cash)

    def run(
        self,
        candles: list[dict],
        signals: list[dict],
        funding_events: Sequence[dict] = (),
    ) -> dict[str, Any]:
        if not isinstance(candles, list) or not isinstance(signals, list):
            return self._empty("candles_and_signals_must_be_lists", self.initial_cash)
        if len(candles) < 2:
            return self._empty("at_least_two_candles_required", self.initial_cash)

        normalized = []
        timestamps = []
        for index, candle in enumerate(candles):
            if not isinstance(candle, dict):
                return self._empty(f"invalid_candle_at_index_{index}", self.initial_cash)
            if any(isinstance(candle.get(key), bool) for key in ("open", "high", "low", "close")):
                return self._empty(f"invalid_ohlc_at_index_{index}", self.initial_cash)
            try:
                o, h, low, close = (float(candle[key]) for key in ("open", "high", "low", "close"))
                stamp_raw = candle.get("timestamp", candle.get("close_time"))
                if isinstance(stamp_raw, bool) or stamp_raw is None:
                    raise ValueError("timestamp_required")
                stamp = float(stamp_raw)
            except (KeyError, TypeError, ValueError, OverflowError):
                return self._empty(f"invalid_candle_at_index_{index}", self.initial_cash)
            if (not all(math.isfinite(value) for value in (o, h, low, close, stamp))
                    or min(o, h, low, close) <= 0 or not stamp.is_integer()
                    or h < max(o, close, low) or low > min(o, close, h)):
                return self._empty(f"invalid_candle_at_index_{index}", self.initial_cash)
            normalized.append({"open": o, "high": h, "low": low, "close": close})
            timestamps.append(int(stamp))
        if any(timestamps[i] <= timestamps[i - 1] for i in range(1, len(timestamps))):
            return self._empty("candle_timestamps_must_increase", self.initial_cash)

        funding = []
        if not isinstance(funding_events, Sequence) or isinstance(funding_events, (str, bytes)):
            return self._empty("funding_events_must_be_a_sequence", self.initial_cash)
        for event in funding_events:
            if not isinstance(event, dict) or any(isinstance(event.get(k), bool) for k in ("timestamp", "rate")):
                return self._empty("invalid_funding_event", self.initial_cash)
            try:
                stamp = float(event["timestamp"])
                rate = float(event["rate"])
            except (KeyError, TypeError, ValueError, OverflowError):
                return self._empty("invalid_funding_event", self.initial_cash)
            if (not math.isfinite(stamp) or not stamp.is_integer()
                    or not math.isfinite(rate) or abs(rate) > 0.05):
                return self._empty("invalid_funding_event", self.initial_cash)
            funding.append({"timestamp": int(stamp), "rate": rate})
        funding.sort(key=lambda item: item["timestamp"])
        if any(funding[i]["timestamp"] <= funding[i - 1]["timestamp"] for i in range(1, len(funding))):
            return self._empty("funding_timestamps_must_be_unique", self.initial_cash)

        by_index: dict[int, dict[str, Any]] = {}
        for signal in signals:
            if not isinstance(signal, dict):
                return self._empty("signals_must_be_objects", self.initial_cash)
            action = str(signal.get("action", "")).lower()
            if action not in {"long", "short", "close", "reduce"}:
                continue
            raw_index = signal.get("index", signal.get("candle_index"))
            if isinstance(raw_index, bool) or raw_index is None:
                return self._empty("signal_index_required", self.initial_cash)
            try:
                numeric_index = float(raw_index)
                if not math.isfinite(numeric_index) or not numeric_index.is_integer():
                    raise ValueError("invalid_signal_index")
                index = int(numeric_index)
            except (TypeError, ValueError, OverflowError):
                return self._empty("invalid_signal_index", self.initial_cash)
            if index < 0 or index >= len(normalized) - 1:
                continue
            if index in by_index:
                return self._empty("multiple_futures_actions_same_candle", self.initial_cash)
            by_index[index] = signal | {"action": action, "index": index}

        cash = self.initial_cash
        position: dict[str, Any] | None = None
        funding_cursor = 0
        fees_total = 0.0
        slippage_total = 0.0
        funding_net_total = 0.0
        liquidations = 0
        partial_fills = 0
        trades: list[dict[str, Any]] = []
        equity_curve = []

        def unrealized(mark: float) -> float:
            if position is None:
                return 0.0
            direction = 1.0 if position["side"] == "long" else -1.0
            return direction * (mark - position["entry_price"]) * position["quantity"]

        def close_quantity(quantity_to_close: float, raw_price: float, index: int, reason: str,
                           liquidation: bool = False) -> None:
            nonlocal cash, position, fees_total, slippage_total, liquidations
            if position is None or quantity_to_close <= 0:
                return
            quantity_to_close = min(quantity_to_close, position["quantity"])
            direction = 1.0 if position["side"] == "long" else -1.0
            fill = raw_price * (1.0 - self.slippage_rate if direction > 0 else 1.0 + self.slippage_rate)
            exit_notional = quantity_to_close * fill
            exit_fee_rate = self.liquidation_fee_rate if liquidation else self.fee_rate
            exit_fee = exit_notional * exit_fee_rate
            gross = direction * (fill - position["entry_price"]) * quantity_to_close
            fraction = quantity_to_close / position["quantity"]
            entry_fee_alloc = position["entry_fee_remaining"] * fraction
            funding_alloc = position["funding_net"] * fraction
            net = gross - entry_fee_alloc - exit_fee + funding_alloc
            cash += gross - exit_fee
            fees_total += exit_fee
            slippage_total += quantity_to_close * abs(raw_price - fill)
            trades.append({
                "side": position["side"], "entry_index": position["entry_index"],
                "exit_index": index, "entry_price": position["entry_price"],
                "exit_price": fill, "quantity": quantity_to_close,
                "leverage": position["leverage"], "gross_pnl": round(gross, 8),
                "entry_fee_allocated": round(entry_fee_alloc, 8),
                "exit_fee": round(exit_fee, 8), "funding_net_allocated": round(funding_alloc, 8),
                "net_pnl": round(net, 8), "exit_reason": reason,
                "liquidated": liquidation,
            })
            position["quantity"] -= quantity_to_close
            position["entry_fee_remaining"] *= (1.0 - fraction)
            position["funding_net"] *= (1.0 - fraction)
            position["initial_margin"] *= (1.0 - fraction)
            if position["quantity"] <= 1e-12:
                position = None
            if liquidation:
                liquidations += 1

        def apply_funding_until(target_timestamp: int, mark_price: float) -> None:
            nonlocal cash, funding_cursor, funding_net_total
            while funding_cursor < len(funding) and funding[funding_cursor]["timestamp"] <= target_timestamp:
                event = funding[funding_cursor]
                if position is not None and event["timestamp"] > position["entry_timestamp"]:
                    direction = 1.0 if position["side"] == "long" else -1.0
                    payment = -direction * position["quantity"] * mark_price * event["rate"]
                    cash += payment
                    position["funding_net"] += payment
                    funding_net_total += payment
                funding_cursor += 1

        for index, candle in enumerate(normalized):
            mark = candle["close"]
            apply_funding_until(timestamps[index], mark)
            if position is not None:
                direction = 1.0 if position["side"] == "long" else -1.0
                maintenance = position["quantity"] * mark * self.maintenance_margin_rate
                margin_equity = (
                    position["initial_margin"] - position["entry_fee_remaining"]
                    + position["funding_net"] + unrealized(mark)
                )
                # Solve equity == maintenance margin directly. The prior
                # close-mark-dependent threshold shifted the intrabar trigger
                # as the candle close changed, rather than using a fixed level.
                margin_after_costs = (
                    position["initial_margin"] - position["entry_fee_remaining"]
                    + position["funding_net"]
                )
                if direction > 0:
                    liq_price = (
                        position["entry_price"] - margin_after_costs / position["quantity"]
                    ) / (1.0 - self.maintenance_margin_rate)
                else:
                    liq_price = (
                        position["entry_price"] + margin_after_costs / position["quantity"]
                    ) / (1.0 + self.maintenance_margin_rate)
                hit_liquidation = (
                    margin_equity <= maintenance
                    or (direction > 0 and candle["low"] <= liq_price)
                    or (direction < 0 and candle["high"] >= liq_price)
                )
                if hit_liquidation:
                    if direction > 0:
                        raw_liq_price = (
                            candle["open"] if candle["open"] <= liq_price
                            else liq_price if math.isfinite(liq_price) and liq_price > 0
                            else candle["low"]
                        )
                    else:
                        raw_liq_price = (
                            candle["open"] if candle["open"] >= liq_price
                            else liq_price if math.isfinite(liq_price) and liq_price > 0
                            else candle["high"]
                        )
                    close_quantity(position["quantity"], raw_liq_price, index, "estimated_liquidation", True)

            equity_curve.append(cash + unrealized(mark))
            if index >= len(normalized) - 1:
                continue
            signal = by_index.get(index)
            if not signal:
                continue
            action = signal["action"]
            fill_open = normalized[index + 1]["open"]
            apply_funding_until(timestamps[index + 1], fill_open)
            if action in {"long", "short"}:
                if position is not None:
                    continue
                raw_leverage = signal.get("leverage", 1.0)
                raw_notional = signal.get("notional")
                raw_fill_ratio = signal.get("fill_ratio", 1.0)
                if any(isinstance(value, bool) for value in (raw_leverage, raw_notional, raw_fill_ratio) if value is not None):
                    return self._empty("boolean_signal_configuration_not_allowed", self.initial_cash)
                try:
                    leverage = float(raw_leverage)
                    fill_ratio = float(raw_fill_ratio)
                    requested = float(raw_notional) if raw_notional is not None else (
                        cash * self.allocation_fraction * leverage
                    )
                except (TypeError, ValueError, OverflowError):
                    return self._empty("invalid_futures_signal_configuration", self.initial_cash)
                if (not all(math.isfinite(value) for value in (leverage, fill_ratio, requested))
                        or leverage < 1 or leverage > self.max_leverage
                        or not 0 <= fill_ratio <= 1 or requested <= 0):
                    return self._empty("futures_signal_configuration_out_of_range", self.initial_cash)
                notional = min(requested, self.max_notional, cash * leverage)
                if notional <= 0 or notional / leverage > cash:
                    continue
                if fill_ratio == 0:
                    continue
                if fill_ratio < 1:
                    partial_fills += 1
                notional *= fill_ratio
                direction = 1.0 if action == "long" else -1.0
                fill = fill_open * (1.0 + self.slippage_rate if direction > 0 else 1.0 - self.slippage_rate)
                quantity = notional / fill
                entry_fee = notional * self.fee_rate
                if cash < entry_fee:
                    continue
                cash -= entry_fee
                fees_total += entry_fee
                slippage_total += quantity * abs(fill_open - fill)
                position = {
                    "side": action, "entry_price": fill, "quantity": quantity,
                    "leverage": leverage, "entry_notional": notional,
                    "initial_margin": notional / leverage,
                    "entry_fee_remaining": entry_fee, "funding_net": 0.0,
                    "entry_index": index + 1, "entry_timestamp": timestamps[index + 1],
                }
            elif action in {"close", "reduce"} and position is not None:
                raw_fill_ratio = signal.get("fill_ratio", 1.0 if action == "close" else 0.5)
                if isinstance(raw_fill_ratio, bool):
                    return self._empty("boolean_fill_ratio_not_allowed", self.initial_cash)
                try:
                    fill_ratio = float(raw_fill_ratio)
                except (TypeError, ValueError, OverflowError):
                    return self._empty("invalid_fill_ratio", self.initial_cash)
                if not math.isfinite(fill_ratio) or not 0 < fill_ratio <= 1:
                    return self._empty("fill_ratio_out_of_range", self.initial_cash)
                if fill_ratio < 1:
                    partial_fills += 1
                quantity_to_close = position["quantity"] * fill_ratio
                direction = 1.0 if position["side"] == "long" else -1.0
                raw_exit = fill_open
                close_quantity(quantity_to_close, raw_exit, index + 1, "signal_close" if fill_ratio == 1 else "partial_reduce")

        if position is not None:
            raw_exit = normalized[-1]["close"]
            close_quantity(position["quantity"], raw_exit, len(normalized) - 1, "end_of_data")
            equity_curve[-1] = cash

        pnl = [trade["net_pnl"] for trade in trades]
        wins = [value for value in pnl if value > 0]
        final_equity = cash
        peak = self.initial_cash
        max_drawdown = 0.0
        for value in equity_curve:
            peak = max(peak, value)
            if peak > 0:
                max_drawdown = max(max_drawdown, (peak - value) / peak)
        return {
            "ok": True,
            "total_trades": len(trades),
            "win_rate": round(len(wins) / len(trades), 4) if trades else 0.0,
            "total_return": round((final_equity - self.initial_cash) / self.initial_cash, 6),
            "final_equity": round(final_equity, 8),
            "max_drawdown": round(max_drawdown, 6),
            "fees_paid": round(fees_total, 8),
            "slippage_cost": round(slippage_total, 8),
            "funding_net": round(funding_net_total, 8),
            "liquidations": liquidations,
            "partial_fills": partial_fills,
            "trades": trades,
            "equity_curve": [round(value, 8) for value in equity_curve],
            "execution_model": "next_candle_open_with_fees_slippage_funding_partial_fills",
            "margin_model": "single_position_isolated_margin_with_estimated_liquidation",
            "max_notional": self.max_notional,
            "no_lookahead": False,
            "signal_causality": "not_verified_for_external_signals",
            "execution": "none",
            "limitations": [
                "single isolated-margin position; no cross-margin portfolio netting",
                "liquidation is an estimate using one maintenance-margin rate, not Binance risk tiers",
                "funding uses supplied timestamps and candle-close mark approximation",
                "no order-book queue, exchange filters, latency, or market-impact model",
                "partial fills are user-supplied fill ratios, not a stochastic order-book simulation",
            ],
        }
