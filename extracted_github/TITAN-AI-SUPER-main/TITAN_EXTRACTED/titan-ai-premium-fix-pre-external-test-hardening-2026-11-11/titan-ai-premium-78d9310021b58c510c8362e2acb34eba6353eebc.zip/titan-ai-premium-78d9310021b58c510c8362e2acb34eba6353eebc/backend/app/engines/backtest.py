"""Historical, signal-driven Spot backtesting.

Signals are evaluated at their candle index and orders are filled at the NEXT
candle open with configured slippage. No synthetic fixed-return exits are used.
This is a basic single-position simulator, not a claim of walk-forward validation.
"""
from __future__ import annotations

from typing import Any
from dataclasses import dataclass
import math


@dataclass
class BacktestResult:
    total_trades: int
    win_rate: float
    profit_factor: float
    expectancy: float
    max_drawdown: float
    total_return: float
    fees_paid: float
    slippage_cost: float
    sharpe: float | None


class BacktestEngine:
    def __init__(
        self,
        fee_rate: float = 0.001,
        slippage_rate: float = 0.0005,
        initial_cash: float = 10_000.0,
        allocation_fraction: float = 0.95,
        max_notional: float = 80.0,
    ):
        if any(isinstance(value, bool) for value in (fee_rate, slippage_rate, initial_cash, allocation_fraction, max_notional)):
            raise ValueError("boolean_backtest_configuration_not_allowed")
        try:
            fee_rate = float(fee_rate)
            slippage_rate = float(slippage_rate)
            initial_cash = float(initial_cash)
            allocation_fraction = float(allocation_fraction)
            max_notional = float(max_notional)
        except (TypeError, ValueError, OverflowError):
            raise ValueError("invalid_backtest_numeric_configuration")
        if not all(math.isfinite(value) for value in (fee_rate, slippage_rate, initial_cash, allocation_fraction, max_notional)):
            raise ValueError("non_finite_backtest_configuration")
        if not 0 <= fee_rate < 1 or not 0 <= slippage_rate < 1:
            raise ValueError("fee_and_slippage_must_be_between_zero_and_one")
        if initial_cash <= 0 or not 0 < allocation_fraction <= 1 or max_notional <= 0:
            raise ValueError("invalid_backtest_capital_or_allocation")
        self.fee_rate = fee_rate
        self.slippage_rate = slippage_rate
        self.initial_cash = initial_cash
        self.allocation_fraction = allocation_fraction
        self.max_notional = max_notional

    def run(self, candles: list[dict], signals: list[dict]) -> dict[str, Any]:
        if not isinstance(candles, list) or not isinstance(signals, list):
            return self._empty("candles_and_signals_must_be_lists")
        if len(candles) < 2:
            return self._empty("at_least_two_candles_required")
        normalized = []
        for i, candle in enumerate(candles):
            if not isinstance(candle, dict) or any(isinstance(candle.get(key), bool) for key in ("open", "high", "low", "close")):
                return self._empty(f"invalid_ohlc_at_index_{i}")
            try:
                o, h, l, c = (float(candle[k]) for k in ("open", "high", "low", "close"))
            except (KeyError, TypeError, ValueError):
                return self._empty(f"invalid_ohlc_at_index_{i}")
            if (not all(math.isfinite(value) for value in (o, h, l, c))
                    or min(o, h, l, c) <= 0 or h < max(o, c, l) or l > min(o, c, h)):
                return self._empty(f"invalid_ohlc_at_index_{i}")
            normalized.append({"open": o, "high": h, "low": l, "close": c})

        by_index: dict[int, list[str]] = {}
        for sig in signals:
            if not isinstance(sig, dict):
                return self._empty("signals_must_be_objects")
            action = str(sig.get("action", "")).lower()
            if action not in {"buy", "sell"}:
                continue
            idx = sig.get("index", sig.get("candle_index"))
            if idx is None:
                return self._empty("each_signal_requires_candle_index")
            if isinstance(idx, bool):
                return self._empty("invalid_signal_index")
            try:
                numeric_index = float(idx)
                if not math.isfinite(numeric_index) or not numeric_index.is_integer():
                    return self._empty("invalid_signal_index")
                idx = int(numeric_index)
            except (TypeError, ValueError, OverflowError):
                return self._empty("invalid_signal_index")
            if idx < 0 or idx >= len(normalized) - 1:
                continue
            by_index.setdefault(idx, []).append(action)
        if any(len(set(actions)) > 1 for actions in by_index.values()):
            return self._empty("conflicting_signals_same_candle")

        cash = self.initial_cash
        qty = 0.0
        entry_price = None
        entry_fee = 0.0
        entry_slippage = 0.0
        entry_index = None
        trades: list[dict[str, Any]] = []
        fees_total = 0.0
        slippage_total = 0.0
        equity_curve = [self.initial_cash]
        pending_exit_reason = None

        def mark_equity(mark: float) -> float:
            return cash + qty * mark

        for i in range(len(normalized) - 1):
            # Signals at candle i execute at candle i+1 open, never at the signal candle close.
            next_open = normalized[i + 1]["open"]
            actions = by_index.get(i, [])
            if "sell" in actions and qty > 0:
                fill = next_open * (1 - self.slippage_rate)
                proceeds = qty * fill
                exit_fee = proceeds * self.fee_rate
                cash += proceeds - exit_fee
                fees_total += exit_fee
                slippage_total += qty * abs(next_open - fill)
                gross = qty * (fill - float(entry_price))
                net = gross - entry_fee - exit_fee
                trades.append({"entry_index": entry_index, "exit_index": i + 1, "entry_price": entry_price,
                               "exit_price": fill, "quantity": qty, "gross_pnl": gross,
                               "fees": entry_fee + exit_fee, "net_pnl": net, "exit_reason": "sell_signal"})
                qty = 0.0; entry_price = None; entry_fee = 0.0; entry_index = None
            elif "buy" in actions and qty <= 0:
                budget = min(cash * self.allocation_fraction, self.max_notional)
                fill = next_open * (1 + self.slippage_rate)
                buy_qty = budget / (fill * (1 + self.fee_rate))
                notional = buy_qty * fill
                fee = notional * self.fee_rate
                cash -= notional + fee
                qty = buy_qty
                entry_price = fill
                entry_fee = fee
                entry_index = i + 1
                fees_total += fee
                slippage_total += buy_qty * abs(next_open - fill)
            equity_curve.append(mark_equity(normalized[i + 1]["close"]))

        if qty > 0:
            last_index = len(normalized) - 1
            raw_exit = normalized[-1]["close"]
            fill = raw_exit * (1 - self.slippage_rate)
            proceeds = qty * fill
            exit_fee = proceeds * self.fee_rate
            cash += proceeds - exit_fee
            fees_total += exit_fee
            slippage_total += qty * abs(raw_exit - fill)
            gross = qty * (fill - float(entry_price))
            net = gross - entry_fee - exit_fee
            trades.append({"entry_index": entry_index, "exit_index": last_index, "entry_price": entry_price,
                           "exit_price": fill, "quantity": qty, "gross_pnl": gross,
                           "fees": entry_fee + exit_fee, "net_pnl": net, "exit_reason": "end_of_data"})
            qty = 0.0
            equity_curve[-1] = cash

        pnl_values = [t["net_pnl"] for t in trades]
        wins = [p for p in pnl_values if p > 0]
        losses = [p for p in pnl_values if p < 0]
        gross_profit, gross_loss = sum(wins), abs(sum(losses))
        peak = self.initial_cash
        max_dd = 0.0
        for value in equity_curve:
            peak = max(peak, value)
            max_dd = max(max_dd, (peak - value) / peak if peak else 0.0)
        returns = [(equity_curve[i] / equity_curve[i - 1] - 1) for i in range(1, len(equity_curve)) if equity_curve[i - 1] > 0]
        sharpe = None
        if len(returns) > 1:
            mean = sum(returns) / len(returns)
            variance = sum((x - mean) ** 2 for x in returns) / (len(returns) - 1)
            if variance > 0:
                sharpe = (mean / math.sqrt(variance)) * math.sqrt(252)
        final_equity = cash
        return {
            "total_trades": len(trades),
            "win_rate": round(len(wins) / len(trades), 4) if trades else 0.0,
            "profit_factor": round(gross_profit / gross_loss, 4) if gross_loss else (None if gross_profit == 0 else "infinite"),
            "expectancy": round(sum(pnl_values) / len(pnl_values), 8) if trades else 0.0,
            "max_drawdown": round(max_dd, 6),
            "total_return": round((final_equity - self.initial_cash) / self.initial_cash, 6),
            "final_equity": round(final_equity, 8),
            "fees_paid": round(fees_total, 8),
            "slippage_cost": round(slippage_total, 8),
            "sharpe": round(sharpe, 4) if sharpe is not None else None,
            "trades": trades,
            "equity_curve": [round(x, 8) for x in equity_curve],
            "execution_model": "next_candle_open_with_fee_and_slippage",
            "position_mode": "spot_long_only_single_position",
            "max_trade_notional": self.max_notional,
            "walk_forward_ready": False,
            "out_of_sample_ready": False,
            "no_lookahead": True,
            "limitations": ["single position", "signal index required", "no partial fills or exchange filters",
                            "end-of-data liquidation", "not a walk-forward or out-of-sample validation"],
        }

    def walk_forward(
        self,
        candles: list[dict],
        *,
        signal_fn,
        train_window: int,
        test_window: int,
        step: int | None = None,
        fit_fn=None,
    ) -> dict[str, Any]:
        """Run rolling out-of-sample folds without exposing future candles.

        fit_fn receives only the training slice. signal_fn receives the training
        slice plus the test history available up to the current test candle.
        Signals fill at the next test candle open through the normal simulator.
        """
        if not callable(signal_fn):
            return self._empty("signal_fn_must_be_callable")
        if fit_fn is not None and not callable(fit_fn):
            return self._empty("fit_fn_must_be_callable")
        for name, value in (("train_window", train_window), ("test_window", test_window)):
            if isinstance(value, bool) or not isinstance(value, int) or value < 2:
                return self._empty(f"{name}_must_be_an_integer_at_least_2")
        step = test_window if step is None else step
        if isinstance(step, bool) or not isinstance(step, int) or step < test_window:
            return self._empty("step_must_be_at_least_test_window_to_avoid_overlapping_oos_folds")
        if len(candles) < train_window + test_window:
            return self._empty("insufficient_candles_for_train_and_test_windows")

        folds: list[dict[str, Any]] = []
        start = 0
        fold_number = 0
        while start + train_window + test_window <= len(candles):
            train_start = start
            train_end = start + train_window
            test_end = train_end + test_window
            training = [dict(row) for row in candles[train_start:train_end]]
            testing = [dict(row) for row in candles[train_end:test_end]]
            fold_number += 1
            try:
                model_state = fit_fn(training) if fit_fn is not None else None
                signals: list[dict[str, Any]] = []
                # The last test candle cannot emit an actionable signal because
                # there is no next candle open inside this fold to fill it.
                for local_index in range(len(testing) - 1):
                    history_end = train_end + local_index + 1
                    visible_history = [
                        dict(row) for row in candles[train_start:history_end]
                    ]
                    generated = signal_fn(visible_history, model_state)
                    action = generated.get("action") if isinstance(generated, dict) else generated
                    action = str(action or "").lower()
                    if action in {"buy", "sell"}:
                        signals.append({"index": local_index, "action": action})
            except Exception as exc:
                return {
                    "ok": False,
                    "error": f"walk_forward_callback_failed_fold_{fold_number}",
                    "detail": str(exc)[:240],
                    "folds": folds,
                    "walk_forward_ready": False,
                    "out_of_sample_ready": False,
                    "no_lookahead": False,
                }

            result = self.run(testing, signals)
            if result.get("ok") is False:
                return {
                    "ok": False,
                    "error": f"walk_forward_test_fold_failed_{fold_number}",
                    "detail": result.get("error"),
                    "folds": folds,
                    "walk_forward_ready": False,
                    "out_of_sample_ready": False,
                    "no_lookahead": False,
                }
            folds.append({
                "fold": fold_number,
                "train_start_index": train_start,
                "train_end_index_exclusive": train_end,
                "test_start_index": train_end,
                "test_end_index_exclusive": test_end,
                "training_candles": len(training),
                "testing_candles": len(testing),
                "model_fitted": fit_fn is not None,
                "result": result,
            })
            start += step

        if not folds:
            return self._empty("no_walk_forward_folds_created")
        all_trades = [trade for fold in folds for trade in fold["result"]["trades"]]
        wins = [trade["net_pnl"] for trade in all_trades if trade["net_pnl"] > 0]
        losses = [trade["net_pnl"] for trade in all_trades if trade["net_pnl"] < 0]
        gross_profit = sum(wins)
        gross_loss = abs(sum(losses))
        compounded_return = 1.0
        for fold in folds:
            compounded_return *= 1.0 + float(fold["result"]["total_return"])
        return {
            "ok": True,
            "validation": "rolling_walk_forward_out_of_sample",
            "fold_count": len(folds),
            "total_trades": len(all_trades),
            "win_rate": round(len(wins) / len(all_trades), 4) if all_trades else 0.0,
            "profit_factor": round(gross_profit / gross_loss, 4) if gross_loss else (None if gross_profit == 0 else "infinite"),
            "expectancy": round(sum(t["net_pnl"] for t in all_trades) / len(all_trades), 8) if all_trades else 0.0,
            "compounded_oos_return": round(compounded_return - 1.0, 6),
            "mean_fold_return": round(sum(f["result"]["total_return"] for f in folds) / len(folds), 6),
            "max_fold_drawdown": round(max(f["result"]["max_drawdown"] for f in folds), 6),
            "fees_paid": round(sum(f["result"]["fees_paid"] for f in folds), 8),
            "slippage_cost": round(sum(f["result"]["slippage_cost"] for f in folds), 8),
            "folds": folds,
            "walk_forward_ready": True,
            "out_of_sample_ready": True,
            "no_lookahead": True,
            "model_fitted_per_fold": fit_fn is not None,
            "signal_generation": "signal_fn_sees_training_window_and_test_history_up_to_current_candle_only",
            "limitations": [
                "each out-of-sample fold starts with a fresh initial cash balance",
                "fold returns are compounded for the aggregate metric",
                "single-position Spot-long simulator; no partial fills or exchange filters",
                "signal and fit callbacks must themselves avoid external future-data leakage",
            ],
        }

    @staticmethod
    def _strategy_action(strategy_key: str, analysis) -> str | None:
        signals = set(getattr(analysis, "signals", []) or [])
        if strategy_key == "trend_following_ema":
            if analysis.trend == "bullish":
                return "buy"
            if analysis.trend == "bearish":
                return "sell"
        elif strategy_key == "momentum_macd_rsi":
            if "macd_hist_positive" in signals and "rsi_overbought" not in signals:
                return "buy"
            if "macd_hist_negative" in signals and "rsi_oversold" not in signals:
                return "sell"
        elif strategy_key == "mean_reversion_bbands":
            if "rsi_oversold" in signals and "bollinger_lower_band_touch" in signals:
                return "buy"
            if "rsi_overbought" in signals and "bollinger_upper_band_touch" in signals:
                return "sell"
        elif strategy_key == "breakout_structure":
            for breakout in (getattr(analysis, "structure", {}) or {}).get("breakouts", []):
                if breakout.get("status") == "confirmed":
                    return "buy" if breakout.get("direction") == "bullish" else "sell"
        elif strategy_key == "scalping_m5":
            timeframe = getattr(getattr(analysis, "timeframe", None), "value", str(getattr(analysis, "timeframe", "")))
            if timeframe != "5m":
                return None
            bullish_confirm = {"bullish_engulfing", "morning_star", "pin_bar_bullish", "hammer"}
            bearish_confirm = {"bearish_engulfing", "evening_star", "pin_bar_bearish", "shooting_star"}
            if (analysis.trend == "bullish" and "macd_hist_positive" in signals
                    and "rsi_overbought" not in signals
                    and ("volume_spike" in signals or bullish_confirm.intersection(signals))):
                return "buy"
            if (analysis.trend == "bearish" and "macd_hist_negative" in signals
                    and "rsi_oversold" not in signals
                    and ("volume_spike" in signals or bearish_confirm.intersection(signals))):
                return "sell"
        elif strategy_key == "swing_h1_h4":
            timeframe = getattr(getattr(analysis, "timeframe", None), "value", str(getattr(analysis, "timeframe", "")))
            if timeframe not in {"1h", "4h"}:
                return None
            structure = (getattr(analysis, "structure", {}) or {}).get("bias")
            if (analysis.trend == "bullish" and structure == "bullish_structure"
                    and "macd_hist_positive" in signals):
                return "buy"
            if (analysis.trend == "bearish" and structure == "bearish_structure"
                    and "macd_hist_negative" in signals):
                return "sell"
        return None

    def run_strategy(
        self,
        candles: list[dict],
        *,
        strategy_key: str,
        timeframe,
    ) -> dict[str, Any]:
        """Causal historical backtest using the existing TechnicalAnalysisEngine."""
        allowed = {"trend_following_ema", "momentum_macd_rsi", "mean_reversion_bbands", "breakout_structure", "scalping_m5", "swing_h1_h4"}
        if strategy_key not in allowed:
            return self._empty("unsupported_or_not_implemented_strategy")
        if len(candles) < 60:
            return self._empty("at_least_60_candles_required")
        try:
            from app.core.enums import Timeframe
            from app.engines.market_data import Candles
            from app.engines.technical import TechnicalAnalysisEngine
            tf = timeframe if isinstance(timeframe, Timeframe) else Timeframe(str(timeframe))
            if strategy_key == "scalping_m5" and tf.value != "5m":
                return self._empty("scalping_m5_requires_5m_timeframe")
            if strategy_key == "swing_h1_h4" and tf.value not in {"1h", "4h"}:
                return self._empty("swing_h1_h4_requires_1h_or_4h_timeframe")
            technical = TechnicalAnalysisEngine()
            signals = []
            for index in range(49, len(candles) - 1):
                history = Candles(candles[: index + 1])
                analysis = technical.analyze(history, tf)
                action = self._strategy_action(strategy_key, analysis)
                if action:
                    signals.append({"index": index, "action": action})
            result = self.run(candles, signals)
            result.update({
                "strategy_key": strategy_key,
                "timeframe": tf.value,
                "signal_generation": "technical_analysis_on_causal_history_prefix",
                "walk_forward_ready": False,
                "out_of_sample_ready": False,
                "no_lookahead": True,
            })
            return result
        except Exception as exc:
            return self._empty("strategy_backtest_failed:" + str(exc)[:160])

    def run_strategy_walk_forward(
        self,
        candles: list[dict],
        *,
        strategy_key: str,
        timeframe,
        train_window: int = 60,
        test_window: int = 30,
        step: int | None = None,
    ) -> dict[str, Any]:
        """Rolling OOS backtest; strategy sees only each fold's past/current candles."""
        allowed = {"trend_following_ema", "momentum_macd_rsi", "mean_reversion_bbands", "breakout_structure", "scalping_m5", "swing_h1_h4"}
        if strategy_key not in allowed:
            return self._empty("unsupported_or_not_implemented_strategy")
        if isinstance(train_window, bool) or not isinstance(train_window, int) or train_window < 50:
            return self._empty("train_window_must_be_at_least_50")
        try:
            from app.core.enums import Timeframe
            from app.engines.market_data import Candles
            from app.engines.technical import TechnicalAnalysisEngine
            tf = timeframe if isinstance(timeframe, Timeframe) else Timeframe(str(timeframe))
            if strategy_key == "scalping_m5" and tf.value != "5m":
                return self._empty("scalping_m5_requires_5m_timeframe")
            if strategy_key == "swing_h1_h4" and tf.value not in {"1h", "4h"}:
                return self._empty("swing_h1_h4_requires_1h_or_4h_timeframe")
            technical = TechnicalAnalysisEngine()

            def signal_fn(history: list[dict], model_state):
                if len(history) < 50:
                    return "wait"
                analysis = technical.analyze(Candles(history), tf)
                return self._strategy_action(strategy_key, analysis) or "wait"

            result = self.walk_forward(
                candles, signal_fn=signal_fn, train_window=train_window,
                test_window=test_window, step=step,
            )
            result.update({
                "strategy_key": strategy_key,
                "timeframe": tf.value,
                "model_fitted_per_fold": False,
                "signal_generation": "existing_technical_strategy_on_causal_fold_history",
                "note": "Deterministic strategy replay; no parameter fitting occurs. The training window supplies past context only.",
            })
            return result
        except Exception as exc:
            return self._empty("strategy_walk_forward_failed:" + str(exc)[:160])

    def _empty(self, reason: str) -> dict[str, Any]:
        return {
            "ok": False, "error": reason, "total_trades": 0, "win_rate": 0.0,
            "profit_factor": 0.0, "expectancy": 0.0, "max_drawdown": 0.0,
            "total_return": 0.0, "fees_paid": 0.0, "slippage_cost": 0.0,
            "sharpe": None, "trades": [], "equity_curve": [self.initial_cash],
            "walk_forward_ready": False, "out_of_sample_ready": False, "no_lookahead": False,
        }
