from __future__ import annotations

from datetime import datetime, timezone
import math
from typing import Any

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.enums import EngineStatus, EnvironmentMode, MarketType, Timeframe
from app.engines.decision import DecisionEngine
from app.engines.liquidity import LiquidityAnalysisEngine
from app.engines.order_flow import OrderFlowEngine
from app.engines.market_data import MarketDataEngine
from app.engines.risk import RiskEngine
from app.engines.strategies import list_strategies
from app.engines.technical import TechnicalAnalysisEngine
from app.models.entities import DecisionRecord, EngineState, OrderRecord, PositionRecord, SystemState
from .audit import log_event
from .governance import record_config_change


ENGINE_REGISTRY = [
    ("compliance_policy", "TITAN COMPLIANCE & POLICY ENGINE", "implemented_partial"),
    ("market_analysis", "Market Analysis Engine", "implemented_partial"),
    ("technical_analysis", "Technical Analysis Engine", "implemented_partial"),
    ("fundamental_analysis", "Fundamental Analysis Engine", "implemented_partial"),
    ("news_analysis", "News Analysis Engine", "implemented_partial"),
    ("market_structure", "Market Structure Engine", "implemented_partial"),
    ("liquidity_analysis", "Liquidity Analysis Engine", "implemented_partial"),
    ("order_flow", "Order Flow Engine", "implemented_partial"),
    ("volume_analysis", "Volume Analysis Engine", "implemented_partial"),
    ("coin_discovery", "Coin Discovery Engine", "implemented_partial"),
    ("arbitrage_analysis", "Triangular Spot Arbitrage Analysis Engine", "implemented_partial"),
    ("strategy_selection", "Strategy Selection Engine", "implemented_partial"),
    ("decision_making", "Decision Making Engine", "implemented_partial"),
    ("risk_management", "Risk Management Engine", "implemented_partial"),
    ("portfolio_management", "Portfolio Management Engine", "implemented_partial"),
    ("trade_execution", "Trade Execution Engine", "needs_external_service"),
    ("position_management", "Position Management Engine", "implemented_partial"),
    ("backtesting", "Backtesting Engine", "implemented_partial"),
    ("ai_learning", "AI Learning Engine", "implemented_partial"),
    ("self_evolution", "Self-Evolution Engine", "implemented_partial"),
    ("knowledge_base", "Knowledge Base", "implemented_partial"),
    ("long_term_memory", "Long-Term Memory", "implemented_partial"),
    ("performance_evaluation", "Performance Evaluation Engine", "implemented_partial"),
    ("prediction_tracking", "Prediction Tracking Engine", "implemented_partial"),
    ("system_monitoring", "System Monitoring Engine", "implemented_partial"),
]


def _utcnow():
    return datetime.now(timezone.utc)


class TitanCoreService:
    def __init__(self) -> None:
        self.market_data = MarketDataEngine()
        self.technical = TechnicalAnalysisEngine()
        self.risk = RiskEngine()
        self.decision = DecisionEngine()

    def ensure_bootstrap(self, db: Session) -> None:
        state = db.get(SystemState, 1)
        if not state:
            state = SystemState(
                id=1, environment_mode=EnvironmentMode.DEMO.value, account_target="demo", market_type=MarketType.SPOT.value,
                bot_run_state="stopped", autonomous_enabled=False, live_trading_enabled=False, live_confirmed_by_user=False,
                emergency_stop=False, selected_timeframes=[t.value for t in Timeframe],
                risk_limits={"demo_initial_balance": 150.0, "demo_risk_per_trade": 0.005,
                             "max_leverage_cap": 1.0, "max_risk_per_trade_cap": min(settings.max_risk_per_trade_cap, 0.005),
                             "max_daily_loss_cap": settings.max_daily_loss_cap, "max_open_positions_cap": settings.max_open_positions_cap},
                status_summary={"bootstrapped": True},
            )
            db.add(state)
            log_event(db, action="system.bootstrap", message="Initialized TITAN system state (DEMO, SPOT, stopped, live off).")
        else:
            # compatibility defaults for older DB rows
            if not getattr(state, "account_target", None): state.account_target = state.environment_mode or "demo"
            if not getattr(state, "bot_run_state", None): state.bot_run_state = "stopped"
            db.add(state)
        existing_rows = {
            row.engine_key: row for row in db.execute(select(EngineState)).scalars().all()
        }
        for key, name, status in ENGINE_REGISTRY:
            row = existing_rows.get(key)
            if row is None:
                db.add(EngineState(engine_key=key, name=name, status=status, message="Registered by TITAN AI CORE bootstrap."))
            else:
                # Registry status describes implementation maturity, not a
                # runtime start/stop flag. Keep it synchronized after upgrades.
                row.name = name
                row.status = status
                if not row.message:
                    row.message = "Implementation status synchronized from TITAN AI CORE registry."
                db.add(row)
        db.commit()

    def _state(self, db: Session) -> SystemState:
        self.ensure_bootstrap(db)
        return db.get(SystemState, 1)

    def get_state(self, db: Session) -> dict[str, Any]:
        s = self._state(db)
        return {
            "environment_mode": s.environment_mode,
            "account_target": getattr(s, "account_target", s.environment_mode),
            "market_type": s.market_type,
            "bot_run_state": getattr(s, "bot_run_state", "stopped"),
            "bot_started_at": s.bot_started_at.isoformat() if getattr(s, "bot_started_at", None) else None,
            "bot_stopped_at": s.bot_stopped_at.isoformat() if getattr(s, "bot_stopped_at", None) else None,
            "bot_stop_reason": getattr(s, "bot_stop_reason", None),
            "autonomous_enabled": s.autonomous_enabled,
            "live_trading_enabled": s.live_trading_enabled,
            "live_confirmed_by_user": bool(getattr(s, "live_confirmed_by_user", False)),
            "emergency_stop": s.emergency_stop,
            "selected_timeframes": s.selected_timeframes or [t.value for t in Timeframe],
            "risk_limits": s.risk_limits or {},
            "safety": {
                "allow_demo_to_live_auto": settings.allow_demo_to_live_auto,
                "allow_withdrawal_permissions": settings.allow_withdrawal_permissions,
                "note": "Demo/Live separated. Auto switch to Live disabled. Withdrawal/transfer permissions are not supported.",
            },
            "master_control": {
                "start_requires": ["account_target_selected", "connectivity_or_data_check", "compliance_check", "risk_limits", "no_duplicate_run"],
                "stop_default": "stop_new_only",
                "emergency_stop": "independent_flag_blocks_new_actions",
            },
        }

    def set_state(self, db: Session, *, environment_mode: str | None = None, account_target: str | None = None,
                  market_type: str | None = None, autonomous_enabled: bool | None = None, emergency_stop: bool | None = None,
                  live_confirm: bool | None = None) -> dict[str, Any]:
        s = self._state(db)
        old = self.get_state(db)
        if account_target:
            at = account_target.lower()
            if at not in {"demo", "testnet", "live"}:
                raise ValueError("account_target must be demo, testnet, or live")
            if at == "live" and old.get("environment_mode") != "live" and not live_confirm:
                raise ValueError("Switching to Live requires explicit confirmation (live_confirm=true) and enabled config. No auto demo->live.")
            s.account_target = at
            s.environment_mode = "live" if at == "live" else "demo"
        if environment_mode:
            env = EnvironmentMode(environment_mode)
            if env == EnvironmentMode.LIVE and (not settings.live_trading_enabled or not live_confirm):
                log_event(db, action="state.live_blocked", severity="warning", message="Live blocked: requires explicit config enablement and confirmation.")
            else:
                s.environment_mode = env.value
                # Keep account target aligned with the selected environment.
                s.account_target = "live" if env == EnvironmentMode.LIVE else "demo"
                s.live_confirmed_by_user = bool(live_confirm) if env == EnvironmentMode.LIVE else False
        if market_type:
            s.market_type = MarketType(market_type).value
        if autonomous_enabled is not None:
            if type(autonomous_enabled) is not bool:
                raise ValueError("autonomous_enabled_must_be_boolean")
            s.autonomous_enabled = autonomous_enabled
        if emergency_stop is not None:
            if type(emergency_stop) is not bool:
                raise ValueError("emergency_stop_must_be_boolean")
            if s.emergency_stop and emergency_stop is False:
                raise ValueError("emergency_stop_reset_requires_verified_reset_flow")
            if emergency_stop:
                s.emergency_stop = True
                s.bot_run_state = "stopped"
                s.autonomous_enabled = False
                s.bot_stopped_at = _utcnow()
                s.bot_stop_reason = "emergency_stop"
                log_event(db, action="master.emergency_stop", severity="warning", message="Emergency stop activated: new actions must halt.")
        db.add(s)
        record_config_change(db, actor="api", scope="system", key="state", old_value=old, new_value=self.get_state(db), reason="User/API state update", approved=True)
        log_event(db, action="state.update", message="System state updated.", details={"before_env": old.get("environment_mode"), "after_env": s.environment_mode})
        db.commit()
        return self.get_state(db)

    def reset_emergency_stop(self, db: Session) -> dict[str, Any]:
        state = self._state(db)
        market = state.market_type
        if (state.environment_mode != EnvironmentMode.DEMO.value
                or state.account_target != "demo"
                or market not in {MarketType.SPOT.value, MarketType.FUTURES.value}):
            raise ValueError("emergency_reset_demo_market_only")
        uncertain = db.execute(select(OrderRecord).where(
            OrderRecord.environment_mode == "demo", OrderRecord.market_type == market,
            OrderRecord.shadow.is_(True), OrderRecord.status.in_(["pending", "submitted", "partially_filled"]),
        )).scalars().all()
        if uncertain:
            raise ValueError("reconciliation_required_before_emergency_reset")
        if market == MarketType.FUTURES.value:
            open_positions = db.execute(select(PositionRecord).where(
                PositionRecord.environment_mode == "demo",
                PositionRecord.market_type == "futures",
                PositionRecord.shadow.is_(True),
                PositionRecord.status == "open",
            )).scalars().all()
            if open_positions:
                raise ValueError("open_futures_positions_require_review_before_emergency_reset")
        batches = self.market_data.get_public_multi_timeframe(
            "BTC/USDT", market_type=market,
        )
        for timeframe, batch in batches.items():
            if (not batch.df or len(batch.df) < 30
                    or getattr(batch, "market_type", market) != market
                    or batch.source.value != "live_public"):
                raise ValueError(f"market_data_not_ready:{timeframe.value}")
        five_minute = batches[Timeframe.M5].df.rows[-1]
        stamp = five_minute.get("close_time") or five_minute.get("timestamp")
        if isinstance(stamp, bool) or stamp is None:
            raise ValueError("market_data_timestamp_invalid_during_emergency_reset")
        if isinstance(stamp, (int, float)):
            age = datetime.now(timezone.utc).timestamp() - float(stamp) / 1000.0
        elif isinstance(stamp, str):
            age = datetime.now(timezone.utc).timestamp() - datetime.fromisoformat(stamp.replace("Z", "+00:00")).timestamp()
        else:
            raise ValueError("market_data_timestamp_invalid_during_emergency_reset")
        if not math.isfinite(age) or age > 300 or age < -60:
            raise ValueError("market_data_stale_during_emergency_reset")
        if market == MarketType.FUTURES.value:
            mark = self.market_data.get_public_mark_price("BTC/USDT")
            raw_price, raw_time = mark.get("mark_price"), mark.get("time")
            if (mark.get("source") != "binance_usdm_futures_public_read_only"
                    or isinstance(raw_price, bool) or isinstance(raw_time, bool)):
                raise ValueError("futures_mark_price_unavailable_during_emergency_reset")
            try:
                mark_price, mark_age = float(raw_price), datetime.now(timezone.utc).timestamp() - float(raw_time) / 1000.0
            except (TypeError, ValueError, OverflowError):
                raise ValueError("futures_mark_price_invalid_during_emergency_reset")
            if not math.isfinite(mark_price) or mark_price <= 0 or not math.isfinite(mark_age) or mark_age > 60 or mark_age < -60:
                raise ValueError("futures_mark_price_stale_during_emergency_reset")
        state.emergency_stop = False
        state.bot_run_state = "stopped"
        state.autonomous_enabled = False
        state.bot_stop_reason = "emergency_reset_checks_passed_worker_not_started"
        state.bot_stopped_at = _utcnow()
        db.add(state)
        log_event(db, action="master.emergency_reset", severity="warning",
                  message=f"Emergency stop reset after Demo/{market.title()} scope, order reconciliation and fresh public-data checks; worker remains stopped.",
                  environment_mode="demo", market_type=market)
        db.commit()
        return {"ok": True, "state": self.get_state(db),
                "note": "Safety checks passed. Emergency stop cleared, but no worker was started."}

    def start_bot(self, db: Session, *, account_target: str | None = None, live_confirm: bool = False) -> dict[str, Any]:
        s = self._state(db)
        if s.emergency_stop:
            raise ValueError("Cannot start: emergency stop is active.")
        if getattr(s, "bot_run_state", "stopped") in {"starting", "running", "analyzing", "executing", "waiting_data"}:
            raise ValueError("Cannot start duplicate run: bot is already active. Stop it first.")
        if account_target and account_target.lower() != "demo":
            raise ValueError("continuous_worker_demo_only")
        if (s.environment_mode != EnvironmentMode.DEMO.value or s.account_target != "demo"
                or s.market_type not in {MarketType.SPOT.value, MarketType.FUTURES.value}):
            raise ValueError("continuous_worker_demo_spot_or_futures_only")

        checks = {
            "account_target": s.account_target,
            "environment_mode": s.environment_mode,
            "market_type": s.market_type,
            "demo_data_available": True,
            "binance_public_read_only_adapter": True,
            "continuous_worker_available": True,
            "manual_demo_cycle_available": True,
            "binance_testnet_authenticated": False,
            "compliance_engine": True,
            "risk_limits_present": bool(s.risk_limits),
            "withdrawal_permissions": False,
            "execution_scope": "internal_demo_shadow_only",
        }
        # Atomic compare-and-set prevents two API workers from both starting
        # a resident worker after reading the same previous "stopped" state.
        claimed = db.execute(
            update(SystemState)
            .where(SystemState.id == 1, SystemState.bot_run_state == "stopped")
            .values(
                bot_run_state="starting",
                bot_started_at=_utcnow(),
                bot_stopped_at=None,
                bot_stop_reason="worker_start_requested",
                autonomous_enabled=False,
            )
        )
        if claimed.rowcount != 1:
            db.rollback()
            raise ValueError("Cannot start duplicate run: another worker claimed startup.")
        db.commit()
        db.refresh(s)
        log_event(db, action="master.start_requested",
                  message=f"Demo/{s.market_type.title()} Shadow worker startup requested; supervisor must confirm the worker is running.",
                  details=checks, environment_mode=s.environment_mode, market_type=s.market_type)
        db.commit()
        return {
            "ok": True,
            "state": self.get_state(db),
            "checks": checks,
            "note": "Worker startup is pending supervisor confirmation. The selected Spot/Futures worker uses Binance public read-only data and internal Demo/Shadow records only; it never sends Binance orders.",
        }

    def stop_bot(self, db: Session, *, reason: str = "user_stop", close_positions: bool = False) -> dict[str, Any]:
        s = self._state(db)
        s.bot_run_state = "stopped"
        s.bot_stopped_at = _utcnow()
        s.bot_stop_reason = reason
        s.autonomous_enabled = False
        db.add(s)
        log_event(db, action="master.stop", severity="warning", message=f"Bot stopped: {reason}.", details={"close_positions_requested": bool(close_positions), "note": "Stops new actions/orders. Open positions are NOT auto-closed unless explicitly handled by a verified execution adapter."},
                  environment_mode=s.environment_mode, market_type=s.market_type)
        db.commit()
        return {"ok": True, "state": self.get_state(db), "close_positions_requested": bool(close_positions)}

    def engines(self, db: Session) -> list[dict[str, Any]]:
        self._state(db)
        rows = db.execute(select(EngineState).order_by(EngineState.engine_key)).scalars().all()
        return [{"key": r.engine_key, "name": r.name, "status": r.status, "message": r.message, "updated_at": r.updated_at.isoformat() if r.updated_at else None} for r in rows]

    def strategies(self) -> list[dict[str, Any]]:
        return list_strategies()

    @staticmethod
    def _validate_public_market_batches(market_batches: dict, expected_market: str = "spot") -> None:
        """Fail closed if any required public timeframe is missing, stale, or malformed."""
        required = {
            Timeframe.D1: 86400,
            Timeframe.H4: 14400,
            Timeframe.H1: 3600,
            Timeframe.M15: 900,
            Timeframe.M5: 300,
        }
        now = datetime.now(timezone.utc).timestamp()
        for timeframe, seconds in required.items():
            batch = market_batches.get(timeframe)
            if (batch is None
                    or getattr(getattr(batch, "source", None), "value", None) != "live_public"
                    or getattr(batch, "market_type", "spot") != expected_market):
                raise ValueError(f"verified_binance_{expected_market}_public_data_required:{timeframe.value}")
            if not batch.df or len(batch.df) < 30:
                raise ValueError(f"insufficient_public_market_data:{timeframe.value}")
            last = batch.df.rows[-1]
            stamp = last.get("close_time") or last.get("timestamp")
            try:
                if isinstance(stamp, bool) or stamp is None:
                    raise ValueError("missing_timestamp")
                if isinstance(stamp, (int, float)):
                    stamp_seconds = float(stamp) / 1000.0
                elif isinstance(stamp, str):
                    stamp_seconds = datetime.fromisoformat(stamp.replace("Z", "+00:00")).timestamp()
                else:
                    raise ValueError("invalid_timestamp_type")
            except (TypeError, ValueError, OverflowError) as exc:
                raise ValueError(f"invalid_public_candle_timestamp:{timeframe.value}") from exc
            age = now - stamp_seconds
            allowed_age = max(300.0, float(seconds) * 2.0)
            if not math.isfinite(stamp_seconds) or age < -60.0 or age > allowed_age:
                raise ValueError(f"stale_or_future_public_market_data:{timeframe.value}")

    def analyze(self, db: Session, *, symbol: str, market_type: str, environment_mode: str, balance: float = 1000.0, max_leverage: float = 3.0, risk_per_trade: float = 0.01, data_source: str = "synthetic", market_batches: dict | None = None) -> dict[str, Any]:
        self.ensure_bootstrap(db)
        market = MarketType(market_type)
        env = EnvironmentMode(environment_mode)
        if env == EnvironmentMode.LIVE and not settings.live_trading_enabled:
            raise ValueError("Live analysis/execution is disabled by configuration. Use DEMO or enable live explicitly in a controlled deployment.")
        if market_batches is not None:
            batches = market_batches
        elif data_source == "binance_public":
            public_market = "futures" if market == MarketType.FUTURES else "spot"
            batches = self.market_data.get_public_multi_timeframe(symbol, market_type=public_market)
        elif data_source == "synthetic":
            batches = self.market_data.get_multi_timeframe(symbol, seed=42, market_type=market.value)
        else:
            raise ValueError("unsupported_data_source")
        if data_source == "binance_public":
            public_market = "futures" if market == MarketType.FUTURES else "spot"
            self._validate_public_market_batches(batches, expected_market=public_market)
        analyses = {tf.value: self.technical.analyze(batch.df, tf) for tf, batch in batches.items()}
        # Portfolio-wide gross exposure and position count are evaluated before
        # every proposed entry, not independently per symbol.
        open_positions = db.execute(select(PositionRecord).where(
            PositionRecord.environment_mode == env.value,
            PositionRecord.market_type == market.value,
            PositionRecord.status == "open",
        )).scalars().all()
        current_exposure = sum(
            abs(float(p.mark_price or p.entry_avg_price or 0.0) * float(p.quantity or 0.0))
            for p in open_positions
        )
        try:
            balance_value = float(balance)
            exposure_multiple = float(settings.max_portfolio_exposure_multiple)
        except (TypeError, ValueError, OverflowError):
            raise ValueError("invalid_portfolio_exposure_configuration")
        if (not math.isfinite(balance_value) or balance_value <= 0
                or not math.isfinite(exposure_multiple) or exposure_multiple <= 0):
            raise ValueError("invalid_portfolio_exposure_configuration")
        # Keep advisory sizing aligned with the independent Shadow execution
        # ceiling; leverage must not multiply the permitted gross portfolio cap.
        max_portfolio_exposure = balance_value * exposure_multiple
        state = db.get(SystemState, 1)
        raw_limits = getattr(state, "risk_limits", None) if state else None
        if raw_limits is not None and not isinstance(raw_limits, dict):
            max_open_positions = 0
        else:
            risk_limits = raw_limits or {}
            configured_positions = risk_limits.get(
                "max_open_positions_cap", settings.max_open_positions_cap,
            )
            if type(configured_positions) is not int:
                max_open_positions = 0
            else:
                max_open_positions = max(0, min(
                    configured_positions, settings.max_open_positions_cap,
                ))
        microstructure_analysis = {"status": "not_available"}
        if data_source == "binance_public" and market in {MarketType.SPOT, MarketType.FUTURES}:
            public_market = "futures" if market == MarketType.FUTURES else "spot"
            liquidity = LiquidityAnalysisEngine().fetch_and_analyze(
                symbol, limit=100, market_type=public_market,
            )
            order_flow = OrderFlowEngine().fetch_and_analyze(
                symbol, limit=500, market_type=public_market,
            )
            microstructure_analysis = {
                "liquidity": liquidity,
                "order_flow": order_flow,
                "status": "available" if liquidity.get("ok") and order_flow.get("ok") else "partial_or_unavailable",
            }
        result = self.decision.decide(
            symbol=symbol, market=market, environment=env,
            timeframe_analyses={Timeframe(k): v for k, v in analyses.items()},
            balance=balance, max_leverage=max_leverage, risk_per_trade=risk_per_trade,
            batches=batches, microstructure_analysis=microstructure_analysis,
            open_positions=len(open_positions), current_exposure=current_exposure,
            max_exposure=max_portfolio_exposure, max_open_positions=max_open_positions,
        )
        rec = DecisionRecord(
            environment_mode=env.value, market_type=market.value, symbol=symbol,
            action=result.get("action", "wait"), strategy=result.get("strategy"),
            confidence=result.get("confidence"), entry_price=result.get("entry_price"),
            stop_loss=result.get("stop_loss"), take_profit=result.get("take_profit"),
            risk_reward=result.get("risk_reward"), leverage=result.get("leverage"),
            rationale=result.get("reason", ""), timeframe_context=result.get("timeframes"),
            indicators={
                "per_timeframe_last": {k: v.indicators for k, v in analyses.items()},
                "microstructure": result.get("microstructure_analysis"),
            },
            costs=result.get("costs"), news_context=None, data_source=result.get("data_source", "synthetic_labeled"),
            reproducibility={"app_version": "0.1.0-foundation", "inputs": {"symbol": symbol, "market_type": market.value, "environment_mode": env.value, "balance": balance, "max_leverage": max_leverage, "risk_per_trade": risk_per_trade},
                              "timeframes": [t.value for t in batches.keys()], "data_labels": {t.value: b.source.value for t, b in batches.items()},
                              "note": "Replay requires the same market-data provider, timestamps, configuration, and analysis version."},
        )
        db.add(rec)
        log_event(db, action="analysis.decision", message=f"Decision {rec.action} for {symbol} ({env.value}/{market.value}).",
                  environment_mode=env.value, market_type=market.value, entity_type="decision", details={"symbol": symbol, "action": rec.action, "confidence": rec.confidence})
        db.commit(); db.refresh(rec)
        result["decision_id"] = rec.id
        result["recorded"] = True
        return result

    def get_engines_detailed(self, db: Session) -> list[dict[str, Any]]:
        self._state(db)
        rows = db.execute(select(EngineState).order_by(EngineState.engine_key)).scalars().all()
        result = []
        for r in rows:
            result.append({
                "key": r.engine_key,
                "name": r.name,
                "status": r.status,
                "message": r.message,
                "details": r.details or {},
                "updated_at": r.updated_at.isoformat() if r.updated_at else None,
                "can_start_stop": True,
                "controls": ["start", "stop", "restart", "test"]
            })
        return result

    def control_engine(self, db: Session, key: str, action: str, user: str = "system") -> dict[str, Any]:
        from .audit import log_event
        es = db.execute(select(EngineState).where(EngineState.engine_key == key)).scalar_one_or_none()
        if not es:
            return {"ok": False, "error": "engine_not_found"}
        action = (action or "").lower()
        if action in {"start", "stop", "restart"}:
            # Registry status is metadata, not a process supervisor. Do not
            # claim an engine was started/stopped when no runtime adapter exists.
            return {
                "ok": False,
                "error": "engine_lifecycle_not_implemented",
                "engine": key,
                "requested_action": action,
                "current_status": es.status,
            }
        if action == "test":
            # A status write is not an engine self-test. Fail honestly until a
            # real, isolated self-test is implemented for the selected engine.
            return {
                "ok": False,
                "error": "engine_self_test_not_implemented",
                "engine": key,
                "current_status": es.status,
            }
        return {"ok": False, "error": "unknown_action"}



core_service = TitanCoreService()

