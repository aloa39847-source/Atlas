from __future__ import annotations

from dataclasses import dataclass
import math
import re
from typing import Any

from app.core.enums import MarketType
from app.core.config import settings
from .compliance import compliance_engine


@dataclass
class GatewayDecision:
    ok: bool
    reason: str
    normalized: dict[str, Any]
    warnings: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {"ok": self.ok, "reason": self.reason, "normalized": self.normalized, "warnings": self.warnings}


class PreTradeOrderGateway:
    """Independent pre-trade safety layer. No AI model may bypass it.

    This validates request shape and basic safety constraints. Exchange-specific
    filters (tick/step/minNotional), balances, and live order state require
    Binance adapter integration and reconciliation.
    """

    def validate(
        self,
        *,
        symbol: str,
        market: MarketType,
        side: str,
        order_type: str,
        quantity: float | None,
        price: float | None = None,
        reference_price: float | None = None,
        max_notional: float | None = None,
        idempotency_key: str | None = None,
        reduce_only: bool = False,
        verified_position_close: bool = False,
        leverage: float = 1.0,
        environment_mode: str = "demo",
        live_enabled: bool = False,
        api_permissions: list[str] | None = None,
        bypass_attempt: bool = False,
        geo_verified: bool | None = None,
        kyc_verified: bool | None = None,
        rate_limit_ok: bool | None = None,
        exchange_filters: dict | None = None,
    ) -> GatewayDecision:
        warnings: list[str] = []
        if not isinstance(market, MarketType):
            return GatewayDecision(False, "invalid_market_type", {}, warnings)
        if not isinstance(symbol, str) or not isinstance(side, str) or not isinstance(order_type, str):
            return GatewayDecision(False, "invalid_order_text_fields", {}, warnings)
        if any(isinstance(value, bool) for value in (quantity, price, reference_price, max_notional, leverage)):
            return GatewayDecision(False, "boolean_numeric_input_not_allowed", {}, warnings)
        if type(reduce_only) is not bool:
            return GatewayDecision(False, "reduce_only_must_be_boolean", {}, warnings)
        if type(verified_position_close) is not bool:
            return GatewayDecision(False, "verified_position_close_must_be_boolean", {}, warnings)
        if idempotency_key is not None and not isinstance(idempotency_key, str):
            return GatewayDecision(False, "invalid_idempotency_key", {}, warnings)
        if type(live_enabled) is not bool:
            return GatewayDecision(False, "invalid_live_enabled_flag", {}, warnings)
        if api_permissions is not None and not isinstance(api_permissions, list):
            return GatewayDecision(False, "invalid_api_permissions", {}, warnings)
        if exchange_filters is not None and not isinstance(exchange_filters, dict):
            return GatewayDecision(False, "invalid_exchange_filters", {}, warnings)
        # Fail closed on malformed, NaN, or infinite numeric order inputs
        # before compliance checks or arithmetic can raise or accept them.
        try:
            quantity = float(quantity) if quantity is not None else None
            price = float(price) if price is not None else None
            reference_price = float(reference_price) if reference_price is not None else None
            max_notional = float(max_notional) if max_notional is not None else None
            leverage = float(leverage)
        except (TypeError, ValueError, OverflowError):
            return GatewayDecision(False, "invalid_numeric_input", {}, warnings)
        numeric_values = [v for v in (quantity, price, reference_price, max_notional, leverage) if v is not None]
        if not all(math.isfinite(v) for v in numeric_values):
            return GatewayDecision(False, "non_finite_numeric_input", {}, warnings)
        if quantity is None or quantity <= 0:
            return GatewayDecision(False, "invalid_quantity", {"quantity": quantity}, warnings)
        if price is not None and price <= 0:
            return GatewayDecision(False, "invalid_price", {"price": price}, warnings)
        if reference_price is not None and reference_price <= 0:
            return GatewayDecision(False, "invalid_reference_price", {"reference_price": reference_price}, warnings)
        if max_notional is not None and max_notional <= 0:
            return GatewayDecision(False, "invalid_max_notional", {"max_notional": max_notional}, warnings)
        comp = compliance_engine.check_order_action(
            market=market, symbol=symbol or "", side=side or "", quantity=quantity, price=price,
            environment_mode=environment_mode, live_enabled=live_enabled, api_permissions=api_permissions,
            bypass_attempt=bypass_attempt, geo_verified=geo_verified, kyc_verified=kyc_verified, rate_limit_ok=rate_limit_ok,
        )
        if not comp.ok or comp.action == "block":
            return GatewayDecision(False, f"compliance_block:{comp.reason}", {"compliance": comp.to_dict()}, warnings)
        if comp.action == "review_required":
            return GatewayDecision(False, f"compliance_review_required:{comp.reason}", {"compliance": comp.to_dict()}, warnings)
        if live_enabled and (not idempotency_key or len(idempotency_key.strip()) < 8):
            return GatewayDecision(False, "live_order_idempotency_key_required", {}, warnings)
        warnings.append(f"compliance:{comp.action}:{comp.reason}")
        sym = (symbol or "").strip().upper()
        if not re.fullmatch(r"[A-Z0-9]{2,20}(?:/[A-Z0-9]{2,20})?", sym):
            return GatewayDecision(False, "invalid_symbol", {"symbol": symbol}, warnings)
        sd = (side or "").strip().lower()
        if market == MarketType.SPOT and sd not in {"buy", "sell"}:
            return GatewayDecision(False, "invalid_spot_side", {"side": side}, warnings)
        if market == MarketType.FUTURES and sd not in {"buy", "sell", "long", "short"}:
            return GatewayDecision(False, "invalid_futures_side", {"side": side}, warnings)
        if market == MarketType.EARN:
            return GatewayDecision(False, "earn_not_order_execution", {"market": market.value}, warnings)
        if reduce_only and market != MarketType.FUTURES:
            return GatewayDecision(False, "reduce_only_futures_only", {"market": market.value}, warnings)
        if reduce_only and sd not in {"buy", "sell"}:
            return GatewayDecision(False, "reduce_only_requires_buy_or_sell_side", {"side": sd}, warnings)
        if verified_position_close and (market != MarketType.SPOT or sd != "sell"):
            return GatewayDecision(False, "verified_position_close_spot_sell_only", {"market": market.value, "side": sd}, warnings)
        if leverage < 1.0:
            return GatewayDecision(False, "invalid_leverage", {"leverage": leverage}, warnings)
        if market == MarketType.SPOT and leverage != 1.0:
            return GatewayDecision(False, "spot_leverage_not_supported", {"leverage": leverage}, warnings)
        if market == MarketType.FUTURES and leverage > settings.max_leverage_cap:
            return GatewayDecision(False, "leverage_exceeds_limit", {"leverage": leverage, "max_leverage": settings.max_leverage_cap}, warnings)
        ot = (order_type or "").strip().lower()
        if ot not in {"market", "limit", "stop", "stop_limit"}:
            return GatewayDecision(False, "unsupported_order_type", {"order_type": ot}, warnings)
        px = price if price is not None else reference_price
        if px is None:
            return GatewayDecision(False, "reference_price_required_for_pretrade", {}, warnings)
        if reference_price and price and reference_price > 0:
            deviation = abs(price - reference_price) / reference_price
            if deviation > 0.2:
                return GatewayDecision(False, "price_deviation_too_large", {"deviation": deviation}, warnings)
            if deviation > 0.03:
                warnings.append("price_deviates_from_reference")
        notional = (px or 0.0) * quantity
        configured_cap = (
            settings.max_spot_trade_notional if market == MarketType.SPOT
            else settings.max_futures_trade_notional if market == MarketType.FUTURES
            else 0.0
        )
        effective_cap = configured_cap if max_notional is None else min(configured_cap, float(max_notional))
        # A validated Futures reduce-only close lowers an existing position;
        # it must remain possible even when mark-price appreciation pushes its
        # exit notional above the entry cap. An explicit caller-supplied cap
        # remains enforceable.
        reduce_only_exit = market == MarketType.FUTURES and reduce_only and max_notional is None
        position_close_exit = market == MarketType.SPOT and verified_position_close and max_notional is None
        if px and notional > effective_cap and not (reduce_only_exit or position_close_exit):
            return GatewayDecision(False, "notional_exceeds_limit", {"notional": notional, "max_notional": effective_cap}, warnings)
        if idempotency_key is not None and len(idempotency_key.strip()) < 8:
            return GatewayDecision(False, "weak_idempotency_key", {"idempotency_key": "masked"}, warnings)
        # Binance exchange filters (tickSize, stepSize, minNotional)
        filters_checked = False
        if exchange_filters:
            filters_checked = True
            if any(isinstance(exchange_filters.get(key), bool) for key in ("tickSize", "stepSize", "minNotional")):
                return GatewayDecision(False, "invalid_exchange_filters", {}, warnings)
            try:
                tick = float(exchange_filters.get("tickSize", 0) or 0)
                step = float(exchange_filters.get("stepSize", 0) or 0)
                min_notional = float(exchange_filters.get("minNotional", 0) or 0)
                if not all(math.isfinite(value) and value >= 0 for value in (tick, step, min_notional)):
                    return GatewayDecision(False, "invalid_exchange_filters", {}, warnings)
                if price is not None and tick > 0:
                    rem = (price / tick) % 1
                    if abs(rem) > 1e-9 and abs(rem - 1) > 1e-9:
                        return GatewayDecision(False, "price_not_aligned_to_tick_size", {"price": price, "tickSize": tick}, warnings)
                if step > 0:
                    rem = (quantity / step) % 1
                    if abs(rem) > 1e-9 and abs(rem - 1) > 1e-9:
                        return GatewayDecision(False, "quantity_not_aligned_to_step_size", {"quantity": quantity, "stepSize": step}, warnings)
                if min_notional > 0 and notional and notional < min_notional:
                    return GatewayDecision(False, "below_min_notional", {"notional": notional, "minNotional": min_notional}, warnings)
            except Exception as e:
                return GatewayDecision(False, "exchange_filter_validation_error", {"error": str(e)}, warnings)
        normalized = {
            "symbol": sym, "market": market.value, "side": sd, "order_type": ot,
            "quantity": quantity, "price": price, "reference_price": reference_price,
            "notional_estimate": notional if px else None, "idempotency_key_present": bool(idempotency_key),
            "reduce_only": bool(reduce_only), "leverage": leverage,
            "exchange_filters_checked": filters_checked,
            "notional_cap_bypassed_for_reduce_only": reduce_only_exit,
            "notional_cap_bypassed_for_verified_spot_close": position_close_exit,
            "exchange_balance_checked": False,
        }
        if not filters_checked:
            warnings.append("exchange_filters_balance_reconciliation_required_before_live_send")
        return GatewayDecision(True, "accepted_for_precheck", normalized, warnings)
