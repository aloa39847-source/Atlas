from __future__ import annotations

import hashlib
import hmac
import os
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.entities import AppUser, AuthSession
from .audit import log_event

PBKDF2_ITERATIONS = 200_000


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def normalize_email(email: str) -> str:
    return (email or "").strip().lower()


def get_allowed_emails() -> set[str]:
    raw = os.getenv("TITAN_ALLOWED_EMAILS", "").strip()
    if not raw:
        return set()
    return {normalize_email(x) for x in raw.split(",") if normalize_email(x)}


def hash_password(password: str, salt_hex: str | None = None) -> tuple[str, str]:
    if not password:
        raise ValueError("password required")
    salt = bytes.fromhex(salt_hex) if salt_hex else secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return dk.hex(), salt.hex()


def verify_password(password: str, password_hash: str | None, salt_hex: str | None) -> bool:
    if not password or not password_hash or not salt_hex:
        return False
    calc, _ = hash_password(password, salt_hex)
    return hmac.compare_digest(calc, password_hash)


def auth_required() -> bool:
    # Match Settings.auth_required: authentication is secure-by-default.
    return os.getenv("TITAN_AUTH_REQUIRED", "true").strip().lower() in {"1", "true", "yes", "on"}


def email_allowed(email: str) -> bool:
    allowed = get_allowed_emails()
    if allowed:
        return normalize_email(email) in allowed
    # If auth is required, an explicit allowlist is required for safety.
    if auth_required():
        return False
    return True  # local/dev convenience when auth not required and no allowlist configured


def ensure_user(db: Session, email: str) -> AppUser:
    e = normalize_email(email)
    user = db.execute(select(AppUser).where(AppUser.email == e)).scalar_one_or_none()
    if not user:
        user = AppUser(email=e, is_active=True, is_admin=True)
        db.add(user)
        db.flush()
    return user


def set_password(db: Session, email: str, password: str) -> AppUser:
    if not email_allowed(email):
        raise ValueError("email not allowed")
    user = ensure_user(db, email)
    ph, salt = hash_password(password)
    user.password_hash = ph
    user.password_salt = salt
    user.failed_login_count = 0
    db.add(user)
    log_event(db, action="auth.password_set", actor="local_setup", message="Password hash updated (value not logged).", details={"email": normalize_email(email)})
    return user


def create_session(db: Session, user: AppUser, ttl_hours: int = 24 * 7, ip_address: str | None = None, user_agent: str | None = None) -> str:
    token = secrets.token_urlsafe(32)
    token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
    sess = AuthSession(
        user_id=user.id,
        token_hash=token_hash,
        expires_at=_utcnow() + timedelta(hours=ttl_hours),
        ip_address=ip_address,
        user_agent=(user_agent or "")[:1000],
    )
    db.add(sess)
    user.last_login_at = _utcnow()
    user.failed_login_count = 0
    db.add(user)
    log_event(db, action="auth.login", actor=normalize_email(user.email), message="User logged in.")
    return token


def revoke_session(db: Session, token: str) -> bool:
    token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
    sess = db.execute(select(AuthSession).where(AuthSession.token_hash == token_hash, AuthSession.revoked_at.is_(None))).scalar_one_or_none()
    if not sess:
        return False
    sess.revoked_at = _utcnow()
    db.add(sess)
    log_event(db, action="auth.logout", actor="user", message="Session revoked.")
    return True


def authenticate(db: Session, email: str, password: str) -> AppUser | None:
    e = normalize_email(email)
    if not email_allowed(e):
        log_event(db, action="auth.denied", severity="warning", message="Login denied for non-allowlisted email.", details={"email": e})
        return None
    user = db.execute(select(AppUser).where(AppUser.email == e)).scalar_one_or_none()
    if not user or not user.is_active:
        log_event(db, action="auth.failed", severity="warning", message="Login failed (unknown/inactive user).", details={"email": e})
        return None
    if user.failed_login_count >= 10:
        log_event(db, action="auth.locked", severity="warning", message="Login blocked due to repeated failures.", details={"email": e})
        return None
    if not verify_password(password, user.password_hash, user.password_salt):
        user.failed_login_count += 1
        db.add(user)
        log_event(db, action="auth.failed", severity="warning", message="Login failed (invalid password).", details={"email": e})
        return None
    return user


def get_session_user(db: Session, token: str | None) -> AppUser | None:
    if not token:
        return None
    token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
    sess = db.execute(select(AuthSession).where(AuthSession.token_hash == token_hash, AuthSession.revoked_at.is_(None))).scalar_one_or_none()
    if not sess:
        return None
    exp = sess.expires_at
    if exp.tzinfo is None:
        exp = exp.replace(tzinfo=timezone.utc)
    if exp < _utcnow():
        return None
    return db.get(AppUser, sess.user_id)
