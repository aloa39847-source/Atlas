import React, { useState } from 'react'
import { api } from './api'

export default function ArbitragePanel() {
  const [route, setRoute] = useState('USDT,BTC,ETH,USDT')
  const [amount, setAmount] = useState('1000')
  const [fee, setFee] = useState('0.001')
  const [slippage, setSlippage] = useState('0.0005')
  const [threshold, setThreshold] = useState('0.05')
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function run(e) {
    e.preventDefault()
    setBusy(true); setError(''); setResult(null)
    try {
      const assets = route.split(',').map(x => x.trim().toUpperCase()).filter(Boolean)
      const data = await api.analyzeArbitrage({
        route: assets,
        starting_amount: Number(amount),
        fee_rate: Number(fee),
        slippage_rate: Number(slippage),
        min_profit_pct: Number(threshold),
      })
      setResult(data)
    } catch (err) {
      setError(err.message || 'تعذر تحليل مسار المراجحة')
    } finally {
      setBusy(false)
    }
  }

  return <div className="card">
    <h3>محلل المراجحة المثلثية — Spot</h3>
    <p className="muted">يفحص ثلاث أزواج من بيانات Binance العامة للقراءة فقط، ويحسب أثر الرسوم والانزلاق. لا ينفذ أي أمر تداول ولا يضمن إمكانية تنفيذ الفرصة.</p>
    <form onSubmit={run}>
      <div className="row">
        <div style={{flex:2,minWidth:220}}>
          <label>مسار الأصول (ثلاث تحويلات، مع العودة للأصل)</label>
          <input value={route} onChange={e=>setRoute(e.target.value)} placeholder="USDT,BTC,ETH,USDT" />
        </div>
        <div style={{flex:1,minWidth:130}}>
          <label>مبلغ البداية</label>
          <input type="number" min="0.000001" step="any" value={amount} onChange={e=>setAmount(e.target.value)} />
        </div>
      </div>
      <div className="row">
        <div style={{flex:1,minWidth:130}}><label>رسوم كل تحويل</label><input type="number" min="0" max="0.999999" step="any" value={fee} onChange={e=>setFee(e.target.value)} /></div>
        <div style={{flex:1,minWidth:130}}><label>انزلاق كل تحويل</label><input type="number" min="0" max="0.999999" step="any" value={slippage} onChange={e=>setSlippage(e.target.value)} /></div>
        <div style={{flex:1,minWidth:130}}><label>أدنى ربح تقديري (%)</label><input type="number" min="0" step="any" value={threshold} onChange={e=>setThreshold(e.target.value)} /></div>
      </div>
      <button disabled={busy}>{busy ? 'جارٍ الفحص...' : 'فحص مسار المراجحة'}</button>
    </form>
    {error && <p className="error">{error}</p>}
    {result && <div style={{marginTop:12}}>
      <div className="row">
        <strong>النتيجة:</strong>
        <span className="pill">{result.assessment || result.error || 'غير متاح'}</span>
      </div>
      {result.ok && <>
        <div className="grid">
          <div className="card"><div className="muted">مبلغ النهاية التقديري</div><strong>{result.ending_amount_estimate}</strong></div>
          <div className="card"><div className="muted">الربح/الخسارة التقديرية</div><strong>{result.profit_estimate} ({result.profit_percent_estimate}%)</strong></div>
          <div className="card"><div className="muted">مرشح فقط</div><strong>{String(result.candidate)}</strong></div>
        </div>
        <div className="table-wrap"><table><thead><tr><th>التحويل</th><th>السوق</th><th>الاتجاه</th><th>الناتج بعد التكاليف</th></tr></thead>
          <tbody>{(result.legs || []).map((leg,i)=><tr key={i}><td>{leg.from_asset} → {leg.to_asset}</td><td>{leg.market_symbol}</td><td>{leg.execution_side}</td><td>{leg.output_after_estimated_costs}</td></tr>)}</tbody>
        </table></div>
        <ul>{(result.limitations || []).map((item,i)=><li key={i} className="muted">{item}</li>)}</ul>
      </>}
      {!result.ok && <p className="muted">{result.error || result.detail || 'تعذر الحصول على بيانات صالحة.'}</p>}
    </div>}
  </div>
}
