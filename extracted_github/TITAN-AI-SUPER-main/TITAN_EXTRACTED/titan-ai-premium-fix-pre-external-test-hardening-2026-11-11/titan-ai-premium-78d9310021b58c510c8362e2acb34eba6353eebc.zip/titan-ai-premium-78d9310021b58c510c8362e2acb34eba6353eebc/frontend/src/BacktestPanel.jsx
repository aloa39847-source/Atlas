import React, { useState } from 'react'
import { api } from './api'

export default function BacktestPanel() {
  const [symbol, setSymbol] = useState('BTC/USDT')
  const [timeframe, setTimeframe] = useState('1h')
  const [marketType, setMarketType] = useState('spot')
  const [leverage, setLeverage] = useState('3')
  const [notional, setNotional] = useState('800')
  const [entryFillRatio, setEntryFillRatio] = useState('1')
  const [exitFillRatio, setExitFillRatio] = useState('1')
  const [strategyKey, setStrategyKey] = useState('trend_following_ema')
  const [mode, setMode] = useState('walk_forward')
  const [initialCash, setInitialCash] = useState('150')
  const [limit, setLimit] = useState('240')
  const [result, setResult] = useState(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  async function run() {
    setBusy(true); setError(''); setResult(null)
    try {
      const payload = {
        symbol: symbol.trim().toUpperCase(),
        timeframe,
        strategy_key: strategyKey,
        mode,
        initial_cash: Number(initialCash),
        limit: Number(limit),
        fee_rate: 0.001,
        slippage_rate: 0.0005,
      }
      if (mode === 'walk_forward') {
        payload.train_window = 60
        payload.test_window = 30
        payload.step = 30
      }
      if (marketType === 'futures') {
        setResult(await api.backtestFutures({
          symbol: payload.symbol, timeframe, strategy_key: strategyKey,
          initial_cash: Number(initialCash), limit: Number(limit),
          max_leverage: 10, leverage: Number(leverage), max_notional: 800,
          notional: Number(notional), entry_fill_ratio: Number(entryFillRatio),
          exit_fill_ratio: Number(exitFillRatio),
        }))
      } else {
        setResult(await api.backtestStrategy(payload))
      }
    } catch (e) {
      setError(e.message || 'تعذر تنفيذ الاختبار التاريخي')
    } finally {
      setBusy(false)
    }
  }

  return <div className="card" style={{marginTop:12}}>
    <h3>مختبر الاستراتيجيات — Backtesting / Walk-Forward</h3>
    <div className="notice">Spot يستخدم Backtesting وWalk-Forward. Futures يستخدم بيانات USD-M العامة مع رسوم وتمويل وتعبئة جزئية وتصفية تقديرية؛ محاكاة بحثية فقط وليست مطابقة كاملة لمحرك Binance. لا توجد أوامر حقيقية.</div>
    <div className="row" style={{marginTop:10}}>
      <div style={{flex:1}}><label>نوع السوق</label><select value={marketType} onChange={e=>{setMarketType(e.target.value); if(e.target.value==='futures') setMode('historical')}}><option value="spot">Spot</option><option value="futures">USD-M Futures</option></select></div>
      <div style={{flex:1}}><label>زوج USDT</label><input value={symbol} onChange={e=>setSymbol(e.target.value.toUpperCase())}/></div>
      <div style={{flex:1}}><label>الإطار</label><select value={timeframe} onChange={e=>setTimeframe(e.target.value)}><option value="1d">1D</option><option value="4h">4H</option><option value="1h">1H</option><option value="15m">15M</option><option value="5m">5M</option></select></div>
    </div>
    <div className="row" style={{marginTop:8}}>
      <div style={{flex:1}}><label>الاستراتيجية</label><select value={strategyKey} onChange={e=>setStrategyKey(e.target.value)}>
        <option value="trend_following_ema">Trend Following EMA</option>
        <option value="momentum_macd_rsi">Momentum MACD/RSI</option>
        <option value="mean_reversion_bbands">Mean Reversion Bollinger/RSI</option>
        <option value="breakout_structure">Breakout / Market Structure</option>
        <option value="scalping_m5">Scalping M5</option>
        <option value="swing_h1_h4">Swing H1/H4</option>
      </select></div>
      <div style={{flex:1}}><label>نوع الاختبار</label><select value={mode} onChange={e=>setMode(e.target.value)} disabled={marketType==='futures'}><option value="walk_forward">Walk-Forward OOS</option><option value="historical">Historical</option></select></div>
    </div>
    {marketType === 'futures' && <div className="row" style={{marginTop:8}}>
      <div style={{flex:1}}><label>الرافعة (حتى 10x)</label><input type="number" min="1" max="10" step="1" value={leverage} onChange={e=>setLeverage(e.target.value)} /></div>
      <div style={{flex:1}}><label>القيمة الاسمية للصفقة (حد 800 USDT)</label><input type="number" min="1" max="800" step="any" value={notional} onChange={e=>setNotional(e.target.value)} /></div>
      <div style={{flex:1}}><label>نسبة تعبئة الدخول</label><input type="number" min="0" max="1" step="0.05" value={entryFillRatio} onChange={e=>setEntryFillRatio(e.target.value)} /></div>
      <div style={{flex:1}}><label>نسبة تعبئة الخروج</label><input type="number" min="0.01" max="1" step="0.05" value={exitFillRatio} onChange={e=>setExitFillRatio(e.target.value)} /></div>
    </div>}
    <div className="row" style={{marginTop:8}}>
      <div style={{flex:1}}><label>رأس المال التجريبي USDT</label><input value={initialCash} onChange={e=>setInitialCash(e.target.value)} inputMode="decimal"/></div>
      <div style={{flex:1}}><label>عدد الشموع (60–500)</label><input value={limit} onChange={e=>setLimit(e.target.value)} inputMode="numeric"/></div>
      <button type="button" onClick={run} disabled={busy}>{busy ? 'جارٍ الاختبار...' : 'تشغيل الاختبار'}</button>
    </div>
    {error && <div className="error" style={{marginTop:10}}>{error}</div>}
    {result && <div style={{marginTop:12}}>
      <div className="row"><span className="pill">{result.validation || 'historical_simulation'}</span><span className="muted">{result.symbol} | {result.timeframe} | {result.data_source} | {result.candles} شمعة</span></div>
      <div className="grid" style={{marginTop:8}}>
        {[
          ['Trades',result.total_trades ?? result.total_trades],
          ['Win rate',result.win_rate],
          ['Profit factor',result.profit_factor ?? '—'],
          ['Expectancy',result.expectancy],
          ['Return',mode === 'walk_forward' ? result.compounded_oos_return : result.total_return],
          ['Max drawdown',mode === 'walk_forward' ? result.max_fold_drawdown : result.max_drawdown],
          ['Fees',result.fees_paid],
          ['Slippage',result.slippage_cost],
          ...(marketType === 'futures' ? [['Funding net',result.funding_net],['Liquidations',result.liquidations],['Partial fills',result.partial_fills]] : []),
        ].map(([label,value])=><div className="card" key={label}><div className="muted">{label}</div><b>{String(value ?? '—')}</b></div>)}
      </div>
      {result.folds?.length > 0 && <div className="table-wrap" style={{marginTop:10}}><table><thead><tr><th>Fold</th><th>Train candles</th><th>Test candles</th><th>Return</th><th>Trades</th><th>Drawdown</th></tr></thead><tbody>
        {result.folds.map(f=><tr key={f.fold}><td>{f.fold}</td><td>{f.training_candles}</td><td>{f.testing_candles}</td><td>{f.result?.total_return}</td><td>{f.result?.total_trades}</td><td>{f.result?.max_drawdown}</td></tr>)}
      </tbody></table></div>}
      <details style={{marginTop:10}}><summary>تفاصيل الاختبار</summary><pre>{JSON.stringify(result,null,2)}</pre></details>
      <div className="muted">{result.note}</div>
    </div>}
  </div>
}
