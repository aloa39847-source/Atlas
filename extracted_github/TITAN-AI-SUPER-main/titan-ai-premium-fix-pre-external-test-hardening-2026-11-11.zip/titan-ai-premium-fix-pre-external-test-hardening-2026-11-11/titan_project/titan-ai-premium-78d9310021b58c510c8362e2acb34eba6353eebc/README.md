# TITAN SUPER AI PREMIUM (Foundation Build)

This workspace contains an **integrated, extensible foundation** for TITAN SUPER AI PREMIUM (Backend + Frontend + SQLite + tests/docs). It follows the core safety and architecture requirements from the master specification, but **it is not the full final system**. Some advanced engines/integrations remain partial or require external services.

> Historical reports dated 2026-11-07 are retained as records of earlier source/archive snapshots. Their test totals, archive names, and completion claims are not current release evidence; use the Verification section below for the latest checks.

## What is real in this build
- **Separation enforced in design/state**: `demo/live` and `spot/futures/earn` are explicit. Auto demo→live is disabled. Withdrawal permissions are not supported.
- **TITAN AI CORE foundation**: engine registry/status, system state, audit logging, knowledge/learning records (SQLite).
- **Working analysis pipeline (tested)** using **LABELED SYNTHETIC** candles for research/testing and **Binance Public read-only** candles for live market analysis:
  - Multi-timeframe provider supports all 15 configured timeframes; the primary decision hierarchy is 1D/4H/1H/15M/5M. It supports labeled synthetic data and Binance Public klines (read-only, no API key). In-progress candles are excluded from public-data analysis.
  - Technical analysis (EMA 9/21/50/200, SMA, VWAP, Supertrend, Ichimoku, RSI, MACD, Stoch RSI, CCI, Bollinger, ATR, candle patterns, confirmed-pivot BOS/CHOCH, liquidity sweeps, FVG, order-block candidates, and market-regime heuristics).
  - Risk/cost engine (estimates; fee/slippage assumptions labeled; leverage capped; Spot has no leverage; Earn not treated as trade execution).
  - Decision engine (BUY/SELL/LONG/SHORT/WAIT) with rationale, confidence note, and data-source warning.
- **Backend API code** (Starlette runtime with service layer) for status, state, strategies, analysis, decisions, audit, knowledge, learning, and read-only Smart Scanner.
- **Frontend** (React + Vite, mobile-responsive PWA shell) that consumes `/api/*` and shows honest statuses (no fake data).
- **Supervised Demo/Shadow worker**: Master Start/Stop/Emergency Stop controls a joinable in-process worker for the selected Spot or USD-M Futures market. Automatic mode uses the Spot BUY scanner or the dedicated USDT-perpetual Futures LONG/SHORT scanner; existing positions are always cycled first for protection. It uses public read-only data and internal Shadow records only; it never sends Binance orders.
- **Smart Scanners**: bounded liquid Spot discovery and a separate active USDT-perpetual Futures discovery path; both analyze 1D/4H/1H/15M/5M with freshness/coverage checks, ranked results and explicit skipped-candidate reasons.
- **Backtesting**: six implemented strategy rules (trend, momentum, mean reversion, structure breakout, M5 scalping, and H1/H4 swing) are connected to causal next-candle-open simulation with fees/slippage and rolling Walk-Forward/OOS folds. Futures simulation additionally models funding, partial fills, and liquidation estimates. External signal callbacks are explicitly marked as not lookahead-verified unless generated from causal history prefixes.

## What remains incomplete or requires external configuration

- **Implemented but not externally verified:** authenticated Binance account/balance reads, Spot/Futures Testnet MARKET/LIMIT submission paths, order lookup/open-order reconciliation, durable idempotency, partial-fill persistence, and emergency-stop handling. The Spot lifecycle regression uses a deterministic fake adapter; no real Binance Testnet order was submitted.
- **Futures margin mode:** before every new Futures Testnet position/order, TITAN requests Binance `ISOLATED` margin for that symbol and fails closed if the exchange refuses. Binance's `-4046` response is treated as confirmation that the symbol is already isolated. Reduce-only close orders deliberately skip margin/leverage changes so an existing Cross position can still be closed safely. These paths are covered by deterministic unit tests but have not yet been exercised with user-provided Futures Testnet credentials; there is no independent post-change position-risk read-back yet.
- **Still deferred:** exchange-side cancel/modify, SL/TP/trailing orders, WebSocket execution stream, and fully verified external reconnect/resynchronization. The Futures Testnet opening path requests ISOLATED margin and applies the configured leverage before submitting a new position; reduce-only closes deliberately skip margin/leverage changes so an existing Cross position can still be closed. These controls have deterministic unit coverage but no user-credentialed exchange verification or independent post-change position-risk read-back yet. Demo/backtest margin and liquidation figures remain estimates. Live execution remains disabled and requires separate explicit approval.
- **Still partial:** knowledge-source verification/provenance; full continuous-learning integration into strategy parameters; liquidity/order-flow strategy depth (current order-flow evidence is recent aggregate-trade taker flow, not a full synchronized depth stream); complete on-chain/tokenomics due diligence; broad news coverage and economic-calendar/NLP analysis; exchange-exact Futures liquidation/funding behavior (the Demo worker uses conservative estimates, and funding payments use the latest mark rather than a historical funding-time mark); wider ML calibration/OOS validation; arbitrage execution; and full agent orchestration.
- **Research-only outputs:** performance analytics use the internal Demo/Shadow ledger; prediction tracking is a single mark-to-market observation, not realized PnL. The ML model is a baseline and cannot independently authorize trades.
- **External configuration:** Telegram requires a Bot Token and allowlisted Chat IDs in server environment variables. AI-provider features require provider keys. Public CoinGecko/RSS endpoints have coverage and rate-limit constraints.
- **Deployment:** production multi-process worker supervision, 24/7 monitoring, and Android APK packaging remain separate work. The current worker is managed inside one application process.

## Verification

Latest fully successful backend/frontend CI snapshot: `9aba1eedbd6ec4afbdf72c5fef012c188121f3df` (2026-11-11).

- Backend CI: **651 passed, 1 skipped, 2 warnings**; Python compilation succeeded.
- Frontend CI: **9 API tests passed**, Vite production build succeeded, and **1 runtime smoke test passed**.
- Regression coverage in that successful snapshot includes: exceptions after durable order creation (unknown outcome + emergency stop + no resubmission), Spot `long_spot` close-side mapping, invalid close-side rejection, long placeholder secret rejection, and project-root `.env` loading with process-environment precedence.
- A fresh 1,800-second offline 15-timeframe stability soak was started on that snapshot and must complete successfully before merge. The earlier soak on `a423024e680df778fc4e66ef079f00afcf35a46e` passed.
- Additional hardening commits after `9aba1ee` add local-AI redirect/proxy blocking, portable SQLite directory initialization, and release-archive content scanning. Their latest GitHub Actions attempts have failed before runner assignment (runner ID 0, no steps/logs), so these newer changes are **not yet CI-verified**. They must pass fresh CI and soak runs before merge.
- Exact-main-commit release packaging and the published-ZIP deep audit run after merge and must pass before release.

These CI/soak checks use offline or deterministic test data; they do not prove external exchange execution. No Binance Testnet order or Live order was submitted. The Futures Testnet workflow is a read-only authenticated preflight and has not been run with dedicated user-provided Futures Testnet credentials. The Spot lifecycle regression uses a deterministic fake adapter; it does not contact Binance.

Optional local AI: the code includes a loopback-only OpenAI-compatible adapter for a locally installed runtime such as Ollama or llama.cpp. It requires no hosted API key and has no cloud fallback. TITAN does not install the runtime or model; local inference has not yet been verified on Android/Termux.

See [Demo USD-M Futures worker operation and safety](docs/DEMO_FUTURES_WORKER.md), [the detailed Arabic implementation status](docs/IMPLEMENTATION_STATUS_2026-11-08_AR.md), and [the implementation update](docs/IMPLEMENTATION_UPDATE_2026-11-08_AR.md).

## Run (standard environment)
### Backend
From the project root:

```bash
python3 -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r backend/requirements.txt
cp .env.example .env
# Edit .env: replace owner@example.com and set a unique random TITAN_SECRET_KEY (32+ characters).
# The app loads this project-root .env automatically; process environment variables take precedence.
uvicorn app.main:app --app-dir backend --reload --host 0.0.0.0 --port 8000
```

Credential encryption remains disabled until a strong non-placeholder `TITAN_SECRET_KEY` is configured.

### Frontend
```bash
cd frontend
npm install
npm run dev
```
Vite proxies `/api` to `http://127.0.0.1:8000` by default.

## Safety rules
- Never commit `.env`, API keys, Telegram tokens, or secrets.
- Use Binance Demo/Testnet before any live environment; verify environment support.
- No auto demo→live. No withdrawal permissions.
- Do not present synthetic/test data as real market data.
- No profit guarantees.

## Reference and backup handling

The immutable reference ZIP is kept at the repository root, outside this project directory. The release workflow packages only this project tree and excludes the root reference ZIP, nested ZIPs, recovered/old material, runtime data, credentials, databases, and build caches. The reference archive remains unchanged in the repository.
