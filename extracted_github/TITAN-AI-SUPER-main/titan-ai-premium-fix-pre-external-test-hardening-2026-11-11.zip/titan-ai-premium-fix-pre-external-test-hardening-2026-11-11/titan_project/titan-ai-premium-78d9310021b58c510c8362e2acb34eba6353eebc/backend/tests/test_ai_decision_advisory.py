from types import SimpleNamespace

from app.integrations import ai_providers


def test_decision_advisory_is_inactive_without_enabled_provider(monkeypatch):
    monkeypatch.setattr(ai_providers, "list_configs", lambda db: [])
    result = ai_providers.evaluate_decision_advisory(object(), {"decision": {"action": "buy"}})
    assert result == {
        "status": "not_configured", "action_authority": "none",
        "decision_modified": False, "advisors": [], "advice_count": 0,
    }


def test_decision_advisory_includes_every_enabled_provider_regardless_of_task_tags(monkeypatch):
    configs = [
        SimpleNamespace(enabled=False, provider="disabled", model="off", tasks=["analysis"]),
        SimpleNamespace(enabled=True, provider="news-tagged", model="model-news", tasks=["news"]),
    ]
    monkeypatch.setattr(ai_providers, "list_configs", lambda db: configs)
    calls = []
    monkeypatch.setattr(
        ai_providers, "invoke_provider",
        lambda cfg, messages, task=None: (
            calls.append((cfg.provider, task))
            or ai_providers.ProviderResult(True, cfg.provider, cfg.model, text="Trading review")
        ),
    )
    monkeypatch.setattr(ai_providers, "record_usage", lambda *args: None)
    result = ai_providers.evaluate_decision_advisory(object(), {"decision": {"action": "wait"}})
    assert calls == [("news-tagged", "analysis")]
    assert result["advice_count"] == 1
    assert result["advisors"][0]["provider"] == "news-tagged"
    assert result["action_authority"] == "none"


def test_decision_advisory_uses_provider_fallback_and_never_grants_trade_authority(monkeypatch):
    first = SimpleNamespace(enabled=True, tasks=["analysis"], provider="openai", model="model-a")
    second = SimpleNamespace(enabled=True, tasks=["analysis"], provider="anthropic", model="model-b")
    monkeypatch.setattr(ai_providers, "list_configs", lambda db: [first, second])
    calls = []
    usage = []

    def fake_invoke(cfg, messages, task=None):
        calls.append((cfg.provider, task, messages))
        if cfg is first:
            return ai_providers.ProviderResult(False, cfg.provider, cfg.model, error="temporary_failure")
        return ai_providers.ProviderResult(True, cfg.provider, cfg.model, text="Review: setup aligns; monitor liquidity.")

    monkeypatch.setattr(ai_providers, "invoke_provider", fake_invoke)
    monkeypatch.setattr(ai_providers, "record_usage", lambda db, cfg, task, result: usage.append((cfg.provider, task, result.ok)))

    context = {
        "decision": {"action": "buy", "strategy": "momentum"},
        "independent_risk_result": {"ok": True, "quantity_estimate": 0.1},
        "system_state": {"emergency_stop": False},
    }
    result = ai_providers.evaluate_decision_advisory(object(), context)

    assert [call[0] for call in calls] == ["openai", "anthropic"]
    assert all(call[1] == "analysis" for call in calls)
    assert len(usage) == 2
    assert result["status"] == "completed"
    assert result["advice_count"] == 1
    assert result["attempted_count"] == 2
    assert result["advisors"][0]["provider"] == "openai"
    assert result["advisors"][0]["status"] == "unavailable"
    assert result["advisors"][1]["provider"] == "anthropic"
    assert result["advisors"][1]["status"] == "completed"
    assert result["action_authority"] == "none"
    assert result["decision_modified"] is False
    assert result["final_decision_owner"] == "TITAN"
    assert context["decision"]["action"] == "buy"
