from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models import db as dbmod
from app.models.entities import SystemState
from app.services.core_service import core_service
from app.services.binance_trading_worker import _entry_notional_cap, _open_signal
from app.services.binance_execution import binance_execution_service


def test_live_spot_entry_is_capped_at_twenty_usdt_notional():
    assert _entry_notional_cap("live", "spot", 1, 500) == 20 / 1.03


def test_live_futures_entry_notional_scales_with_titan_leverage_but_margin_stays_twenty():
    notional = _entry_notional_cap("live", "futures", 5, 500)
    assert notional == 100 / 1.03
    assert notional * 1.03 / 5 <= 20 + 1e-9


def test_live_futures_entry_respects_lower_remaining_portfolio_exposure():
    assert _entry_notional_cap("live", "futures", 10, 75) == 75
    assert _entry_notional_cap("live", "futures", 10, 75) * 1.03 / 10 <= 20


def test_demo_caps_remain_unchanged():
    assert _entry_notional_cap("demo", "spot", 1, 500) == 80
    assert _entry_notional_cap("testnet", "futures", 10, 1000) == 800


def test_paused_trading_blocks_new_entries_without_touching_exchange():
    _open_signal(
        None, None, {"symbol": "BTCUSDT", "action": "buy", "confidence": 0.99},
        "live", "spot", 100.0, 100.0, {"trading_paused": True}, 0.0, 0,
    )


def test_trading_pause_is_persisted_and_does_not_set_emergency_stop(tmp_path, monkeypatch):
    engine = create_engine(
        f"sqlite:///{tmp_path / 'trading_pause.db'}",
        connect_args={"check_same_thread": False},
        future=True,
    )
    factory = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
    monkeypatch.setattr(dbmod, "engine", engine)
    monkeypatch.setattr(dbmod, "SessionLocal", factory)
    monkeypatch.setattr(dbmod, "init_db", lambda: dbmod.Base.metadata.create_all(bind=engine))
    dbmod.init_db()
    db = factory()
    try:
        core_service.ensure_bootstrap(db)
        paused = core_service.set_trading_paused(db, True)
        state = db.get(SystemState, 1)
        assert paused["state"]["trading_paused"] is True
        assert state.emergency_stop is False
        assert state.bot_run_state == "stopped"
        resumed = core_service.set_trading_paused(db, False)
        assert resumed["state"]["trading_paused"] is False
        assert state.emergency_stop is False
    finally:
        db.close()
        engine.dispose()



def _execution_test_db(tmp_path):
    engine = create_engine(
        f"sqlite:///{tmp_path / 'live_execution_guard.db'}",
        connect_args={"check_same_thread": False},
        future=True,
    )
    dbmod.Base.metadata.create_all(bind=engine)
    factory = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
    return engine, factory()


def test_execution_boundary_rejects_live_futures_margin_over_twenty(tmp_path):
    engine, db = _execution_test_db(tmp_path)
    try:
        db.add(SystemState(
            id=1, environment_mode="live", account_target="live", market_type="futures",
            bot_run_state="running", autonomous_enabled=True, emergency_stop=False,
            risk_limits={},
        ))
        db.commit()
        result = binance_execution_service.execute_order(
            db, symbol="BTCUSDT", side="BUY", order_type="MARKET",
            quantity=1.0, price=None, leverage=5.0, reduce_only=False,
            idempotency_key="live-margin-cap-test-001", live_worker_ready=True,
            order_metadata={"intent": "open", "reference_price": 100.0},
        )
        assert result["error"] == "live_per_trade_margin_cap_exceeded"
        assert result["sent_to_exchange"] is False
    finally:
        db.close()
        engine.dispose()


def test_execution_boundary_blocks_new_entries_while_trading_is_paused(tmp_path):
    engine, db = _execution_test_db(tmp_path)
    try:
        db.add(SystemState(
            id=1, environment_mode="demo", account_target="testnet", market_type="futures",
            bot_run_state="running", autonomous_enabled=True, emergency_stop=False,
            risk_limits={"trading_paused": True},
        ))
        db.commit()
        result = binance_execution_service.execute_order(
            db, symbol="BTCUSDT", side="BUY", order_type="MARKET",
            quantity=0.001, price=100.0, leverage=2.0, reduce_only=False,
            idempotency_key="paused-entry-test-001", live_worker_ready=False,
            order_metadata={"intent": "open", "reference_price": 100.0},
        )
        assert result["error"] == "new_trade_entries_paused"
        assert result["sent_to_exchange"] is False
    finally:
        db.close()
        engine.dispose()


def test_worker_daily_loss_cap_uses_seven_percent_default():
    from app.services.binance_trading_worker import _daily_loss_cap_usdt
    assert _daily_loss_cap_usdt(1_000.0, {}) == 70.0


def test_worker_daily_loss_cap_never_accepts_configured_percentage_above_seven():
    from app.services.binance_trading_worker import _daily_loss_cap_usdt
    assert _daily_loss_cap_usdt(1_000.0, {"max_daily_loss_cap": 0.10}) == 70.0


def test_worker_daily_loss_cap_respects_stricter_configured_percentage_and_cash_limit():
    from app.services.binance_trading_worker import _daily_loss_cap_usdt
    assert _daily_loss_cap_usdt(1_000.0, {"max_daily_loss_cap": 0.05}) == 50.0
    assert _daily_loss_cap_usdt(1_000.0, {"max_daily_loss_cap": 0.07, "max_daily_loss_usdt": 40}) == 40.0


def test_worker_daily_loss_cap_fails_closed_for_invalid_cash_limit():
    from app.services.binance_trading_worker import _daily_loss_cap_usdt
    assert _daily_loss_cap_usdt(1_000.0, {"max_daily_loss_usdt": 0}) == 0.0


def test_emergency_stop_blocks_new_testnet_entries_but_allows_position_exit(tmp_path, monkeypatch):
    from types import SimpleNamespace

    engine, db = _execution_test_db(tmp_path)
    try:
        db.add(SystemState(
            id=1, environment_mode="testnet", account_target="testnet", market_type="spot",
            bot_run_state="stopped", autonomous_enabled=False, emergency_stop=True,
            risk_limits={},
        ))
        db.commit()

        blocked = binance_execution_service.execute_order(
            db, symbol="BTCUSDT", side="BUY", order_type="MARKET",
            quantity=0.001, price=100.0, leverage=1.0, reduce_only=False,
            idempotency_key="emergency-new-entry-01", live_worker_ready=False,
            order_metadata={"intent": "open", "reference_price": 100.0},
        )
        assert blocked["error"] == "master_worker_not_running"
        assert blocked["sent_to_exchange"] is False

        class FakeAdapter:
            def reconcile(self, local_open_orders):
                return {"ok": True}
            def place_order(self, **kwargs):
                return {"sent_to_exchange": True, "response": {
                    "status": "FILLED", "orderId": 12345,
                    "clientOrderId": kwargs["idempotency_key"],
                    "executedQty": "0.001", "avgPrice": "100",
                    "cummulativeQuoteQty": "0.1",
                }}

        fake = FakeAdapter()
        monkeypatch.setattr(
            binance_execution_service, "adapter_for",
            lambda state, live_worker_ready=False: fake,
        )
        monkeypatch.setattr(
            binance_execution_service, "preflight",
            lambda db, live_worker_ready=False, allow_emergency_exit=False: {
                "ok": True, "ready": allow_emergency_exit,
            },
        )
        closing = binance_execution_service.execute_order(
            db, symbol="BTCUSDT", side="SELL", order_type="MARKET",
            quantity=0.001, price=100.0, leverage=1.0, reduce_only=False,
            idempotency_key="emergency-close-order-01", live_worker_ready=False,
            order_metadata={"intent": "close", "position_id": 1},
        )
        assert closing["ok"] is True
        assert closing["sent_to_exchange"] is True
        assert closing["status"] == "filled"
    finally:
        db.close()
        engine.dispose()


def test_execution_partial_fill_is_durably_recorded_and_duplicate_key_never_resubmits(tmp_path, monkeypatch):
    from app.models.entities import OrderRecord
    engine, db = _execution_test_db(tmp_path)
    calls = {"place": 0}

    class FakeAdapter:
        def status(self):
            return {"configured": True, "connected": True}
        def reconcile(self, local_open_orders):
            return {"ok": True}
        def place_order(self, **kwargs):
            calls["place"] += 1
            return {"sent_to_exchange": True, "response": {
                "status": "PARTIALLY_FILLED", "orderId": 77,
                "clientOrderId": "titan-partial-01", "executedQty": "0.0004",
                "avgPrice": "50000",
            }}

    try:
        db.add(SystemState(
            id=1, environment_mode="testnet", account_target="testnet", market_type="spot",
            bot_run_state="running", autonomous_enabled=True, emergency_stop=False,
            risk_limits={},
        ))
        db.commit()
        monkeypatch.setattr(binance_execution_service, "adapter_for", lambda *a, **k: FakeAdapter())
        monkeypatch.setattr(binance_execution_service, "preflight", lambda *a, **k: {"ready": True})
        args = dict(symbol="BTCUSDT", side="BUY", order_type="MARKET", quantity=0.001,
                    price=50000, leverage=1, reduce_only=False,
                    idempotency_key="partial-fill-idempotency-01", live_worker_ready=False,
                    order_metadata={"intent": "open", "reference_price": 50000})
        first = binance_execution_service.execute_order(db, **args)
        assert first["sent_to_exchange"] is True
        assert first["status"] == "partially_filled"
        order = db.get(OrderRecord, first["order_id"])
        assert order.filled_quantity == 0.0004
        second = binance_execution_service.execute_order(db, **args)
        assert second["duplicate"] is True
        assert calls["place"] == 1
    finally:
        db.close()
        engine.dispose()


def test_uncertain_execution_outcome_latches_emergency_stop_and_never_resubmits(tmp_path, monkeypatch):
    from app.models.entities import OrderRecord
    engine, db = _execution_test_db(tmp_path)
    calls = {"place": 0}

    class FakeAdapter:
        def status(self):
            return {"configured": True, "connected": True}
        def reconcile(self, local_open_orders):
            return {"ok": True}
        def place_order(self, **kwargs):
            calls["place"] += 1
            return {"sent_to_exchange": False, "error": "timeout waiting for exchange response"}

    try:
        state = SystemState(
            id=1, environment_mode="testnet", account_target="testnet", market_type="spot",
            bot_run_state="running", autonomous_enabled=True, emergency_stop=False,
            risk_limits={},
        )
        db.add(state)
        db.commit()
        monkeypatch.setattr(binance_execution_service, "adapter_for", lambda *a, **k: FakeAdapter())
        monkeypatch.setattr(binance_execution_service, "preflight", lambda *a, **k: {"ready": True})
        args = dict(symbol="BTCUSDT", side="BUY", order_type="MARKET", quantity=0.001,
                    price=50000, leverage=1, reduce_only=False,
                    idempotency_key="uncertain-idempotency-key-01", live_worker_ready=False,
                    order_metadata={"intent": "open", "reference_price": 50000})
        first = binance_execution_service.execute_order(db, **args)
        db.refresh(state)
        assert first["status"] == "unknown"
        assert state.emergency_stop is True
        assert state.bot_run_state == "stopped"
        second = binance_execution_service.execute_order(db, **args)
        assert second["duplicate"] is True
        assert second["sent_to_exchange"] is False
        assert calls["place"] == 1
        recorded = db.get(OrderRecord, first["order_id"])
        assert recorded.status == "unknown"
    finally:
        db.close()
        engine.dispose()


def test_execution_exception_after_durable_order_record_latches_unknown_and_never_resubmits(tmp_path, monkeypatch):
    from app.models.entities import OrderRecord
    engine, db = _execution_test_db(tmp_path)
    calls = {"place": 0}

    class RaisingAdapter:
        def status(self):
            return {"configured": True, "connected": True}
        def reconcile(self, local_open_orders):
            return {"ok": True}
        def place_order(self, **kwargs):
            calls["place"] += 1
            raise RuntimeError("simulated socket read timed out after request transmission")

    try:
        state = SystemState(
            id=1, environment_mode="testnet", account_target="testnet", market_type="spot",
            bot_run_state="running", autonomous_enabled=True, emergency_stop=False,
            risk_limits={},
        )
        db.add(state)
        db.commit()
        monkeypatch.setattr(binance_execution_service, "adapter_for", lambda *a, **k: RaisingAdapter())
        monkeypatch.setattr(binance_execution_service, "preflight", lambda *a, **k: {"ready": True})
        args = dict(
            symbol="BTCUSDT", side="BUY", order_type="MARKET", quantity=0.001,
            price=50000, leverage=1, reduce_only=False,
            idempotency_key="raised-exception-idempotency-01", live_worker_ready=False,
            order_metadata={"intent": "open", "reference_price": 50000},
        )
        first = binance_execution_service.execute_order(db, **args)
        db.refresh(state)
        assert first["status"] == "unknown"
        assert first["error"] == "binance_execution_outcome_uncertain"
        assert state.emergency_stop is True
        assert state.bot_run_state == "stopped"
        recorded = db.get(OrderRecord, first["order_id"])
        assert recorded.status == "unknown"
        second = binance_execution_service.execute_order(db, **args)
        assert second["duplicate"] is True
        assert second["sent_to_exchange"] is False
        assert calls["place"] == 1
    finally:
        db.close()
        engine.dispose()
