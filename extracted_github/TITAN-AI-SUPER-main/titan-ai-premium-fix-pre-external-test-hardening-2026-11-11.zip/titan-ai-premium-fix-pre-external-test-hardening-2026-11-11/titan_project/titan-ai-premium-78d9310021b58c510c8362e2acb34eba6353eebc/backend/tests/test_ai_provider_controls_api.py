from __future__ import annotations

import asyncio
import json
from types import SimpleNamespace

from app import star_app


class RequestStub:
    def __init__(self, payload=None, provider_id=1, query=None):
        self._payload = payload or {}
        self.path_params = {"provider_id": provider_id}
        self.query_params = query or {}

    async def body(self):
        return json.dumps(self._payload).encode("utf-8")


class QueryResult:
    def __init__(self, rows):
        self.rows = rows

    def scalars(self):
        return self

    def all(self):
        return self.rows


class FakeDB:
    def __init__(self, row=None, query_rows=None):
        self.row = row
        self.query_rows = list(query_rows or [])
        self.query_count = 0
        self.commits = 0
        self.closed = False
        self.added = []

    def get(self, model, key):
        return self.row

    def execute(self, statement):
        rows = self.query_rows[self.query_count] if self.query_count < len(self.query_rows) else []
        self.query_count += 1
        return QueryResult(rows)

    def add(self, row):
        self.added.append(row)

    def commit(self):
        self.commits += 1

    def close(self):
        self.closed = True


def test_ai_provider_control_toggles_only_the_selected_provider(monkeypatch):
    cfg = SimpleNamespace(id=1, enabled=True, provider="openai", model="test-model", name="primary")
    db = FakeDB(cfg)
    monkeypatch.setattr(star_app, "db_sess", lambda: db)
    monkeypatch.setattr(star_app, "require_user", lambda request, session: (SimpleNamespace(email="user"), None))
    monkeypatch.setattr(star_app, "provider_status", lambda session: {"status": "all_disabled"})
    monkeypatch.setattr(star_app, "log_event", lambda *args, **kwargs: None)

    response = asyncio.run(star_app.ai_provider_control(RequestStub({"enabled": False})))
    assert response.status_code == 200
    assert cfg.enabled is False
    assert db.commits == 1
    assert db.closed is True
    assert b'"enabled":false' in response.body


def test_ai_provider_control_rejects_string_boolean(monkeypatch):
    cfg = SimpleNamespace(id=1, enabled=True)
    db = FakeDB(cfg)
    monkeypatch.setattr(star_app, "db_sess", lambda: db)
    monkeypatch.setattr(star_app, "require_user", lambda request, session: (SimpleNamespace(email="user"), None))

    response = asyncio.run(star_app.ai_provider_control(RequestStub({"enabled": "false"})))
    assert response.status_code == 400
    assert cfg.enabled is True
    assert db.commits == 0


def test_live_credentials_are_saved_encrypted_without_exchange_execution(monkeypatch):
    captured = []
    monkeypatch.setattr(star_app, "_binance_auth_error", lambda request: None)
    monkeypatch.setattr(star_app, "save_live_credentials",
                        lambda key, secret, market: captured.append((key, secret, market)) or {
                            "ok": True, "saved": True, "market": market,
                        })
    response = asyncio.run(star_app.binance_live_save(RequestStub({
        "market": "futures", "api_key": "test-live-key", "api_secret": "test-live-secret",
    })))
    assert response.status_code == 200
    assert captured == [("test-live-key", "test-live-secret", "futures")]
    assert b"test-live-secret" not in response.body
    assert b"No connection test or order was made" in response.body


def test_live_credentials_reject_unsupported_market_before_storage(monkeypatch):
    called = []
    monkeypatch.setattr(star_app, "_binance_auth_error", lambda request: None)
    monkeypatch.setattr(star_app, "save_live_credentials",
                        lambda *args: called.append(args) or {"ok": True})
    response = asyncio.run(star_app.binance_live_save(RequestStub({
        "market": "margin", "api_key": "key", "api_secret": "secret",
    })))
    assert response.status_code == 400
    assert called == []


def test_chat_reports_include_saved_external_ai_advisory_without_provider_secrets(monkeypatch):
    advisory = {
        "status": "completed",
        "advisors": [{
            "provider": "openai", "model": "gpt-test",
            "status": "completed", "advisory_text": "15m RSI supports caution",
            "action_authority": "none",
        }],
        "action_authority": "none",
        "decision_modified": False,
    }
    decision = SimpleNamespace(
        id=5, created_at=None, symbol="BTC/USDT", action="wait", strategy="test",
        confidence=0.5, entry_price=None, stop_loss=None, take_profit=None,
        leverage=1, rationale="test rationale", data_source="synthetic",
        environment_mode="demo", market_type="spot",
        indicators={"ai_evaluation": advisory},
    )
    db = FakeDB(query_rows=[[decision], [], [], [], []])
    monkeypatch.setattr(star_app, "db_sess", lambda: db)
    monkeypatch.setattr(star_app, "require_user", lambda request, session: (SimpleNamespace(email="user"), None))

    response = asyncio.run(star_app.chat_reports(RequestStub(query={"limit": "5"})))
    assert response.status_code == 200
    payload = json.loads(response.body)
    assert payload["decisions"][0]["ai_evaluation"] == advisory
    assert payload["decisions"][0]["ai_evaluation"]["action_authority"] == "none"
    assert db.closed is True
