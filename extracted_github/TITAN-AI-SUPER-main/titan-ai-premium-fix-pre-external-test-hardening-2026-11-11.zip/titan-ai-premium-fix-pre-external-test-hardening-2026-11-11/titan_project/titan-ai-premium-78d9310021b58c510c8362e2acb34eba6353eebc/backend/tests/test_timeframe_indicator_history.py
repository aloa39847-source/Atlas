from datetime import datetime, timezone

from app.core.enums import Timeframe
from app.engines.market_data import MarketDataEngine
from app.engines.technical import TechnicalAnalysisEngine, _vwap


def test_all_fifteen_timeframes_generate_synthetic_candles_and_ema200_history():
    timeframes = list(Timeframe)
    assert len(timeframes) == 15
    batches = MarketDataEngine().get_multi_timeframe(
        "BTC/USDT", limit=250, seed=7, timeframes=timeframes,
    )
    assert len(batches) == 15
    engine = TechnicalAnalysisEngine()
    for timeframe, batch in batches.items():
        assert len(batch.df) == 250
        analysis = engine.analyze(batch.df, timeframe)
        assert analysis.indicators["ema200"] is not None, timeframe.value


def test_multi_timeframe_fetch_defaults_to_all_fifteen_frames(monkeypatch):
    engine = MarketDataEngine()
    calls = []

    def fake_get_public_candles(symbol, timeframe, *, limit, market_type):
        calls.append((timeframe, limit, market_type))
        return (symbol, timeframe, limit, market_type)

    monkeypatch.setattr(engine, "get_public_candles", fake_get_public_candles)
    core = engine.get_public_multi_timeframe("BTCUSDT")
    assert len(core) == 15
    assert all(row[2] == 250 for row in core.values())

    calls.clear()
    full = engine.get_public_multi_timeframe(
        "BTCUSDT", timeframes=list(Timeframe), market_type="futures",
    )
    assert len(full) == 15
    assert len(calls) == 15
    assert all(row[2] == 250 and row[3] == "futures" for row in full.values())


def test_vwap_resets_at_utc_session_boundary_when_timestamps_are_available():
    values = _vwap(
        [10.0, 20.0], [10.0, 20.0], [10.0, 20.0], [1.0, 1.0],
        ["2026-11-09T23:59:00Z", "2026-11-10T00:00:00Z"],
    )
    assert values == [10.0, 20.0]


def test_vwap_uses_one_batch_anchor_without_timestamps():
    values = _vwap([10.0, 20.0], [10.0, 20.0], [10.0, 20.0], [1.0, 1.0])
    assert values == [10.0, 15.0]


def test_vwap_accepts_datetime_and_millisecond_timestamps():
    values = _vwap(
        [10.0, 20.0], [10.0, 20.0], [10.0, 20.0], [1.0, 1.0],
        [
            datetime(2026, 11, 9, 23, 59, tzinfo=timezone.utc),
            1794268800000,
        ],
    )
    assert values == [10.0, 20.0]
