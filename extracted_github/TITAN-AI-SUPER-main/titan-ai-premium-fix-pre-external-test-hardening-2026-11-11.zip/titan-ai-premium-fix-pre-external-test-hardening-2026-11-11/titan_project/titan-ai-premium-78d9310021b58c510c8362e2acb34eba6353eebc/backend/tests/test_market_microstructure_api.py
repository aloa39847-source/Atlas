import asyncio
import json
from types import SimpleNamespace

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app import star_app
from app.models import db as dbmod
from app.models.entities import EngineState
from app.services.core_service import core_service


def test_bootstrap_refreshes_partial_engine_maturity_statuses(tmp_path, monkeypatch):
    engine = create_engine(f"sqlite:///{tmp_path / 'engine_registry.db'}", future=True)
    dbmod.Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
    db = factory()
    try:
        db.add(EngineState(engine_key="backtesting", name="Backtesting Engine", status="not_implemented"))
        db.add(EngineState(engine_key="liquidity_analysis", name="Liquidity Analysis Engine", status="needs_external_service"))
        db.commit()
        core_service.ensure_bootstrap(db)
        assert db.get(EngineState, 1) is not None
        backtest = db.query(EngineState).filter_by(engine_key="backtesting").one()
        liquidity = db.query(EngineState).filter_by(engine_key="liquidity_analysis").one()
        order_flow = db.query(EngineState).filter_by(engine_key="order_flow").one()
        assert backtest.status == "implemented_partial"
        assert liquidity.status == "implemented_partial"
        assert order_flow.status == "implemented_partial"
    finally:
        db.close()
        engine.dispose()


def test_market_microstructure_api_returns_read_only_public_metrics(monkeypatch):
    class FakeDB:
        def close(self): pass

    monkeypatch.setattr(star_app, "db_sess", lambda: FakeDB())
    monkeypatch.setattr(star_app, "require_user", lambda request, db: (None, None))
    monkeypatch.setattr(
        "app.engines.liquidity.LiquidityAnalysisEngine.fetch_and_analyze",
        lambda self, symbol, limit, market_type="spot": {"ok": True, "symbol": symbol, "market_type": market_type, "spread_percent": 0.02},
    )
    monkeypatch.setattr(
        "app.engines.order_flow.OrderFlowEngine.fetch_and_analyze",
        lambda self, symbol, limit, market_type="spot": {"ok": True, "symbol": symbol, "market_type": market_type, "taker_flow_imbalance": 0.1},
    )
    request = SimpleNamespace(query_params={"symbol": "BTC/USDT"})
    response = asyncio.run(star_app.market_microstructure(request))
    data = json.loads(response.body.decode("utf-8"))
    assert response.status_code == 200
    assert data["ok"] is True
    assert data["source"] == "binance_public_read_only"
    assert data["execution"] == "none"


def test_market_microstructure_api_selects_futures_public_market(monkeypatch):
    class FakeDB:
        def close(self): pass

    seen = []
    monkeypatch.setattr(star_app, "db_sess", lambda: FakeDB())
    monkeypatch.setattr(star_app, "require_user", lambda request, db: ({"id": 1}, None))
    monkeypatch.setattr(
        "app.engines.liquidity.LiquidityAnalysisEngine.fetch_and_analyze",
        lambda self, symbol, limit, market_type="spot": seen.append(("liquidity", market_type)) or {"ok": True, "symbol": symbol},
    )
    monkeypatch.setattr(
        "app.engines.order_flow.OrderFlowEngine.fetch_and_analyze",
        lambda self, symbol, limit, market_type="spot": seen.append(("order_flow", market_type)) or {"ok": True, "symbol": symbol},
    )
    request = SimpleNamespace(query_params={"symbol": "BTC/USDT", "market_type": "futures"})
    response = asyncio.run(star_app.market_microstructure(request))
    data = json.loads(response.body.decode("utf-8"))
    assert response.status_code == 200
    assert data["market_type"] == "futures"
    assert data["source"] == "binance_futures_public_read_only"
    assert seen == [("liquidity", "futures"), ("order_flow", "futures")]
