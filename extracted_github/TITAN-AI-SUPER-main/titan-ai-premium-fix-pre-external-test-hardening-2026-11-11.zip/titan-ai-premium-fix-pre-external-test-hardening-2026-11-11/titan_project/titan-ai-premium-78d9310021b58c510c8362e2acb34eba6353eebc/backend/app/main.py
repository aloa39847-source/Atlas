"""ASGI entrypoint.

Primary runtime in this environment: Starlette app (compatible with Python 3.14 here).
The FastAPI route implementation exists in app.api.routes for reference/standard envs,
but FastAPI 0.99 + Pydantic v1 has OpenAPI import issues on Python 3.14 in this runtime.
"""
from __future__ import annotations

from .star_app import app, create_star_app

__all__ = ["app", "create_star_app"]
