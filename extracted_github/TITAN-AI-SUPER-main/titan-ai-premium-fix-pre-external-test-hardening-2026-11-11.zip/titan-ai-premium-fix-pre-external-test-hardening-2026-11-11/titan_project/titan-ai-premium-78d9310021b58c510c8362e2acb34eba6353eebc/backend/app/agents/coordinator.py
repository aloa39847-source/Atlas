"""Multi-Agent Coordinator - Evidence-based aggregation"""
from __future__ import annotations

from typing import Any
from .specialists import TechnicalAgent, LiquidityAgent, RiskAgent, NewsAgent, StrategyAgent
from .base import AgentVote


class MultiAgentCoordinator:
    def __init__(self):
        self.agents = [
            TechnicalAgent(),
            LiquidityAgent(),
            RiskAgent(),
            NewsAgent(),
            StrategyAgent(),
        ]

    def deliberate(self, context: dict[str, Any]) -> dict[str, Any]:
        votes: list[AgentVote] = []
        for agent in self.agents:
            try:
                votes.append(agent.analyze(context))
            except Exception as e:
                votes.append(AgentVote(
                    agent_name=agent.name,
                    role=agent.role,
                    bias="neutral",
                    confidence=0.0,
                    evidence=[f"error:{str(e)[:50]}"],
                    reasoning="Agent error",
                    risk_notes=["agent_failed"],
                ))
        
        # Evidence-based aggregation - not random voting
        bull_score = 0.0
        bear_score = 0.0
        evidence_all = []
        vetoes = []
        for v in votes:
            evidence_all.extend(v.evidence)
            if v.veto:
                vetoes.append(v.agent_name)
            if v.bias == "bullish":
                bull_score += v.confidence * (1.0 + 0.1 * len(v.evidence))
            elif v.bias == "bearish":
                bear_score += v.confidence * (1.0 + 0.1 * len(v.evidence))
        
        if vetoes:
            return {
                "consensus": "vetoed",
                "vetoed_by": vetoes,
                "votes": [{"agent": v.agent_name, "role": v.role, "bias": v.bias, "confidence": v.confidence} for v in votes],
                "evidence": evidence_all,
                "aggregation_method": "evidence_weighted_with_veto",
            }
        
        if bull_score > bear_score * 1.2:
            consensus = "bullish"
        elif bear_score > bull_score * 1.2:
            consensus = "bearish"
        else:
            consensus = "neutral"
        
        return {
            "consensus": consensus,
            "bull_score": round(bull_score, 3),
            "bear_score": round(bear_score, 3),
            "votes": [{"agent": v.agent_name, "role": v.role, "bias": v.bias, "confidence": v.confidence, "reasoning": v.reasoning} for v in votes],
            "evidence": evidence_all,
            "aggregation_method": "evidence_weighted_no_random_voting",
        }
