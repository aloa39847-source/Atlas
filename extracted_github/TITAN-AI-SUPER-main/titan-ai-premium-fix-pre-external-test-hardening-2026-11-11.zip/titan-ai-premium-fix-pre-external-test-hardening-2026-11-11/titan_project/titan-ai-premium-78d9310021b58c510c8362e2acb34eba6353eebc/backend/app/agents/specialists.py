"""Specialized Agents for TITAN Multi-Agent System"""
from __future__ import annotations

from typing import Any
from .base import BaseAgent, AgentVote


class TechnicalAgent(BaseAgent):
    def __init__(self):
        super().__init__("technical_agent", "Technical Analysis Specialist")

    def analyze(self, context: dict[str, Any]) -> AgentVote:
        bias = context.get("bias", "neutral")
        evidence = context.get("evidence", [])[:5]
        return AgentVote(
            agent_name=self.name,
            role=self.role,
            bias=bias,
            confidence=0.7 if bias != "neutral" else 0.3,
            evidence=[f"ta:{e}" for e in evidence],
            reasoning="Technical structure analysis across multiple timeframes",
            risk_notes=[],
        )


class LiquidityAgent(BaseAgent):
    def __init__(self):
        super().__init__("liquidity_agent", "Liquidity & Order Flow Specialist")

    def analyze(self, context: dict[str, Any]) -> AgentVote:
        return AgentVote(
            agent_name=self.name,
            role=self.role,
            bias="neutral",
            confidence=0.5,
            evidence=["liquidity:zones_partial"],
            reasoning="Liquidity analysis (public data only when available)",
            risk_notes=["liquidity_data_limited_without_full_orderbook"],
        )


class RiskAgent(BaseAgent):
    def __init__(self):
        super().__init__("risk_agent", "Risk Management Specialist")

    def analyze(self, context: dict[str, Any]) -> AgentVote:
        return AgentVote(
            agent_name=self.name,
            role=self.role,
            bias="neutral",
            confidence=0.8,
            evidence=["risk:pretrade_checks_enforced"],
            reasoning="Risk-first evaluation - can veto unsafe setups",
            risk_notes=["enforce_position_sizing", "respect_correlation"],
            veto=False,
        )


class NewsAgent(BaseAgent):
    def __init__(self):
        super().__init__("news_agent", "News & Fundamental Specialist")

    def analyze(self, context: dict[str, Any]) -> AgentVote:
        return AgentVote(
            agent_name=self.name,
            role=self.role,
            bias="neutral",
            confidence=0.4,
            evidence=["news:external_sources_required"],
            reasoning="Fundamental/news analysis requires trusted external sources",
            risk_notes=["avoid_trading_on_unverified_news"],
        )


class StrategyAgent(BaseAgent):
    def __init__(self):
        super().__init__("strategy_agent", "Strategy Selection Specialist")

    def analyze(self, context: dict[str, Any]) -> AgentVote:
        strategy = context.get("strategy", "unknown")
        return AgentVote(
            agent_name=self.name,
            role=self.role,
            bias=context.get("bias", "neutral"),
            confidence=0.6,
            evidence=[f"strategy:{strategy}"],
            reasoning="Strategy fit assessment based on market conditions",
            risk_notes=[],
        )
