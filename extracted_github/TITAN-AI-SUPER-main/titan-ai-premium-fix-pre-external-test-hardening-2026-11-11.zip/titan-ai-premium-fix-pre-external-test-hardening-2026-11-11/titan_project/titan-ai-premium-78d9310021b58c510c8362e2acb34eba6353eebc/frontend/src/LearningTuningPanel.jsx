import React, { useState } from 'react'
import { api } from './api'

export default function LearningTuningPanel() {
  const [strategyKey, setStrategyKey] = useState('trend_following_ema')
  const [currentParams, setCurrentParams] = useState('{"fast":9,"slow":21}')
  const [proposedParams, setProposedParams] = useState('{"fast":10,"slow":24}')
  const [metricsBefore, setMetricsBefore] = useState('{"expectancy":0,"max_drawdown":0}')
  const [rationale, setRationale] = useState('')
  const [proposalId, setProposalId] = useState('')
  const [baselineFolds, setBaselineFolds] = useState('[]')
  const [candidateFolds, setCandidateFolds] = useState('[]')
  const [result, setResult] = useState(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const parse = (value, label) => {
    try { return JSON.parse(value) } catch { throw new Error('صيغة JSON غير صحيحة: ' + label) }
  }

  async function createProposal() {
    setBusy(true); setError(''); setResult(null)
    try {
      const response = await api.strategyProposalCreate({
        strategy_key: strategyKey, current_params: parse(currentParams, 'الإعدادات الحالية'),
        proposed_params: parse(proposedParams, 'الإعدادات المقترحة'),
        metrics_before: parse(metricsBefore, 'المؤشرات الأساسية'), rationale,
      })
      setProposalId(String(response.proposal_id))
      setResult(response)
    } catch (e) { setError(e.message || 'تعذر إنشاء مقترح التعلم') }
    finally { setBusy(false) }
  }

  async function validate() {
    setBusy(true); setError(''); setResult(null)
    try {
      const response = await api.strategyProposalWalkForward({
        proposal_id: Number(proposalId),
        baseline_folds: parse(baselineFolds, 'Baseline folds'),
        candidate_folds: parse(candidateFolds, 'Candidate folds'),
        min_folds: 3, min_samples_per_fold: 30,
      })
      setResult(response)
    } catch (e) { setError(e.message || 'فشل اختبار Walk-Forward') }
    finally { setBusy(false) }
  }

  async function applyPaper() {
    setBusy(true); setError('')
    try {
      const response = await api.strategyProposalApplyPaper({ proposal_id: Number(proposalId), explicit_approval: true })
      setResult(response)
    } catch (e) { setError(e.message || 'تعذر اعتماد نسخة Paper') }
    finally { setBusy(false) }
  }

  return <div className="card" style={{marginTop:14}}>
    <h3>مختبر تحسين الاستراتيجية — Walk-Forward</h3>
    <p className="muted">ينشئ مقترحاً فقط. يجب إدخال نتائج طيات تاريخية مستقلة ومغلقة؛ 3 طيات على الأقل و30 صفقة بكل طية، مع تحسن طية الاختبار الأخيرة وعدم تدهور السحب. لا تعديل تلقائي على Live.</p>
    <div className="row">
      <div style={{flex:1,minWidth:180}}><label>الاستراتيجية</label><select value={strategyKey} onChange={e=>setStrategyKey(e.target.value)}><option value="trend_following_ema">Trend Following EMA</option><option value="momentum_macd_rsi">Momentum MACD/RSI</option><option value="mean_reversion_bbands">Mean Reversion</option><option value="breakout_structure">Breakout Structure</option><option value="scalping_m5">Scalping M5</option><option value="swing_h1_h4">Swing H1/H4</option></select></div>
      <div style={{flex:1,minWidth:160}}><label>رقم المقترح</label><input type="number" min="1" value={proposalId} onChange={e=>setProposalId(e.target.value)} placeholder="يظهر بعد الإنشاء"/></div>
    </div>
    <label>الإعدادات الحالية JSON</label><textarea rows={2} value={currentParams} onChange={e=>setCurrentParams(e.target.value)}/>
    <label>الإعدادات المرشحة JSON</label><textarea rows={2} value={proposedParams} onChange={e=>setProposedParams(e.target.value)}/>
    <label>المؤشرات الأساسية JSON</label><textarea rows={2} value={metricsBefore} onChange={e=>setMetricsBefore(e.target.value)}/>
    <label>مبرر المقترح</label><input value={rationale} onChange={e=>setRationale(e.target.value)} placeholder="سبب التعديل والفرضية المراد اختبارها"/>
    <button type="button" onClick={createProposal} disabled={busy || !rationale.trim()}>إنشاء مقترح بحثي</button>
    <label>Baseline folds JSON — لكل طية: expectancy, max_drawdown, sample_count</label><textarea rows={3} value={baselineFolds} onChange={e=>setBaselineFolds(e.target.value)}/>
    <label>Candidate folds JSON — بنفس ترتيب الطيات، وآخر طية Holdout</label><textarea rows={3} value={candidateFolds} onChange={e=>setCandidateFolds(e.target.value)}/>
    <div className="row"><button type="button" className="secondary" onClick={validate} disabled={busy || !proposalId}>تحقق Walk-Forward</button><button type="button" className="secondary" onClick={applyPaper} disabled={busy || !proposalId}>اعتماد نسخة Paper بعد نجاح الاختبار</button></div>
    {error && <div className="error">{error}</div>}
    {result && <div className="notice" style={{marginTop:8}}>{JSON.stringify(result)}</div>}
  </div>
}
